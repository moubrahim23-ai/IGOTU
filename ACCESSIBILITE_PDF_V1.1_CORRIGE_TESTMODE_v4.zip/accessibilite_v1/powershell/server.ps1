﻿param([switch]$TestMode)
$ErrorActionPreference='Stop'
$Base = Split-Path -Parent (Split-Path -Parent $MyInvocation.MyCommand.Path)
$SettingsPath=Join-Path $Base 'config\settings.json'; $UsersPath=Join-Path $Base 'config\users.json'; $MetaPath=Join-Path $Base 'data\metadata.json'; $HistoryPath=Join-Path $Base 'data\history.csv'
$S=Get-Content $SettingsPath -Raw|ConvertFrom-Json; $Port=[int]$S.port
$IsTestMode=($TestMode.IsPresent -or $env:ACCESSIBILITE_TEST -eq '1')
if($IsTestMode){$Root=Join-Path $Base 'TEST_ROOT'; $MetaPath=Join-Path $Base 'data\test_metadata.json'; $HistoryPath=Join-Path $Base 'data\test_history.csv'}else{$Root=$S.rootPath}
if(!(Test-Path $Root)){throw "Racine inaccessible : $Root"}
function Read-Json($p){if(Test-Path $p){Get-Content $p -Raw|ConvertFrom-Json}else{$null}}
function Write-Json($p,$o){$o|ConvertTo-Json -Depth 10|Set-Content $p -Encoding UTF8}
function CurrentUser(){ $w=$env:USERNAME; $us=@(Read-Json $UsersPath); $u=$us|? windows -eq $w|select -First 1; if(!$u){[pscustomobject]@{id='AUTO';name=$w;windows=$w;role='COLLABORATEUR';active=$true}}else{$u}}
function IdFor($p){$sha=[Security.Cryptography.SHA1]::Create(); (($sha.ComputeHash([Text.Encoding]::UTF8.GetBytes($p))|%{$_.ToString('x2')}) -join '')}
function Meta(){ $m=Read-Json $MetaPath; if(!$m){$m=[pscustomobject]@{}}; $m }
function SaveMeta($m){Write-Json $MetaPath $m}
function Log($action,$doc,$entity,$src,$dst,$status,$comment=''){ $u=CurrentUser; $line=[pscustomobject]@{Timestamp=(Get-Date -Format 'yyyy-MM-dd HH:mm:ss');WindowsUser=$u.windows;Action=$action;Document=$doc;Entity=$entity;SourcePath=$src;DestinationPath=$dst;Status=$status;Comment=$comment}; $line|Export-Csv $HistoryPath -Delimiter ';' -NoTypeInformation -Append -Encoding UTF8 }
function StatusOf($p){foreach($x in @('A TRAITER','EN COURS','NON CONFORME','TRAITES')){if($p -match ('\\'+[regex]::Escape($x)+'(\\|$)')){return ($x -replace ' ','_')}};''}
function EntityOf($p){$rel=$p.Substring($Root.Length).TrimStart('\'); ($rel -split '\\')[0]}
function RelativeOf($p){$p.Substring($Root.Length).TrimStart('\')}
$script:DocumentsCache=$null
$script:DocumentsCacheAt=[datetime]::MinValue
$script:DocumentsCacheSeconds=30
function Invalidate-DocumentsCache(){ $script:DocumentsCache=$null; $script:DocumentsCacheAt=[datetime]::MinValue }
function Documents([switch]$Force){
 if(!$Force -and $script:DocumentsCache -ne $null -and ((Get-Date)-$script:DocumentsCacheAt).TotalSeconds -lt $script:DocumentsCacheSeconds){return @($script:DocumentsCache)}
 $m=Meta; $out=@();
 # available source files
 Get-ChildItem $Root -Recurse -File -ErrorAction SilentlyContinue | ? { $_.Extension.ToLower() -in '.pdf','.doc','.docx' -and (StatusOf $_.FullName) -eq 'A_TRAITER' } | %{
   $id=IdFor $_.FullName; $md=$m.PSObject.Properties[$id].Value; $out += [pscustomobject]@{id=$id;name=$_.Name;path=$_.FullName;entity=(EntityOf $_.FullName);relative=(RelativeOf $_.DirectoryName);type=$_.Extension.Trim('.').ToUpper();status='A_TRAITER';priority=$(if($md){$md.priority}else{'Normale'});assigned=$(if($md){$md.assigned}else{''});owner=''}
 }
 # tracked work packages
 foreach($p in $m.PSObject.Properties){$md=$p.Value;if($md.status -and $md.status -ne 'A_TRAITER'){$out += [pscustomobject]@{id=$p.Name;name=$md.name;path=$md.path;entity=$md.entity;relative=(RelativeOf $md.path);type=$md.type;status=$md.status;priority=$md.priority;assigned=$md.assigned;owner=$md.owner}}}
 $script:DocumentsCache=@($out); $script:DocumentsCacheAt=Get-Date; @($script:DocumentsCache)
}
function FindStatusRoot($path,$status){$d=[IO.DirectoryInfo](Split-Path $path -Parent);while($d -and $d.FullName.StartsWith($Root,[StringComparison]::OrdinalIgnoreCase)){if($d.Name -eq $status){return $d.FullName};$d=$d.Parent};$null}
function Counterpart($statusRoot,$name){Join-Path (Split-Path $statusRoot -Parent) $name}
function AuditTemplatePath(){
 $configured=Join-Path $Base ([string]$S.auditTemplate)
 if(Test-Path $configured -PathType Leaf){return $configured}
 $fallback=Join-Path $Base 'templates\Fiche_Audit_RAPDF.xlsx'
 if(Test-Path $fallback -PathType Leaf){return $fallback}
 throw "Modèle d'audit introuvable. Vérifiez templates\Fiche_Audit_RAPDF.xlsx."
}
function EnsureAuditFile($pkg,$base){
 $existing=@(Get-ChildItem $pkg -File -Filter '*.xlsx' -ErrorAction SilentlyContinue)
 if($existing.Count -gt 0){return $existing[0].FullName}
 $tpl=AuditTemplatePath
 $audit=Join-Path $pkg ('Audit_'+$base+'.xlsx')
 Copy-Item -LiteralPath $tpl -Destination $audit -Force -ErrorAction Stop
 if(!(Test-Path $audit -PathType Leaf)){throw "La fiche d'audit n'a pas pu être créée."}
 return $audit
}
function TakeDoc($id){$u=CurrentUser;$d=Documents|? id -eq $id|select -First 1;if(!$d -or $d.status-ne'A_TRAITER'){throw 'Document déjà pris ou introuvable.'};$src=$d.path;$atr=FindStatusRoot $src 'A TRAITER';if(!$atr){throw 'Dossier A TRAITER introuvable.'};$relDir=(Split-Path $src -Parent).Substring($atr.Length).TrimStart('\');$en=Counterpart $atr 'EN COURS';$base=[IO.Path]::GetFileNameWithoutExtension($src);$pkg=Join-Path (Join-Path $en $relDir) $base
 # Valider le modèle AVANT de déplacer le document.
 $null=AuditTemplatePath
 New-Item $pkg -ItemType Directory -Force|Out-Null
 try{
   # move source and same-base Word/PDF companions
   Get-ChildItem (Split-Path $src -Parent) -File|?{[IO.Path]::GetFileNameWithoutExtension($_.Name)-eq$base -and $_.Extension.ToLower() -in '.pdf','.doc','.docx'}|%{Move-Item $_.FullName $pkg -ErrorAction Stop}
   $null=EnsureAuditFile $pkg $base
 }catch{
   # En cas d'échec, remettre les fichiers métier dans A TRAITER.
   Get-ChildItem $pkg -File -ErrorAction SilentlyContinue|?{$_.Extension.ToLower() -in '.pdf','.doc','.docx'}|%{Move-Item $_.FullName (Split-Path $src -Parent) -Force -ErrorAction SilentlyContinue}
   Remove-Item $pkg -Force -Recurse -ErrorAction SilentlyContinue
   throw
 }
 $m=Meta;$md=[pscustomobject]@{name=$d.name;entity=$d.entity;type=$d.type;status='EN_COURS';priority=$d.priority;assigned=$u.windows;owner=$u.windows;path=$pkg;original=$src;started=(Get-Date -Format o);comment=''};$m|Add-Member NoteProperty $id $md -Force;SaveMeta $m;Invalidate-DocumentsCache;Log 'PRISE_EN_CHARGE' $d.name $d.entity $src $pkg 'EN_COURS';$md
}
function FinishDoc($id,$status,$comment){$u=CurrentUser;$m=Meta;$md=$m.PSObject.Properties[$id].Value;if(!$md -or $md.status-ne'EN_COURS'){throw 'Traitement en cours introuvable.'};if($md.owner-ne$u.windows -and $u.role-ne'MANAGER'){throw 'Ce document est pris en charge par un autre collaborateur.'};$pkg=$md.path;if(!(Test-Path $pkg)){throw 'Dossier de travail introuvable.'};$files=@(Get-ChildItem $pkg -File);if(!($files|? Extension -eq '.xlsx')){$base=[IO.Path]::GetFileNameWithoutExtension($md.name);$null=EnsureAuditFile $pkg $base;throw "La fiche d'audit manquante vient d'être recréée dans le dossier EN COURS. Ouvrez-la et complétez-la, puis cliquez de nouveau sur Traité."};if($md.type -match 'DOC' -and !($files|? Extension -eq '.pdf')){throw 'Le PDF final est absent pour cette source Word.'};$en=FindStatusRoot (Join-Path $pkg 'x.tmp') 'EN COURS';if(!$en){$en=FindStatusRoot $pkg 'EN COURS'};$rel=$pkg.Substring($en.Length).TrimStart('\');$destRoot=Counterpart $en $(if($status-eq'TRAITES'){'TRAITES'}else{'NON CONFORME'});$dest=Join-Path $destRoot $rel;New-Item (Split-Path $dest -Parent) -ItemType Directory -Force|Out-Null;if(Test-Path $dest){throw 'Un dossier de même nom existe déjà dans la destination.'};Move-Item $pkg $dest;$md.status=$status;$md.path=$dest;$md.finished=(Get-Date -Format o);$md.comment=$comment;SaveMeta $m;Invalidate-DocumentsCache;Log 'FINALISATION' $md.name $md.entity $pkg $dest $status $comment;$md
}
function Send($stream,$code,$obj,$type='application/json'){if($type-eq'application/json'){if($null -eq $obj){$body='null'}elseif($obj -is [Array]){if($obj.Count -eq 0){$body='[]'}else{$body=ConvertTo-Json -InputObject $obj -Depth 10 -Compress}}else{$body=$obj|ConvertTo-Json -Depth 10 -Compress}}else{$body=[string]$obj};$bytes=[Text.Encoding]::UTF8.GetBytes([string]$body);$reason=if($code-eq200){'OK'}else{'Error'};$hdr="HTTP/1.1 $code $reason`r`nContent-Type: $type; charset=utf-8`r`nContent-Length: $($bytes.Length)`r`nAccess-Control-Allow-Origin: *`r`nAccess-Control-Allow-Headers: Content-Type`r`nAccess-Control-Allow-Methods: GET,POST,OPTIONS`r`nConnection: close`r`n`r`n";$hb=[Text.Encoding]::ASCII.GetBytes($hdr);$stream.Write($hb,0,$hb.Length);$stream.Write($bytes,0,$bytes.Length)}
function BodyObj($body){if([string]::IsNullOrWhiteSpace($body)){return [pscustomobject]@{}};$body|ConvertFrom-Json}
$listener=[Net.Sockets.TcpListener]::new([Net.IPAddress]::Loopback,$Port);$listener.Start();$mode=if($IsTestMode){'TEST - aucune donnée de production'}else{'PRODUCTION'};Write-Host "Accessibilite V1.1 [$mode] : http://127.0.0.1:$Port/app/collaborateur.html" -ForegroundColor Green
while($true){$c=$listener.AcceptTcpClient();$st=$c.GetStream();try{$r=New-Object IO.StreamReader($st,[Text.Encoding]::UTF8,$false,4096,$true);$first=$r.ReadLine();if(!$first){$c.Close();continue};$parts=$first.Split(' ');$method=$parts[0];$target=$parts[1];$len=0;while(($line=$r.ReadLine()) -ne ''){if($line -match '^Content-Length:\s*(\d+)'){$len=[int]$matches[1]}};$body='';if($len-gt0){$buf=New-Object char[] $len;$null=$r.ReadBlock($buf,0,$len);$body=-join$buf};if($method-eq'OPTIONS'){Send $st 200 @{};continue};$uri=[Uri]("http://localhost"+$target);$path=$uri.AbsolutePath.TrimEnd('/').ToLowerInvariant();if([string]::IsNullOrEmpty($path)){$path='/'};$q=[Web.HttpUtility]::ParseQueryString($uri.Query)
 if($path.StartsWith('/api/')){try{switch -Exact ($path){
 '/api/me' {Send $st 200 (CurrentUser)}
 '/api/mode' {Send $st 200 ([pscustomobject]@{test=$IsTestMode;mode=$(if($IsTestMode){'TEST'}else{'PRODUCTION'});root=$Root;cacheSeconds=$script:DocumentsCacheSeconds})}
 '/api/refresh' {Invalidate-DocumentsCache;Send $st 200 ([pscustomobject]@{ok=$true})}
 '/api/documents' {$ds=@(Documents);if($q['status']){$ds=@($ds|? status -eq $q['status'])};if($q['mine']-eq'1'){$w=(CurrentUser).windows;$ds=@($ds|? owner -eq $w)};Send $st 200 $ds}
 '/api/take' {$o=BodyObj $body;Send $st 200 (TakeDoc $o.id)}
 '/api/take-next' {$u=CurrentUser;$ds=@(Documents|? status -eq'A_TRAITER');$rank=@{'Urgente'=0;'Prioritaire'=1;'Normale'=2};$d=$ds|sort @{e={if($_.assigned-eq$u.windows){0}elseif($_.assigned){2}else{1}}},@{e={$rank[$_.priority]}},name|select -First 1;if(!$d){throw 'Aucun document disponible.'};Send $st 200 (TakeDoc $d.id)}
 '/api/finish' {$o=BodyObj $body;Send $st 200 (FinishDoc $o.id $o.status $o.comment)}
 '/api/users' {if($method-eq'POST'){$o=BodyObj $body;$us=@(Read-Json $UsersPath);$us+= [pscustomobject]@{id=('USR'+(Get-Random -Minimum 1000 -Maximum 9999));name=$o.name;windows=$o.windows;role=$o.role;active=$true};Write-Json $UsersPath $us;Send $st 200 $us}else{Send $st 200 @(Read-Json $UsersPath)}}
 '/api/users/toggle' {$o=BodyObj $body;$us=@(Read-Json $UsersPath);($us|? id -eq$o.id).active=[bool]$o.active;Write-Json $UsersPath $us;Send $st 200 $us}
 '/api/priority' {$o=BodyObj $body;$m=Meta;$d=Documents|? id-eq$o.id|select -First 1;$md=$m.PSObject.Properties[$o.id].Value;if(!$md){$md=[pscustomobject]@{name=$d.name;entity=$d.entity;type=$d.type;status='A_TRAITER';priority=$o.priority;assigned='';owner='';path=$d.path;original=$d.path};$m|Add-Member NoteProperty $o.id $md -Force}else{$md.priority=$o.priority};SaveMeta $m;Invalidate-DocumentsCache;Log 'PRIORITE' $d.name $d.entity $d.path $d.path $d.status $o.priority;Send $st 200 $md}
 '/api/rework' {$o=BodyObj $body;$m=Meta;$md=$m.PSObject.Properties[$o.id].Value;if(!$md-or$md.status-ne'NON_CONFORME'){throw 'Document non conforme introuvable.'};$nc=FindStatusRoot (Join-Path $md.path 'x.tmp') 'NON CONFORME';if(!$nc){$nc=FindStatusRoot $md.path 'NON CONFORME'};$rel=$md.path.Substring($nc.Length).TrimStart('\');$en=Counterpart $nc 'EN COURS';$dst=Join-Path $en $rel;New-Item (Split-Path $dst -Parent)-ItemType Directory -Force|Out-Null;Move-Item $md.path $dst;$md.path=$dst;$md.status='EN_COURS';$md.owner='';$md.assigned='';SaveMeta $m;Invalidate-DocumentsCache;Log 'RETRAITEMENT_AUTORISE' $md.name $md.entity $nc $dst 'EN_COURS';Send $st 200 $md}
 '/api/history' {$rows=@();if(Test-Path $HistoryPath){$rows=@(Import-Csv $HistoryPath -Delimiter ';')|sort Timestamp -Descending};if($q['mine']-eq'1'){$w=(CurrentUser).windows;$rows=@($rows|? WindowsUser-eq$w)};$lim=if($q['limit']){[int]$q['limit']}else{100};Send $st 200 @($rows|select -First $lim)}
 '/api/dashboard' {$ds=@(Documents);$u=@(Read-Json $UsersPath);$w=(CurrentUser).windows;$today=Get-Date -Format 'yyyy-MM-dd';$hist=@();if(Test-Path $HistoryPath){$hist=@(Import-Csv $HistoryPath -Delimiter ';' -ErrorAction SilentlyContinue)};$todo=0;$inProgress=0;$mine=0;$done=0;$nc=0;$ipByOwner=@{};foreach($d in $ds){switch($d.status){'A_TRAITER'{$todo++};'EN_COURS'{$inProgress++;if($d.owner-eq$w){$mine++};if($d.owner){if(!$ipByOwner.ContainsKey($d.owner)){$ipByOwner[$d.owner]=0};$ipByOwner[$d.owner]++}};'TRAITES'{$done++};'NON_CONFORME'{$nc++}}};$doneByUser=@{};$doneToday=0;foreach($h in $hist){if($h.Action-eq'FINALISATION'-and$h.Status-eq'TRAITES'){if(!$doneByUser.ContainsKey($h.WindowsUser)){$doneByUser[$h.WindowsUser]=0};$doneByUser[$h.WindowsUser]++;if($h.Timestamp.StartsWith($today)){$doneToday++}}};$team=@($u|? active|%{$uw=$_.windows;[pscustomobject]@{name=$_.name;inProgress=$(if($ipByOwner.ContainsKey($uw)){$ipByOwner[$uw]}else{0});done=$(if($doneByUser.ContainsKey($uw)){$doneByUser[$uw]}else{0})}});Send $st 200 ([pscustomobject]@{todo=$todo;inProgress=$inProgress;mine=$mine;done=$done;doneToday=$doneToday;nonConform=$nc;team=$team;mode=$(if($IsTestMode){'TEST'}else{'PRODUCTION'})})}
 '/api/anomalies' {$a=@();$m=Meta;foreach($p in $m.PSObject.Properties){$md=$p.Value;if($md.status-ne'A_TRAITER'-and!(Test-Path $md.path)){$a+="$($md.name) : chemin introuvable ($($md.path))"}};Send $st 200 $a}
 default {Send $st 404 @{error='API inconnue'}} }}catch{Send $st 500 @{error=$_.Exception.Message}} }
 else {$local=Join-Path $Base ($path.TrimStart('/') -replace '/','\');if($path-eq'/'){$local=Join-Path $Base 'app\collaborateur.html'};if(Test-Path $local -PathType Leaf){$ext=[IO.Path]::GetExtension($local);$ct=switch($ext){'.html'{'text/html'}'.css'{'text/css'}'.js'{'application/javascript'}default{'application/octet-stream'}};Send $st 200 ([IO.File]::ReadAllText($local)) $ct}else{Send $st 404 'Introuvable' 'text/plain'}}
}catch{try{Send $st 500 @{error=$_.Exception.Message}}catch{}}finally{$st.Close();$c.Close()}}
