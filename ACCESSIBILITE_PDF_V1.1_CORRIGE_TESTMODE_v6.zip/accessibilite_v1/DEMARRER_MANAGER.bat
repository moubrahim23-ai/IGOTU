@echo off
setlocal
cd /d "%~dp0"
set "ACCESSIBILITE_TEST="
start "Accessibilite Backend V1.1" powershell.exe -NoProfile -ExecutionPolicy RemoteSigned -File "%~dp0powershell\server.ps1"
powershell.exe -NoProfile -Command "$ok=$false; 1..20 | %% { if(Test-NetConnection 127.0.0.1 -Port 8765 -InformationLevel Quiet -WarningAction SilentlyContinue){$ok=$true;break}; Start-Sleep -Milliseconds 500 }; if(-not $ok){exit 1}"
if errorlevel 1 (
 echo Le serveur n'a pas demarre. Consultez la fenetre PowerShell pour le message d'erreur.
 pause
 exit /b 1
)
start "" "http://127.0.0.1:8765/app/manager.html"
endlocal
