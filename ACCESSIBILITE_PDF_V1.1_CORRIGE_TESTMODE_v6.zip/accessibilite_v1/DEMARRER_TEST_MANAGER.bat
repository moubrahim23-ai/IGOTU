@echo off
setlocal
cd /d "%~dp0"
set "ACCESSIBILITE_TEST=1"
start "Accessibilite Backend V1.1 - MODE TEST" powershell.exe -NoProfile -ExecutionPolicy RemoteSigned -Command "$env:ACCESSIBILITE_TEST='1'; & '%~dp0powershell\server.ps1'"
powershell.exe -NoProfile -Command "$ok=$false; 1..20 | %% { if(Test-NetConnection 127.0.0.1 -Port 8765 -InformationLevel Quiet -WarningAction SilentlyContinue){$ok=$true;break}; Start-Sleep -Milliseconds 500 }; if(-not $ok){exit 1}"
if errorlevel 1 (echo Le serveur TEST n'a pas demarre.& pause & exit /b 1)
start "" "http://127.0.0.1:8765/app/manager.html"
endlocal
