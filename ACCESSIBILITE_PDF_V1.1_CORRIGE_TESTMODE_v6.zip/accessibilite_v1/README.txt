ACCESSIBILITE PDF - V1
======================

1. Copier tout le dossier ACCESSIBILITE_V1 sur un emplacement accessible à l'utilisateur.
2. Ouvrir config\settings.json et vérifier rootPath. Valeur préconfigurée : \\UF11-A03\eids-eaa-pdf-statiques\ACCESSIBILITE
3. Ouvrir config\users.json et remplacer A_REMPLACER_HIBA / HAFSSA / IMAD par leurs vrais identifiants Windows (commande PowerShell : $env:USERNAME).
4. Le modèle d'audit fourni est templates\Fiche_Audit_RAPDF.xlsx.
5. Collaborateur : double-cliquer DEMARRER_COLLABORATEUR.bat.
6. Manager : double-cliquer DEMARRER_MANAGER.bat.

IMPORTANT
- La V1 utilise un serveur HTTP LOCAL (127.0.0.1:8765), uniquement sur le poste de l'utilisateur. Aucun serveur Internet.
- Le moteur PowerShell effectue les déplacements sur le partage réseau avec les droits Windows de l'utilisateur connecté.
- A la prise en charge : création d'un dossier dans EN COURS, déplacement du PDF/Word source, copie de la fiche d'audit.
- Source Word : la finalisation exige qu'un PDF soit présent.
- Toute finalisation exige une fiche .xlsx.
- Les actions sont journalisées dans data\history.csv.
- Les métadonnées sont dans data\metadata.json.
- Pour une utilisation multi-postes réelle, placez le dossier applicatif commun sur le partage réseau afin que config/data/logs soient partagés. Chaque poste lance son propre backend local depuis ce dossier.

SECURITE / EXPLOITATION
- Tester d'abord sur une COPIE de l'arborescence métier avant production.
- Ne pas modifier manuellement metadata.json pendant que l'application tourne.
- Conserver une sauvegarde régulière de data\history.csv et data\metadata.json.
- Les droits réels restent ceux du partage Windows.

LIMITES V1 A TESTER AVANT PRODUCTION
- Les structures de dossiers atypiques peuvent nécessiter un ajustement.
- Le modèle d'audit est copié tel quel; son contenu n'est pas encore validé automatiquement.
- La gestion simultanée multi-postes repose sur le déplacement atomique du fichier, mais metadata.json est un fichier partagé : une V2 pourra ajouter un verrou de données renforcé.
