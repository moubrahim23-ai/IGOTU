CORRECTION TESTMODE v3
======================
- /api/documents accepte maintenant les variantes avec slash final et casse differente.
- Les routes API utilisent un switch exact apres normalisation du chemin.
- Correction importante de la serialisation JSON des tableaux PowerShell : un seul document reste renvoye sous forme de tableau JSON [ ... ] au lieu d'un objet { ... }.
- Cela corrige l'erreur JavaScript : TypeError: ds.map is not a function.

TEST
1. Fermer l'ancien serveur (Ctrl+C dans sa fenetre PowerShell).
2. Remplacer l'ancien dossier par ce dossier corrige.
3. Lancer DEMARRER_TEST_MANAGER.bat.
4. Ouvrir Documents : TEST_Document_01.pdf doit apparaitre.
5. Tester ensuite Historique, Non conformes, Equipe et Anomalies.
