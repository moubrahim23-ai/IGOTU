CORRECTION TESTMODE v4
======================
- Conserve les corrections v3 (/api/documents et tableaux JSON).
- Corrige la gestion de la fiche d'audit Excel lors de la prise en charge.
- Le modèle templates\Fiche_Audit_RAPDF.xlsx est vérifié AVANT de déplacer le document.
- Après la prise en charge, Audit_<nom_document>.xlsx doit obligatoirement être présent dans EN COURS.
- Si un document déjà EN COURS n'a pas sa fiche d'audit (cas créé avec v3), un clic sur « Traité » recrée automatiquement la fiche puis bloque la finalisation avec un message demandant de la compléter.
- Si la copie de la fiche échoue pendant une nouvelle prise en charge, le PDF/Word est remis dans A TRAITER afin d'éviter un dossier de travail incomplet.

TEST CONSEILLÉ
1. Fermer l'ancien serveur (Ctrl+C).
2. Utiliser ce dossier v4 et lancer DEMARRER_TEST_COLLABORATEUR.bat.
3. Prendre TEST_Document_01.pdf.
4. Vérifier dans EN COURS\TEST_Document_01 la présence de :
   - TEST_Document_01.pdf
   - Audit_TEST_Document_01.xlsx
5. Compléter la fiche d'audit, puis cliquer sur « Traité ».
