ACCESSIBILITE PDF V1.1 - CORRECTION TESTMODE V5

Correction : chemin du modèle d'audit Excel.
Cause identifiée : PowerShell utilise une portée dynamique pour les variables. La variable locale $base contenant le nom du document masquait la variable globale $Base utilisée pour construire le chemin templates\\Fiche_Audit_RAPDF.xlsx.

Correction V5 :
- racine de l'application renommée $AppRoot ;
- $AppRoot calculé explicitement depuis $PSScriptRoot ;
- paramètre local d'EnsureAuditFile renommé $docBase ;
- aucun accès aux données de production en -TestMode.

Test attendu : lors de la prise en charge de TEST_Document_01.pdf, le dossier EN COURS\\TEST_Document_01 contient le PDF et Audit_TEST_Document_01.xlsx.
