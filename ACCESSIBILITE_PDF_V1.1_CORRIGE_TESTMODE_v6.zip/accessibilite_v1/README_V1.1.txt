ACCESSIBILITE PDF - V1.1
========================

CORRECTIONS PRINCIPALES
- Correction de l'erreur HTTP 500 du dashboard : EntityOf utilisait -split '\' (expression reguliere invalide). V1.1 utilise -split '\\'.
- StatusOf conserve la detection robuste des dossiers A TRAITER / EN COURS / NON CONFORME / TRAITES.
- Cache documentaire de 30 secondes : le partage reseau n'est plus rescane a chaque appel du dashboard.
- Invalidation immediate du cache apres prise en charge, finalisation, changement de priorite et retraitement.
- Calcul du dashboard optimise en un seul parcours des documents et de l'historique.
- Les boutons de demarrage attendent que le port 8765 reponde avant d'ouvrir Edge.

TEST SECURISE (A FAIRE EN PREMIER)
1. Fermer toute ancienne fenetre "Accessibilite Backend" afin de liberer le port 8765.
2. Double-cliquer DEMARRER_TEST_MANAGER.bat.
3. Le MODE TEST utilise uniquement le dossier local TEST_ROOT et les fichiers data/test_*.
4. Le partage de production configure dans settings.json n'est pas utilise en MODE TEST.
5. Verifier le tableau de bord : 1 document "TEST_Document_01.pdf" doit apparaitre A TRAITER.
6. Tester la prise en charge depuis DEMARRER_TEST_COLLABORATEUR.bat (apres avoir ferme le serveur manager si necessaire).
7. Verifier que le fichier passe de A TRAITER vers EN COURS et que la fiche Audit_*.xlsx est copiee.

PRODUCTION
- Verifier config/settings.json > rootPath.
- Fermer le serveur TEST.
- Double-cliquer DEMARRER_MANAGER.bat ou DEMARRER_COLLABORATEUR.bat.
- Le mode production utilise le partage reseau configure dans settings.json.

ACTUALISATION
- Le cache dure au maximum 30 secondes.
- Les actions de workflow rafraichissent le cache immediatement.
- Dans l'espace collaborateur, le bouton Actualiser force egalement un nouveau scan.

IMPORTANT
- Ne pas lancer simultanement TEST et PRODUCTION : les deux utilisent le port local 8765.
- Toujours tester V1.1 avec DEMARRER_TEST_MANAGER.bat avant la premiere utilisation en production.
