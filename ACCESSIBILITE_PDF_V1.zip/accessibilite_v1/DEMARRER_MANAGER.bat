@echo off
cd /d "%~dp0"
start "Accessibilite Backend" powershell.exe -NoProfile -ExecutionPolicy RemoteSigned -File "%~dp0powershell\server.ps1"
timeout /t 2 /nobreak >nul
start "" "http://127.0.0.1:8765/app/manager.html"
