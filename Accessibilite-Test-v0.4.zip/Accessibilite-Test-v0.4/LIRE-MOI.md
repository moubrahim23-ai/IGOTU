# Accessibilité — v0.4 TEST LOCAL

Application HTML/CSS/JS et serveur PowerShell. Aucun module externe, installation administrateur ou accès internet requis sur le poste utilisateur. Les tests de développement inclus nécessitent d'autres outils, pas l'application.

## Mise à jour

Suivre INSTALLATION_CORRECTIF.txt. Remplacer server.ps1, seed.json et web ; ajouter backup.ps1 et Restaurer.ps1 ; conserver TEST-DATA, TEST-FILES et SAUVEGARDES. Ne pas utiliser l'ancienne interface avec le nouveau serveur.

## Nouveau parcours avec fichiers

1. Choisir le rôle Manager, puis Documents → **Importer un document de test**.
2. Choisir l'entité et la nature. Sélectionner un PDF, un DOCX ou les deux pour un seul document.
3. L'import copie les fichiers, archive l'original dans `TEST-FILES/Historique/<identifiant>/V001`, puis crée le dossier de travail dans `TEST-FILES/A TRAITER/<identifiant>/Source`. Les fichiers sélectionnés sur le PC ne sont pas déplacés ni modifiés.
4. Affecter le document ou sélectionner un collaborateur puis **Prendre en charge**. Le dossier passe réellement dans EN COURS.
5. Dans la fiche, télécharger une copie de la source pour travailler. Enregistrer son travail dans un autre dossier, puis utiliser **Déposer les livrables**.
6. Déposer le PDF final et l'audit XLSX ; si la source comporte un Word, le DOCX final est obligatoire. Le remplacement d'un dépôt final conserve le précédent dans Historique.
7. **Clôturer et déplacer vers Traités** vérifie les fichiers attendus et leurs empreintes, puis déplace le dossier complet dans TRAITES. Aucun contrôle manager préalable n'est requis.
8. **Déclarer non conforme**, avec motif, déplace le dossier dans NON CONFORME et arrête le chrono.
9. Le manager utilise **Importer le retour corrigé** avec les pièces reçues par mail. La source V002 (puis V003…) est archivée, l'ancien travail est conservé dans Historique, le dossier revient en A TRAITER, l'agent initial est conservé et la date du premier dépôt ne change pas.
10. Le manager peut rouvrir un traité pour correction. Les livrables précédents sont archivés et le dossier revient en A TRAITER.

Les cinq exemples fournis restent fictifs et conservent leurs boutons de simulation. Un document importé ne peut pas être clôturé en simulant la présence des fichiers. Un même nom importé deux fois crée deux documents distincts : aucun dédoublonnage ou écrasement implicite.

## Horaires

Import, consultation, affectation et déclaration NC possibles hors horaires. La prise en charge et la reprise du chrono restent limitées aux horaires configurés, hors week-ends et jours de fermeture. Les tests automatisés injectent une horloge de test ; ils ne modifient pas celle du poste.

## Formats et limites

- Source : PDF et DOCX. Les anciens formats DOC/XLS ne sont pas encore pris en charge.
- Livrables : PDF, XLSX et DOCX si requis ; un fichier maximum par format.
- 10 Mio par fichier, 12 Mio par envoi, nom de fichier de 100 caractères maximum.
- Le PDF est vérifié par sa signature ; les fichiers Office par leur structure ZIP minimale. L'application ne vérifie pas encore le remplissage de l'audit, la lisibilité complète, la protection du PDF ou la conformité RAPDF. Elle n'exécute pas les documents importés.
- Les dossiers physiques sont classés par statut et identifiant interne dans cet espace de test. Le classement par entité reste dans la fiche ; le branchement sur les vrais dossiers par entité viendra ensuite.

## Récupération et sauvegarde

Les déplacements sont accompagnés d'un manifeste de transaction. Au démarrage, une opération non validée dans le journal est annulée ; une opération validée est conservée. Une collision ou incohérence ne déclenche aucune suppression automatique. Si la reprise ne peut pas aboutir, conserver les deux dossiers de données pour diagnostic.

Ne pas déplacer ou renommer manuellement les fichiers sous TEST-FILES pendant le fonctionnement. En cas d'échec d'enregistrement, le mouvement est annulé lorsque les chemins restent cohérents. Les zones de staging et manifestes sont conservées pour diagnostic, sans purge automatique.

La sauvegarde quotidienne est désormais complète : données, journal, sources, versions et livrables. L’onglet Sauvegardes permet de changer l’emplacement, créer une copie et la vérifier. La restauration utilise Restaurer.ps1 et crée un nouveau dossier sans écrasement. Lire RESTAURATION.md. Choisir un autre disque ou emplacement autorisé pour se protéger d’une panne du disque ; la destination locale par défaut ne suffit pas à cet objectif.

## Périmètre restant

Authentification Windows réelle, plusieurs postes sur partage SMB, détection automatique des dépôts, versions reçues en cours de traitement, publication physique ACM, évaluations RAPDF, exports/reportings Excel, import de l'ancien consolidé et Outlook. Les rôles restent sélectionnables pour la démonstration : ce n'est pas une gestion sécurisée des droits de production.

Les fichiers importés sont de vraies copies locales. Aucun dossier client n'est connecté. Les tests et leurs limites sont décrits dans VERIFICATION.md.
