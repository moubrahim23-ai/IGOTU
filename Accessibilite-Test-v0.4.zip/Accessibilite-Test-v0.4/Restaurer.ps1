﻿param([Parameter(Mandatory=$true)][string]$Sauvegarde,[Parameter(Mandatory=$true)][string]$Destination)
$ErrorActionPreference='Stop'
. (Join-Path $PSScriptRoot 'backup.ps1')
# Lecture de la sauvegarde uniquement ; copie vers un nouveau dossier, jamais sur l'installation existante.
$result=Restore-NewFolder $Sauvegarde $Destination $PSScriptRoot
Write-Host "Restauration vérifiée dans : $result"
Write-Host 'Aucun serveur lancé. Arrêtez votre ancien serveur avant de lancer la copie restaurée.'
