# Vérification — Accessibilité v0.4

Exécution le 27 septembre 2026 sur copies temporaires isolées, avec PowerShell 7.4.14 sous Linux, Python et Node.js.

## 216 contrôles automatisés réussis

| Suite | Contrôles | Couverture |
|---|---:|---|
| workflow.ps1 | 29 | Réservation, rôles, pause/reprise, NC, clôture, publication fictive, horaires, journal |
| settings.ps1 | 30 | Paramètres, migration, droits, désactivation, horaires à la minute, fermetures |
| server_http.py | 22 | Serveur réel, contrôles de requête, conflits, sauvegarde, redémarrage |
| frontend.cjs | 41 | Vrai JS avec DOM simulé : filtres, rôles, paramètres et commandes de fichiers |
| files.ps1 | 36 | Vrais octets et déplacements : import, archive, homonymes, livrables, altération, NC, retour, réouverture, collisions, rollback |
| files_http.py | 14 | Import HTTP, téléchargement exact, déplacements sur disque et récupération au démarrage |
| backup.ps1 (tests) | 31 | Sauvegardes complètes, intégrité, rétention, échecs, copies corrompues et restauration sans écrasement |
| backup_http.py | 13 | Sauvegarde par API, script de restauration, démarrage du serveur restauré et téléchargement exact |

Les suites existantes ont été réexécutées sur la nouvelle version. Syntaxe JS et analyse syntaxique PowerShell vérifiées.

## Incidents testés

- Destination déjà occupée : refus et conservation de la source.
- Échec de sauvegarde après déplacement : retour à la position et à l'état précédemment enregistrés.
- Interruption avant déplacement, après le premier ou le deuxième déplacement d'un remplacement de livrables, y compris entre déplacement et checkpoint : récupération des deux jeux de fichiers.
- Vrai redémarrage de processus avec un déplacement effectué mais non validé : restauration de la source, statut cohérent et original intact.
- Redémarrage avec une transaction déjà enregistrée mais un manifeste non clôturé : opération conservée, sans document dupliqué.

## Contrôles documentaires

Empreintes SHA-256 comparées pour la conservation des sources et la détection d'une altération des livrables après dépôt. Téléchargement comparé octet par octet. Données synthétiques utilisées : signature PDF et archives Office minimales, sans contenu client et sans certification de validité métier.

Le contrôle d'un fichier Office vérifie la structure minimale du conteneur. Le contrôle PDF vérifie une signature, pas le balisage ni l'absence de protection. L'audit peut être vide : le module de validation de ses critères n'est pas encore présent.

## Limites exactes

Windows PowerShell 5.1, verrous de fichiers Windows, chemins longs, applications Office et partages SMB n'ont pas été exécutés dans cet environnement. Aucun test ne prouve la résistance à une panne matérielle ou à toutes les coupures système. Les tests d'interruption reproduisent les états intermédiaires et la reprise, pas une panne électrique.

Le navigateur complet reste bloqué par les restrictions de l'environnement de développement. Les 41 tests JS utilisent un DOM simulé : ils ne valident pas le rendu ni les dialogues natifs de sélection de fichiers sous Chrome/Edge. browser.cjs reste un scénario fourni mais non validé ici.

Les sauvegardes quotidiennes comprennent désormais TEST-DATA et TEST-FILES, avec vérification des empreintes avant validation. Tests supplémentaires : destination inaccessible, corruption, fichier ajouté, chemin de manifeste traversant, restauration dans un dossier neuf, chronomètres en pause, refus d’écrasement et reprise du serveur restauré. Le serveur restauré a servi les octets exacts d’un document. L’installation initiale est restée intacte. La destination par défaut est sur le même disque ; une copie indépendante est à configurer pour les pannes de disque. Pas de connexion à un dossier client, pas de publication physique ACM, pas de déploiement multi-postes.

## Rejouer

PowerShell : tests/workflow.ps1, tests/settings.ps1, tests/files.ps1, tests/backup.ps1.
Node.js : `node tests/frontend.cjs`.
Python : définir TEST_PWSH vers PowerShell, puis lancer tests/server_http.py (port 18091) et tests/files_http.py (port 18092) et tests/backup_http.py (ports 18093 et 18094). Les suites n'utilisent pas vos données de test personnelles.
