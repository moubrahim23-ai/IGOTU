﻿# Sauvegardes locales complètes. Fonctions également utilisées par Restaurer.ps1.
function Full-Path($path){$full=[IO.Path]::GetFullPath($path);if($full -eq [IO.Path]::GetPathRoot($full)){return $full};return $full.TrimEnd([char[]]@([IO.Path]::DirectorySeparatorChar,[IO.Path]::AltDirectorySeparatorChar))}
function Inside-Path($path,$parent){
    $a=Full-Path $path;$b=Full-Path $parent;$comparison=[StringComparison]::Ordinal
    if([IO.Path]::DirectorySeparatorChar -eq [char]92){$comparison=[StringComparison]::OrdinalIgnoreCase}
    return $a.Equals($b,$comparison) -or $a.StartsWith($b.TrimEnd([char[]]@([IO.Path]::DirectorySeparatorChar,[IO.Path]::AltDirectorySeparatorChar))+[IO.Path]::DirectorySeparatorChar,$comparison)
}
function Assert-NoLink($path){
    $cursor=[IO.Path]::GetFullPath($path)
    while($cursor){
        if(Test-Path -LiteralPath $cursor){if((Get-Item -LiteralPath $cursor -Force).Attributes -band [IO.FileAttributes]::ReparsePoint){throw 'Jonction ou lien symbolique refusé pour la sauvegarde'}}
        $next=[IO.Path]::GetDirectoryName($cursor);if($next -eq $cursor){break};$cursor=$next
    }
}
function Tree-Files($directory){
    Assert-NoLink $directory
    if(-not (Test-Path -LiteralPath $directory -PathType Container)){throw 'Dossier absent pour la sauvegarde'}
    $queue=New-Object 'System.Collections.Generic.Queue[string]';$queue.Enqueue($directory)
    while($queue.Count){
        $dir=[IO.DirectoryInfo]::new($queue.Dequeue())
        foreach($entry in $dir.GetFileSystemInfos()){
            if($entry.Attributes -band [IO.FileAttributes]::ReparsePoint){throw 'Lien symbolique ou jonction dans les données : sauvegarde interrompue'}
            if($entry -is [IO.DirectoryInfo]){$queue.Enqueue($entry.FullName)}else{Write-Output $entry}
        }
    }
}
function Backup-Hash($path){return (Get-FileHash -LiteralPath $path -Algorithm SHA256).Hash}
function Backup-Relative($base,$path){return $path.Substring((Full-Path $base).Length+1).Replace([char]92,[char]47)}
function Backup-Child($base,$relative){
    if(-not $relative -or $relative -match '(^/|\\|:|(^|/)\.\.?(/|$))'){throw 'Chemin de manifeste invalide'}
    $path=[IO.Path]::GetFullPath((Join-Path $base $relative))
    if(-not (Inside-Path $path $base) -or (Full-Path $path) -eq (Full-Path $base)){throw 'Chemin de manifeste hors sauvegarde'}
    Assert-NoLink $path;return $path
}
function Verify-Backup($directory){
    Assert-NoLink $directory
    $manifestPath=Join-Path $directory 'manifest.json'
    $m=Get-Content -LiteralPath $manifestPath -Raw -Encoding UTF8|ConvertFrom-Json
    if($m.format -ne 'ACCESSIBILITE-BACKUP-1' -or @($m.files).Count -lt 1){throw 'Format de sauvegarde non reconnu'}
    $payload=Join-Path $directory 'payload';$seen=@{};$bytes=[long]0
    foreach($entry in $m.files){
        $rel=[string]$entry.path
        if($rel -notmatch '^(TEST-DATA|TEST-FILES)/' -or $seen.ContainsKey($rel)){throw 'Fichier de manifeste invalide ou en double'};$seen[$rel]=$entry
        $path=Backup-Child $payload $rel
        if(-not (Test-Path -LiteralPath $path -PathType Leaf)){throw "Fichier de sauvegarde manquant : $rel"}
        $file=Get-Item -LiteralPath $path
        if($file.Length -ne [long]$entry.size -or (Backup-Hash $path) -ne $entry.sha256){throw "Intégrité de sauvegarde incorrecte : $rel"}
        $bytes+=$file.Length
    }
    $actual=@(Tree-Files $payload)
    if($actual.Count -ne $seen.Count){throw 'Fichiers inattendus dans la sauvegarde'}
    if([string]$m.sequence -notmatch '^[0-9]+$'){throw 'Numéro de snapshot invalide'}
    $snapshot='TEST-DATA/commits/'+('{0:D12}.json' -f [int]$m.sequence)
    if(-not $seen.ContainsKey($snapshot)){throw 'Snapshot de reprise absent'}
    $snapshotState=Get-Content -LiteralPath (Backup-Child $payload $snapshot) -Raw -Encoding UTF8|ConvertFrom-Json
    foreach($d in $snapshotState.docs){
        if($d.physical){
            foreach($file in @($d.sourceFiles)){
                $rel='TEST-FILES/'+$d.status+'/'+$d.id+'/Source/'+$file.name
                if(-not $seen.ContainsKey($rel) -or $seen[$rel].sha256 -ne $file.sha256){throw 'Source physique absente ou altérée par rapport au journal'}
            }
            foreach($file in @($d.finalFiles)){
                $rel='TEST-FILES/'+$d.status+'/'+$d.id+'/Livrables/'+$file.name
                if(-not $seen.ContainsKey($rel) -or $seen[$rel].sha256 -ne $file.sha256){throw 'Livrable physique absent ou altéré par rapport au journal'}
            }
            if(-not @($m.files|Where-Object {$_.path.StartsWith('TEST-FILES/Historique/'+$d.id+'/V001/')})){throw 'Original V001 absent de la sauvegarde'}
        }
    }
    if($seen.ContainsKey('TEST-FILES/transactions/pending.json')){throw 'Sauvegarde contenant une transaction inachevée'}
    return [pscustomobject]@{id=$m.id;at=$m.at;files=$seen.Count;bytes=$bytes;sequence=$m.sequence;valid=$true}
}
function Ensure-Backup {
    if(-not $script:state.PSObject.Properties['backup']){
        $script:state|Add-Member -NotePropertyName backup -NotePropertyValue ([pscustomobject]@{directory=(Join-Path $root 'SAUVEGARDES');lastSuccess=$null;lastId=$null;lastAttempt=$null;lastError='';automaticDay='';version=1})
        Save-State
    }
}
function Backup-Destination($path){
    if(-not [IO.Path]::IsPathRooted($path)){throw 'Indiquez un chemin absolu de sauvegarde'}
    $dest=Full-Path $path;Assert-NoLink $dest
    foreach($source in @($store,(Join-Path $root 'TEST-FILES'),(Join-Path $root 'web'))){
        if((Inside-Path $dest $source) -or (Inside-Path $source $dest)){throw 'La destination doit être séparée des dossiers de données et de travail'}
    }
    return $dest
}
function List-Backups {
    $destination=$script:state.backup.directory
    if(-not (Test-Path -LiteralPath $destination -PathType Container)){return @()}
    Assert-NoLink $destination;$rows=@()
    foreach($dir in Get-ChildItem -LiteralPath $destination -Directory -Filter 'ACC-*'|Sort-Object Name -Descending|Select-Object -First 100){
        try{
            Assert-NoLink $dir.FullName;$m=Get-Content -LiteralPath (Join-Path $dir.FullName 'manifest.json') -Raw -Encoding UTF8|ConvertFrom-Json
            $rows+=@([pscustomobject]@{id=$dir.Name;at=$m.at;files=@($m.files).Count;bytes=($m.files|Measure-Object -Property size -Sum).Sum})
        }catch{$rows+=@([pscustomobject]@{id=$dir.Name;at='';files=0;bytes=0;error='Manifeste illisible'})}
    }
    return $rows
}
function New-Backup($automatic=$false){
    Ensure-Backup
    if(Test-Path -LiteralPath (File-Path 'transactions/pending.json')){throw 'Terminez la reprise des fichiers avant sauvegarde'}
    $script:state.backup.lastAttempt=[DateTimeOffset]::Now.ToString('o');Save-State
    $snapshotSequence=$script:sequence;$now=[DateTimeOffset]::Now;$id='ACC-'+$now.ToString('yyyyMMdd-HHmmss')+'-'+[Guid]::NewGuid().ToString('N').Substring(0,8)
    try{
        $destination=Backup-Destination $script:state.backup.directory
        [IO.Directory]::CreateDirectory($destination)|Out-Null
        $partial=Join-Path $destination ('.partial-'+$id);$payload=Join-Path $partial 'payload'
        [IO.Directory]::CreateDirectory($payload)|Out-Null
        $entries=@()
        foreach($source in @([pscustomobject]@{path=$store;prefix='TEST-DATA'},[pscustomobject]@{path=(File-Path '');prefix='TEST-FILES'})){
            foreach($file in @(Tree-Files $source.path)){
                $relative=Backup-Relative $source.path $file.FullName
                if($source.prefix -eq 'TEST-DATA' -and $relative -eq 'server.lock'){continue}
                $rel=$source.prefix+'/'+$relative;$target=Backup-Child $payload $rel
                [IO.Directory]::CreateDirectory([IO.Path]::GetDirectoryName($target))|Out-Null
                $before=Backup-Hash $file.FullName
                [IO.File]::Copy($file.FullName,$target,$false)
                $after=Backup-Hash $file.FullName;$copied=Backup-Hash $target
                if($before -ne $after -or $before -ne $copied){throw 'Un fichier a changé pendant la sauvegarde : réessayez après la fin des modifications'}
                $entries+=@([pscustomobject]@{path=$rel;size=(Get-Item -LiteralPath $target).Length;sha256=$copied})
            }
        }
        $manifest=[pscustomobject]@{format='ACCESSIBILITE-BACKUP-1';application='0.4-test';id=$id;at=$now.ToString('o');sequence=$snapshotSequence;files=@($entries)}
        Write-Durable (Join-Path $partial 'manifest.json') ([Text.Encoding]::UTF8.GetBytes(($manifest|ConvertTo-Json -Depth 10)))
        $verified=Verify-Backup $partial
        [IO.Directory]::Move($partial,(Join-Path $destination $id))
        $script:state.backup.lastSuccess=$now.ToString('o');$script:state.backup.lastId=$id;$script:state.backup.lastError=''
        $script:state.backup.automaticDay=(Get-Date -Format 'yyyy-MM-dd')
        Event 'SAUVEGARDE_COMPLETE' '' ("Sauvegarde vérifiée : $id ; $($verified.files) fichiers")
        Save-State;return $verified
    }catch{
        $message=$_.Exception.Message;$script:state.backup.lastError=$message
        Event 'ECHEC_SAUVEGARDE' '' $message
        try{Save-State}catch{Write-Warning 'Impossible de journaliser cet échec de sauvegarde'}
        throw
    }
}
function Maybe-Backup {
    Ensure-Backup
    $day=Get-Date -Format 'yyyy-MM-dd'
    if($script:state.backup.automaticDay -eq $day){return}
    if($script:lastAutomaticAttempt -and ([DateTimeOffset]::Now-$script:lastAutomaticAttempt).TotalMinutes -lt 30){return}
    $script:lastAutomaticAttempt=[DateTimeOffset]::Now;$previousActor=$script:actor;$script:actor='SYSTEME'
    try{New-Backup $true|Out-Null}catch{Write-Warning ('Sauvegarde complète en échec : '+$_.Exception.Message)}finally{$script:actor=$previousActor}
}
function Backup-Request($p){
    $script:actor=[string]$p.actor
    if(-not (Is-Manager $script:actor)){throw 'Sauvegardes réservées au manager ou suppléant'}
    Ensure-Backup
    switch([string]$p.operation){
        'create' {return (New-Backup)}
        'configure' {
            if([int]$p.version -ne [int]$script:state.backup.version){throw 'Paramètre modifié ailleurs : actualisez'}
            $path=Backup-Destination ([string]$p.directory)
            $old=$script:state.backup.directory;$script:state.backup.directory=$path;$script:state.backup.automaticDay='';$script:state.backup.version++
            $script:state.backup.lastSuccess=$null;$script:state.backup.lastId=$null;$script:state.backup.lastError='';$script:lastAutomaticAttempt=$null
            Event 'DESTINATION_SAUVEGARDE' '' ("Ancien : $old ; nouveau : $path")
            Save-State;return @{configured=$true}
        }
        'list' {return @{items=@(List-Backups)}}
        'verify' {
            if([string]$p.id -notmatch '^ACC-[0-9]{8}-[0-9]{6}-[a-f0-9]{8}$'){throw 'Identifiant de sauvegarde invalide'}
            $result=Verify-Backup (Join-Path (Backup-Destination $script:state.backup.directory) $p.id)
            Event 'VERIFICATION_SAUVEGARDE' '' ([string]$p.id);Save-State;return $result
        }
        default {throw 'Opération de sauvegarde inconnue'}
    }
}
function Restore-NewFolder($backupDirectory,$destination,$applicationRoot){
    $check=Verify-Backup $backupDirectory
    if(-not [IO.Path]::IsPathRooted($destination)){throw 'Destination de restauration absolue requise'}
    $target=Full-Path $destination
    if(Test-Path -LiteralPath $target){throw 'La destination doit être un nouveau dossier inexistant ; aucun écrasement autorisé'}
    Assert-NoLink $target
    if((Inside-Path $target $backupDirectory) -or (Inside-Path $backupDirectory $target)){throw 'Destination séparée de la sauvegarde requise'}
    $stage=$target+'.restauration-'+[Guid]::NewGuid().ToString('N')
    [IO.Directory]::CreateDirectory($stage)|Out-Null
    $payload=Join-Path $backupDirectory 'payload'
    foreach($file in @(Tree-Files $payload)){
        $relative=Backup-Relative $payload $file.FullName;$output=Backup-Child $stage $relative
        [IO.Directory]::CreateDirectory([IO.Path]::GetDirectoryName($output))|Out-Null;[IO.File]::Copy($file.FullName,$output,$false)
    }
    # Vérifier la copie restaurée avant publication du nouveau dossier.
    $m=Get-Content -LiteralPath (Join-Path $backupDirectory 'manifest.json') -Raw -Encoding UTF8|ConvertFrom-Json
    foreach($entry in $m.files){if((Backup-Hash (Backup-Child $stage $entry.path)) -ne $entry.sha256){throw 'Échec de vérification après restauration'}}
    foreach($name in @('server.ps1','backup.ps1','Restaurer.ps1','seed.json','Lancer.cmd')){[IO.File]::Copy((Join-Path $applicationRoot $name),(Join-Path $stage $name),$false)}
    foreach($name in @('LIRE-MOI.md','VERIFICATION.md','RESTAURATION.md','INSTALLATION_CORRECTIF.txt','CAHIER_DES_CHARGES.md')){if(Test-Path -LiteralPath (Join-Path $applicationRoot $name)){[IO.File]::Copy((Join-Path $applicationRoot $name),(Join-Path $stage $name),$false)}}
    foreach($file in @(Tree-Files (Join-Path $applicationRoot 'web'))){$rel='web/'+(Backup-Relative (Join-Path $applicationRoot 'web') $file.FullName);$out=Backup-Child $stage $rel;[IO.Directory]::CreateDirectory([IO.Path]::GetDirectoryName($out))|Out-Null;[IO.File]::Copy($file.FullName,$out,$false)}
    # Nouvelle sauvegarde locale par défaut, sans réutiliser silencieusement une ancienne destination réseau.
    $commitsRestored=Join-Path $stage 'TEST-DATA/commits';$last=Get-ChildItem -LiteralPath $commitsRestored -Filter '*.json'|Sort-Object Name|Select-Object -Last 1
    $s=Get-Content -LiteralPath $last.FullName -Raw -Encoding UTF8|ConvertFrom-Json
    $s.backup.directory=Join-Path $target 'SAUVEGARDES';$s.backup.lastSuccess=$null;$s.backup.lastId=$null;$s.backup.automaticDay='';$s.backup.lastError='';$s.backup.version++
    foreach($d in $s.docs){if($d.active){$d.active=$false;$d.started=$null}}
    $s.events=@($s.events)+@([pscustomobject]@{id=[Guid]::NewGuid().ToString('N');at=[DateTime]::UtcNow.ToString('o');account=[Environment]::UserName;actor='SYSTEME';session='RESTAURATION';action='RESTAURATION_NOUVEAU_DOSSIER';document='';message=('Sauvegarde '+$check.id+' ; chronomètres en pause')})
    $next=[int]$last.BaseName+1;$jsonPath=Join-Path $commitsRestored ('{0:D12}.json' -f $next)
    [IO.File]::WriteAllText($jsonPath,($s|ConvertTo-Json -Depth 30),[Text.Encoding]::UTF8)
    [IO.Directory]::Move($stage,$target)
    return $target
}
