﻿param([int]$Port = 8090)
$ErrorActionPreference = 'Stop'
$root = $PSScriptRoot
. (Join-Path $root 'backup.ps1')
# Prototype exclusivement local. Aucun chemin client ni partage UNC accepté.
$store = Join-Path $root 'TEST-DATA'
$commits = Join-Path $store 'commits'
$backups = Join-Path $store 'backups'
New-Item -ItemType Directory -Force -Path $commits,$backups | Out-Null
$token = [Guid]::NewGuid().ToString('N')
$session = [Guid]::NewGuid().ToString('N')
$account = [Environment]::UserName
$script:state = $null
$script:sequence = 0
function Save-State {
    $next = $script:sequence + 1
    $tmp = Join-Path $commits ([Guid]::NewGuid().ToString('N') + '.tmp')
    $dest = Join-Path $commits ('{0:D12}.json' -f $next)
    $bytes = [Text.Encoding]::UTF8.GetBytes(($script:state | ConvertTo-Json -Depth 30))
    $f = [IO.File]::Open($tmp,[IO.FileMode]::CreateNew,[IO.FileAccess]::Write,[IO.FileShare]::None)
    try { $f.Write($bytes,0,$bytes.Length); $f.Flush($true) } finally { $f.Dispose() }
    [IO.File]::Move($tmp,$dest)
    $script:sequence = $next
}
function Event($action,$doc,$message) {
    $e = [pscustomobject]@{id=[Guid]::NewGuid().ToString('N');at=[DateTime]::UtcNow.ToString('o');account=$account;actor=$script:actor;session=$session;action=$action;document=$doc;message=$message}
    $script:state.events = @($script:state.events) + @($e)
}

function Ensure-Config {
    if(-not $script:state.PSObject.Properties['config']) {
        $defaults=Get-Content -LiteralPath (Join-Path $root 'seed.json') -Raw -Encoding UTF8 | ConvertFrom-Json
        if($null -eq $defaults.config){throw 'Installation incomplète : remplacez également seed.json et le dossier web par ceux de la v0.2'}
        $script:state | Add-Member -NotePropertyName config -NotePropertyValue $defaults.config
        Event 'MIGRATION_PARAMETRES' '' 'Ajout des paramètres ; documents et historique conservés'
    }
}
function Is-Manager($id) {
    return @($script:state.config.users | Where-Object {$_.id -eq $id -and $_.active -and $_.role -in @('manager','backup')}).Count -eq 1
}
function Active-Collaborators {
    return @($script:state.config.users | Where-Object {$_.active -and $_.role -eq 'collaborator'} | ForEach-Object {$_.id})
}
function Day-Rule($date) {
    if($date.DayOfWeek -in @('Saturday','Sunday') -or $date.ToString('yyyy-MM-dd') -in @($script:state.config.holidays)){return $null}
    if($date.DayOfWeek -eq 'Friday'){return $script:state.config.hours.friday}
    return $script:state.config.hours.standard
}
function Minute-OfDay($text) {
    if([string]$text -notmatch '^([01][0-9]|2[0-3]):[0-5][0-9]$'){throw 'Horaire invalide : utiliser HH:mm'}
    return ([int]$text.Substring(0,2))*60+[int]$text.Substring(3,2)
}
function Config-Integer($value,$min,$max,$label) {
    $n=0
    if(-not [int]::TryParse([string]$value,[ref]$n) -or $n -lt $min -or $n -gt $max){throw "$label : entier attendu entre $min et $max"}
    return $n
}
function Save-Config($p) {
    $script:actor=[string]$p.actor
    if(-not (Is-Manager $script:actor)){throw 'Paramètres réservés au manager ou suppléant'}
    $old=$script:state.config;$c=$p.config
    if($null -eq $c -or $null -eq $c.version -or [int]$c.version -ne [int]$old.version){throw 'Paramètres modifiés ailleurs. Rechargez avant de réessayer.'}
    if(@($c.users).Count -lt 1 -or @($c.users).Count -gt 100){throw 'Prévoir de 1 à 100 comptes'}
    $users=@();$ids=@()
    foreach($u in $c.users){
        $id=([string]$u.id).Trim().ToUpperInvariant();$name=([string]$u.name).Trim()
        if($id -notmatch '^[A-Z0-9][A-Z0-9_.-]{1,63}$' -or $id -eq 'SYSTEME'){throw 'Identifiant invalide : 2 à 64 caractères, lettres, chiffres, point, tiret ou soulignement'}
        if($id -in $ids){throw 'Identifiant de compte en double'};$ids+=@($id)
        if($name.Length -lt 2 -or $name.Length -gt 100){throw 'Nom du compte requis (2 à 100 caractères)'}
        if($u.active -isnot [bool] -or $u.role -notin @('manager','backup','collaborator')){throw 'Rôle ou activation du compte invalide'}
        if((-not $u.active -or $u.role -ne 'collaborator') -and @($script:state.docs|Where-Object {$_.owner -eq $id -and $_.status -ne 'TRAITES'}).Count){throw "Réaffectez les documents non terminés de $id avant désactivation ou changement de rôle"}
        $users+=@([pscustomobject]@{id=$id;name=$name;role=[string]$u.role;active=[bool]$u.active})
    }
    foreach($u in $old.users){if($u.id -notin $ids){throw 'Les comptes historiques ne peuvent être supprimés : utilisez Désactiver'}}
    if(@($users|Where-Object {$_.id -eq $script:actor -and $_.active -and $_.role -in @('manager','backup')}).Count -ne 1){throw 'Conservez votre propre accès manager pour éviter un verrouillage'}
    if(@($users|Where-Object {$_.active -and $_.role -eq 'manager'}).Count -lt 1){throw 'Un manager actif est obligatoire'}
    if(@($c.entities).Count -lt 1 -or @($c.entities).Count -gt 100){throw 'Prévoir de 1 à 100 entités'}
    $entities=@();$entityIds=@()
    foreach($e in $c.entities){
        $id=([string]$e.id).Trim().ToUpperInvariant()
        if($id -notmatch '^[\p{L}\p{N}][\p{L}\p{N} _.-]{0,63}$' -or $e.active -isnot [bool]){throw 'Nom ou activation de cette entité invalide'}
        if($id -in $entityIds){throw 'Entité en double'};$entityIds+=@($id)
        if(-not $e.active -and @($script:state.docs|Where-Object {$_.entity -eq $id -and $_.status -ne 'TRAITES'}).Count){throw "Terminez les documents de $id avant désactivation"}
        $entities+=@([pscustomobject]@{id=$id;active=[bool]$e.active})
    }
    foreach($e in $old.entities){if($e.id -notin $entityIds){throw 'Les entités historiques ne peuvent être supprimées : utilisez Désactiver'}}
    $hours=[ordered]@{}
    foreach($key in @('standard','friday')){
        $h=$c.hours.$key;$start=Minute-OfDay $h.start;$end=Minute-OfDay $h.end
        $pause=Config-Integer $h.pauseMinutes 0 600 'Pause';$lunch=Config-Integer $h.lunchMinutes 0 600 'Déjeuner'
        if($end -le $start -or ($pause+$lunch) -ge ($end-$start)){throw 'La plage horaire doit être positive et supérieure aux pauses cumulées'}
        $hours[$key]=[pscustomobject]@{start=[string]$h.start;end=[string]$h.end;pauseMinutes=$pause;lunchMinutes=$lunch}
    }
    if(@($c.holidays).Count -gt 500){throw 'Maximum 500 jours de fermeture'}
    $holidays=@()
    foreach($day in $c.holidays){
        $date=[datetime]::MinValue
        if([string]$day -notmatch '^\d{4}-\d{2}-\d{2}$' -or -not [datetime]::TryParseExact([string]$day,'yyyy-MM-dd',[Globalization.CultureInfo]::InvariantCulture,[Globalization.DateTimeStyles]::None,[ref]$date)){throw 'Date de fermeture invalide : AAAA-MM-JJ'}
        if($day -in $holidays){throw 'Date de fermeture en double'};$holidays+=@([string]$day)
    }
    $calendarChanged=(($hours|ConvertTo-Json -Compress) -ne ($old.hours|ConvertTo-Json -Compress)) -or ((@($holidays|Sort-Object)|ConvertTo-Json -Compress) -ne (@($old.holidays|Sort-Object)|ConvertTo-Json -Compress))
    if($calendarChanged -and @($script:state.docs|Where-Object {$_.active}).Count){throw 'Mettez tous les chronomètres en pause avant de changer les horaires ou fermetures'}
    if(@($c.estimates).Count -gt 100){throw 'Maximum 100 temps de référence'}
    $estimates=@();$estimateIds=@();$pairs=@()
    foreach($e in $c.estimates){
        $id=([string]$e.id).Trim().ToUpperInvariant();$nature=([string]$e.nature).Trim();$entity=([string]$e.entity).Trim().ToUpperInvariant()
        if($id -notmatch '^[A-Z0-9_-]{1,64}$' -or $id -in $estimateIds){throw 'Identifiant de temps de référence invalide ou en double'};$estimateIds+=@($id)
        if($nature.Length -lt 2 -or $nature.Length -gt 100 -or ($entity -ne '*' -and $entity -notin $entityIds)){throw 'Nature ou entité du temps de référence invalide'}
        $pair=$entity+'|'+$nature.ToUpperInvariant();if($pair -in $pairs){throw 'Temps de référence en double pour cette entité et nature'};$pairs+=@($pair)
        $minutes=Config-Integer $e.minutes 1 60000 'Temps de référence (minutes)'
        $estimates+=@([pscustomobject]@{id=$id;nature=$nature;entity=$entity;minutes=$minutes})
    }
    $config=[pscustomobject]@{version=([int]$old.version+1);users=@($users);entities=@($entities);hours=[pscustomobject]$hours;holidays=@($holidays|Sort-Object);estimates=@($estimates)}
    $script:state.config=$config
    Event 'PARAMETRES_MODIFIES' '' 'Mise à jour des paramètres de cette activité'
    $event=$script:state.events[-1]
    $event|Add-Member -NotePropertyName before -NotePropertyValue $old
    $event|Add-Member -NotePropertyName after -NotePropertyValue $config
    Save-State
}

# Fichiers locaux de test uniquement. Aucune entrée API ne désigne un chemin absolu.
function File-Path($relative) {
    $base=[IO.Path]::GetFullPath((Join-Path $root 'TEST-FILES'))
    $full=[IO.Path]::GetFullPath((Join-Path $base $relative))
    $comparison=[StringComparison]::Ordinal;if([IO.Path]::DirectorySeparatorChar -eq [char]92){$comparison=[StringComparison]::OrdinalIgnoreCase}
    if(-not $full.Equals($base,$comparison) -and -not $full.StartsWith($base+[IO.Path]::DirectorySeparatorChar,$comparison)){throw 'Chemin hors espace de test refusé'}
    $cursor=$full
    while($cursor.Length -ge $base.Length){
        if(Test-Path -LiteralPath $cursor){if((Get-Item -LiteralPath $cursor -Force).Attributes -band [IO.FileAttributes]::ReparsePoint){throw 'Lien symbolique ou jonction interdit dans les fichiers de test'}}
        if($cursor.Equals($base,$comparison)){break};$cursor=[IO.Path]::GetDirectoryName($cursor)
    }
    return $full
}
function Write-Durable($path,[byte[]]$bytes) {
    $f=[IO.File]::Open($path,[IO.FileMode]::CreateNew,[IO.FileAccess]::Write,[IO.FileShare]::None)
    try{$f.Write($bytes,0,$bytes.Length);$f.Flush($true)}finally{$f.Dispose()}
}
function Init-Files {
    foreach($dir in @('','A TRAITER','EN COURS','NON CONFORME','TRAITES','Historique','staging','transactions')){[IO.Directory]::CreateDirectory((File-Path $dir))|Out-Null}
}
function File-Hash($path){return (Get-FileHash -LiteralPath $path -Algorithm SHA256).Hash}
function Read-Uploads($uploads,$kind,$needsWord=$false) {
    if(@($uploads).Count -lt 1 -or @($uploads).Count -gt 3){throw 'Sélectionnez les fichiers du document (trois maximum)'}
    $files=@();$types=@();$total=0
    foreach($u in $uploads){
        $name=[string]$u.name
        if($name.Length -lt 1 -or $name.Length -gt 100 -or $name -match '[<>:"/\\|?*\x00-\x1F]' -or $name -match '[ .]$' -or $name -match '^(CON|PRN|AUX|NUL|COM[1-9]|LPT[1-9])(\.|$)'){throw 'Nom de fichier Windows invalide ou trop long (100 caractères maximum)'}
        $ext=[IO.Path]::GetExtension($name).ToLowerInvariant()
        if($ext -notin @('.pdf','.docx','.xlsx') -or ($kind -eq 'source' -and $ext -eq '.xlsx')){throw 'Formats acceptés : PDF et DOCX en source ; PDF, DOCX et XLSX pour les livrables'}
        if($ext -in $types){throw 'Un seul fichier par format est accepté pour un document'};$types+=@($ext)
        $bytes=[Convert]::FromBase64String([string]$u.base64);$total+=$bytes.Length
        if($bytes.Length -eq 0 -or $bytes.Length -gt 10MB -or $total -gt 12MB){throw 'Limite de test : 10 Mo par fichier, 12 Mo par envoi ; fichier vide refusé'}
        if($ext -eq '.pdf'){
            if($bytes.Length -lt 8 -or [Text.Encoding]::ASCII.GetString($bytes,0,5) -ne '%PDF-'){throw 'Le fichier ne contient pas une signature PDF'}
        }else{
            Add-Type -AssemblyName System.IO.Compression
            $memory=[IO.MemoryStream]::new($bytes,$false);$zip=$null
            try{
                $zip=[IO.Compression.ZipArchive]::new($memory,[IO.Compression.ZipArchiveMode]::Read,$false)
                $required='word/document.xml';if($ext -eq '.xlsx'){$required='xl/workbook.xml'}
                if($null -eq $zip.GetEntry('[Content_Types].xml') -or $null -eq $zip.GetEntry($required)){throw 'Structure Office invalide'}
                if($zip.Entries.Count -gt 10000 -or ($zip.Entries|Measure-Object -Property Length -Sum).Sum -gt 100MB){throw 'Archive Office trop volumineuse après décompression'}
            }catch{throw 'DOCX ou XLSX invalide, chiffré ou trop volumineux'}finally{if($zip){$zip.Dispose()}else{$memory.Dispose()}}
        }
        $sha=[Security.Cryptography.SHA256]::Create();try{$hash=([BitConverter]::ToString($sha.ComputeHash($bytes))).Replace('-','')}finally{$sha.Dispose()}
        $files+=@([pscustomobject]@{name=$name;ext=$ext;bytes=$bytes;size=$bytes.Length;sha256=$hash})
    }
    if($kind -eq 'package' -and ('.pdf' -notin $types -or '.xlsx' -notin $types -or ($needsWord -and '.docx' -notin $types))){throw 'Livrables incomplets : PDF et audit XLSX obligatoires, plus DOCX si origine Word'}
    if($kind -eq 'source' -and $needsWord -and '.docx' -notin $types){throw 'La correction doit inclure le DOCX car le document initial comporte un Word'}
    return $files
}
function Store-Uploads($relative,$files) {
    $dir=File-Path $relative;[IO.Directory]::CreateDirectory($dir)|Out-Null
    foreach($f in $files){Write-Durable (File-Path ($relative+'/'+$f.name)) $f.bytes}
}
function Upload-Metadata($files){return @($files|ForEach-Object {[pscustomobject]@{name=$_.name;size=$_.size;sha256=$_.sha256;ext=$_.ext}})}
function Move-Spec($from,$to){return [pscustomobject]@{from=$from;to=$to}}
function Save-FileManifest($tx) {
    $path=File-Path 'transactions/pending.json';$tmp=File-Path ('transactions/'+[Guid]::NewGuid().ToString('N')+'.tmp')
    Write-Durable $tmp ([Text.Encoding]::UTF8.GetBytes(($tx|ConvertTo-Json -Depth 10)))
    if(Test-Path -LiteralPath $path){[IO.File]::Replace($tmp,$path,(File-Path ('transactions/'+[Guid]::NewGuid().ToString('N')+'.bak')))}else{[IO.File]::Move($tmp,$path)}
}
function Resolve-FileTransaction {
    $pending=File-Path 'transactions/pending.json';if(-not (Test-Path -LiteralPath $pending)){return}
    $tx=Get-Content -LiteralPath $pending -Raw -Encoding UTF8|ConvertFrom-Json
    $committed=@($script:state.events|Where-Object {$_.PSObject.Properties['fileTransaction'] -and $_.fileTransaction -eq $tx.id}).Count -gt 0
    if(-not $committed){
        if($tx.phase -eq 'forward'){
            if($tx.done -lt @($tx.moves).Count){
                $m=$tx.moves[$tx.done];$hasFrom=Test-Path -LiteralPath (File-Path $m.from);$hasTo=Test-Path -LiteralPath (File-Path $m.to)
                if(-not $hasFrom -and $hasTo){$tx.done++}
                elseif(-not ($hasFrom -and -not $hasTo)){throw 'Conflit fichiers pendant reprise : aucune suppression automatique. Diagnostic requis.'}
            }
            $tx.phase='rollback';Save-FileManifest $tx
        }
        while($tx.done -gt 0){
            $m=$tx.moves[$tx.done-1];$from=File-Path $m.from;$to=File-Path $m.to
            $hasFrom=Test-Path -LiteralPath $from;$hasTo=Test-Path -LiteralPath $to
            if($hasTo -and -not $hasFrom){[IO.Directory]::CreateDirectory([IO.Path]::GetDirectoryName($from))|Out-Null;[IO.Directory]::Move($to,$from)}
            elseif(-not ($hasFrom -and -not $hasTo)){throw 'Conflit fichiers pendant annulation : diagnostic requis'}
            $tx.done--;Save-FileManifest $tx
        }
    }
    [IO.File]::Move($pending,(File-Path ('transactions/'+$tx.id+'-'+$(if($committed){'valide'}else{'annule'})+'.json')))
}
function Commit-Files($moves,$event) {
    if(Test-Path -LiteralPath (File-Path 'transactions/pending.json')){throw 'Une transaction fichiers attend sa reprise : redémarrez le serveur'}
    if(@($moves).Count -eq 0){Save-State;return}
    # Prévalidation séquentielle : une destination peut être libérée par une étape précédente.
    $exists=@{}
    foreach($m in $moves){
        foreach($key in @($m.from,$m.to)){if(-not $exists.ContainsKey($key)){$exists[$key]=Test-Path -LiteralPath (File-Path $key)}}
        if(-not $exists[$m.from] -or $exists[$m.to]){throw 'Déplacement refusé : source absente ou destination déjà occupée'}
        $exists[$m.from]=$false;$exists[$m.to]=$true
    }
    $tx=[pscustomobject]@{id=[Guid]::NewGuid().ToString('N');moves=@($moves);done=0;phase='forward';at=[DateTime]::UtcNow.ToString('o')}
    Save-FileManifest $tx
    try{
        foreach($m in $tx.moves){
            $from=File-Path $m.from;$to=File-Path $m.to
            if(-not (Test-Path -LiteralPath $from -PathType Container) -or (Test-Path -LiteralPath $to)){throw 'Source absente ou destination occupée pendant déplacement'}
            [IO.Directory]::CreateDirectory([IO.Path]::GetDirectoryName($to))|Out-Null;[IO.Directory]::Move($from,$to)
            $tx.done++;Save-FileManifest $tx
        }
        $event|Add-Member -NotePropertyName fileTransaction -NotePropertyValue $tx.id
        Save-State
    }catch{
        $last=Get-ChildItem -LiteralPath $commits -Filter '*.json'|Sort-Object Name|Select-Object -Last 1
        $script:state=Get-Content -LiteralPath $last.FullName -Raw -Encoding UTF8|ConvertFrom-Json
        Resolve-FileTransaction
        throw
    }
    try{Resolve-FileTransaction}catch{Write-Warning 'Transaction enregistrée ; manifeste à finaliser au redémarrage'}
}
function Check-Package($d) {
    if(-not $d.packageReady -or @($d.finalFiles).Count -lt 2){throw 'Livrables non déposés'}
    $types=@()
    foreach($f in $d.finalFiles){$path=File-Path ($d.status+'/'+$d.id+'/Livrables/'+$f.name);if(-not (Test-Path -LiteralPath $path -PathType Leaf) -or (File-Hash $path) -ne $f.sha256){throw 'Livrable absent ou modifié depuis son dépôt. Déposez à nouveau le dossier final.'};$types+=@($f.ext)}
    if('.pdf' -notin $types -or '.xlsx' -notin $types -or ($d.word -and '.docx' -notin $types)){throw 'Dossier final incomplet'}
}
function File-Request($p) {
    $script:actor=[string]$p.actor;$manager=Is-Manager $script:actor
    if(@($script:state.config.users|Where-Object {$_.id -eq $script:actor -and $_.active}).Count -ne 1){throw 'Compte de test inconnu'}
    if($p.operation -eq 'import'){
        if(-not $manager){throw 'Import réservé au manager ou suppléant'}
        if(@($script:state.config.entities|Where-Object {$_.id -eq $p.entity -and $_.active}).Count -ne 1){throw 'Entité inactive ou inconnue'}
        $nature=([string]$p.nature).Trim();if($nature.Length -lt 2 -or $nature.Length -gt 100){throw 'Nature requise (2 à 100 caractères)'}
        $files=@(Read-Uploads $p.files 'source');$id='F-'+[Guid]::NewGuid().ToString('N').Substring(0,16)
        $d=[pscustomobject]@{id=$id;name=[IO.Path]::GetFileNameWithoutExtension($files[0].name);entity=[string]$p.entity;nature=$nature;word=('.docx' -in @($files.ext));owner='';status='A TRAITER';priority='Normale';stage=0;seconds=0;stageSeconds=@(0,0,0,0);started=$null;active=$false;packageReady=$false;reason='';finished=$null;published=$false;wasPublished=$false;reworks=0;version=1;physical=$true;received=[DateTimeOffset]::Now.ToString('o');sourceVersion=1;sourceFiles=@(Upload-Metadata $files);finalFiles=@()}
        $stage='staging/'+[Guid]::NewGuid().ToString('N')
        Store-Uploads ($stage+'/Archive') $files;Store-Uploads ($stage+'/Work/Source') $files
        $moves=@((Move-Spec ($stage+'/Archive') ('Historique/'+$id+'/V001')),(Move-Spec ($stage+'/Work') ('A TRAITER/'+$id)))
        $script:state.docs=@($script:state.docs)+@($d);Event 'IMPORT_FICHIERS' $id 'Import de copies locales ; original archivé'
        $script:state.events[-1]|Add-Member -NotePropertyName after -NotePropertyValue (($d|ConvertTo-Json -Depth 15)|ConvertFrom-Json)
        Commit-Files $moves $script:state.events[-1];return
    }
    $d=@($script:state.docs|Where-Object {$_.id -eq $p.id})
    if($d.Count -ne 1 -or -not $d[0].physical){throw 'Document physique introuvable'};$d=$d[0]
    if([int]$d.version -ne [int]$p.version){throw 'Document modifié : actualisez avant de déposer les fichiers'}
    $previous=$d|ConvertTo-Json -Depth 15
    $stage='staging/'+[Guid]::NewGuid().ToString('N');$moves=@()
    if($p.operation -eq 'package'){
        if($d.owner -ne $script:actor -or $d.status -ne 'EN COURS'){throw 'Livrables réservés au collaborateur en charge'}
        $files=@(Read-Uploads $p.files 'package' $d.word);Store-Uploads ($stage+'/Final') $files
        $destination=$d.status+'/'+$d.id+'/Livrables'
        if(Test-Path -LiteralPath (File-Path $destination)){$moves+=@(Move-Spec $destination ('Historique/'+$d.id+'/Final-'+[Guid]::NewGuid().ToString('N')))}
        $moves+=@(Move-Spec ($stage+'/Final') $destination);$d.finalFiles=@(Upload-Metadata $files);$d.packageReady=$true
        $action='DEPOT_LIVRABLES';$message='PDF, audit et Word si requis déposés ; contrôle de structure minimal'
    }elseif($p.operation -eq 'return'){
        if(-not $manager -or $d.status -ne 'NON CONFORME'){throw 'Retour corrigé réservé au manager sur un document non conforme'}
        $files=@(Read-Uploads $p.files 'source' $d.word);Store-Uploads ($stage+'/Archive') $files;Store-Uploads ($stage+'/Work/Source') $files
        $d.sourceVersion++;$archive='Historique/'+$d.id+('/V{0:D3}' -f [int]$d.sourceVersion)
        $moves+=@((Move-Spec ($d.status+'/'+$d.id) ('Historique/'+$d.id+'/Travail-'+[Guid]::NewGuid().ToString('N'))),(Move-Spec ($stage+'/Archive') $archive),(Move-Spec ($stage+'/Work') ('A TRAITER/'+$d.id)))
        $d.status='A TRAITER';$d.word=$d.word -or ('.docx' -in @($files.ext));$d.reworks++;$d.packageReady=$false;$d.finalFiles=@();$d.sourceFiles=@(Upload-Metadata $files);$d.finished=$null;$d.reason='Retour corrigé importé';$action='RETOUR_FICHIERS';$message='Nouvelle version source archivée ; date du premier dépôt conservée'
    }else{throw 'Opération fichier inconnue'}
    $d.version++;Event $action $d.id $message
    $event=$script:state.events[-1];$event|Add-Member -NotePropertyName before -NotePropertyValue ($previous|ConvertFrom-Json);$event|Add-Member -NotePropertyName after -NotePropertyValue (($d|ConvertTo-Json -Depth 15)|ConvertFrom-Json)
    Commit-Files $moves $event
}

function Charge($d,$until) {
    if (-not $d.started) { return }
    $start = [DateTimeOffset]::Parse($d.started)
    $seconds = [Math]::Max(0,($until - $start).TotalSeconds)
    $d.seconds = [double]$d.seconds + $seconds
    $d.stageSeconds[$d.stage] = [double]$d.stageSeconds[$d.stage] + $seconds
    $d.started = $until.ToString('o')
}
function Tick {
    if(Test-Path -LiteralPath (File-Path 'transactions/pending.json')){return}
    $changed=$false; $now=[DateTimeOffset]::Now
    foreach($d in $script:state.docs) {
        if($d.started) {
            $start=[DateTimeOffset]::Parse($d.started)
            $rule=Day-Rule $start.LocalDateTime
            $endMinute=0;if($null -ne $rule){$endMinute=Minute-OfDay $rule.end}
            $cut=[DateTimeOffset]($start.LocalDateTime.Date.AddMinutes($endMinute))
            if($now -ge $cut) { Charge $d $cut; $d.started=$null; $d.active=$false; $savedActor=$script:actor;try{$script:actor='SYSTEME';Event 'ARRET_HORAIRE' $d.id 'Arrêt à la fin de journée'}finally{$script:actor=$savedActor}; }
            else { Charge $d $now }
            $changed=$true
        }
    }
    if($changed){ Save-State }
    $daily=Join-Path $backups ((Get-Date -Format 'yyyy-MM-dd')+'.json')
    if(-not (Test-Path -LiteralPath $daily)) {
        $source=Join-Path $commits ('{0:D12}.json' -f $script:sequence)
        $temp=$daily+'.tmp';[IO.File]::Copy($source,$temp,$true);[IO.File]::Move($temp,$daily)
    }
}
function Begin-Work($d,$user) {
    if(@($script:state.docs | Where-Object {$_.owner -eq $user -and $_.active}).Count -gt 0){throw 'Un document est déjà actif pour ce collaborateur. Mettre en pause avant de continuer.'}
    $now=Get-Date
    $rule=Day-Rule $now
    if($null -eq $rule){throw 'Hors horaires : week-end ou jour de fermeture.'}
    $minute=$now.Hour*60+$now.Minute
    if($minute -lt (Minute-OfDay $rule.start) -or $minute -ge (Minute-OfDay $rule.end)){throw 'Hors horaires configurés. Le jeu reste consultable, mais le chrono reste arrêté.'}
    $d.owner=$user;$d.status='EN COURS';$d.active=$true;$d.started=[DateTimeOffset]::Now.ToString('o')
}
function Action($p) {
    $script:actor=[string]$p.actor
    if(@($script:state.config.users|Where-Object {$_.id -eq $script:actor -and $_.active}).Count -ne 1){throw 'Compte de test inconnu'}
    $d=@($script:state.docs | Where-Object {$_.id -eq $p.id})
    if($d.Count -ne 1){throw 'Document introuvable'};$d=$d[0]
    if([int]$p.version -ne [int]$d.version){throw 'Ce document a changé. Actualisez avant de réessayer.'}
    $manager=Is-Manager $script:actor
    $own=$d.owner -eq $script:actor
    $reason=[string]$p.reason
    $previous=$d | ConvertTo-Json -Depth 10 -Compress
    $oldStatus=$d.status;$moves=@()
    if($d.physical -and $p.action -in @('return','package','publish')){throw 'Utilisez le dépôt de vrais fichiers pour ce document. La publication physique sera ajoutée dans un prochain module.'}
    if($d.physical -and $p.action -eq 'close'){Check-Package $d}
    switch([string]$p.action) {
        'assign' {if(-not $manager){throw 'Réservé au manager'};if($d.active){throw 'Mettre le document en pause avant réaffectation'};if($p.owner -notin @(Active-Collaborators)){throw 'Collaborateur invalide'};$d.owner=[string]$p.owner;if($p.priority -notin @('Normale','Haute','Urgente')){throw 'Priorité invalide'};$d.priority=$p.priority}
        'take' {if($manager){throw 'Sélectionnez un collaborateur de test'};if($d.status -ne 'A TRAITER'){throw 'Document indisponible'};if($d.owner -and -not $own){throw 'Document réservé à un autre collaborateur'};Begin-Work $d $script:actor}
        'pause' {if(-not ($own -or $manager) -or -not $d.active){throw 'Pause non autorisée'};$d.started=$null;$d.active=$false}
        'resume' {if(-not $own -or $d.status -ne 'EN COURS' -or $d.active){throw 'Reprise non autorisée'};Begin-Work $d $script:actor}
        'stage' {if(-not $own -or -not $d.active){throw 'Un traitement actif à votre nom est nécessaire'};if([int]$p.stage -lt 0 -or [int]$p.stage -gt 3){throw 'Étape invalide'};$d.stage=[int]$p.stage}
        'block' {if(-not ($own -or $manager) -or $d.status -notin @('EN COURS','A TRAITER')){throw 'Blocage non autorisé'};if(-not $reason.Trim()){throw 'Motif obligatoire'};$d.status='NON CONFORME';$d.active=$false;$d.started=$null;$d.reason=$reason}
        'return' {if(-not $manager -or $d.status -ne 'NON CONFORME'){throw 'Retour réservé au manager sur un document non conforme'};$d.status='A TRAITER';$d.reworks++;$d.packageReady=$false;$d.reason='Retour corrigé simulé'}
        'package' {if(-not $own -or $d.status -ne 'EN COURS'){throw 'Simulation réservée au collaborateur affecté'};$d.packageReady=$true}
        'close' {if(-not $own -or $d.status -ne 'EN COURS'){throw 'Clôture non autorisée'};if(-not $d.packageReady){throw 'Dossier de test incomplet : simulez PDF + audit et Word final si applicable'};$d.started=$null;$d.active=$false;$d.status='TRAITES';$d.finished=[DateTimeOffset]::Now.ToString('o');if($d.wasPublished){$d.published=$true}}
        'reopen' {if(-not $manager -or $d.status -ne 'TRAITES'){throw 'Réouverture réservée au manager'};if(-not $reason.Trim()){throw 'Motif obligatoire'};$d.wasPublished=$d.published;$d.published=$false;$d.packageReady=$false;$d.status='A TRAITER';$d.reason=$reason;$d.reworks++}
        'publish' {if(-not $manager -or $d.entity -ne 'ACM' -or $d.status -ne 'TRAITES'){throw 'Publication réservée aux ACM traités'};$d.published=$true}
        default {throw 'Action inconnue'}
    }
    $d.version++;Event ([string]$p.action).ToUpperInvariant() $d.id $reason
    $event=$script:state.events[-1]
    $event | Add-Member -NotePropertyName before -NotePropertyValue ($previous | ConvertFrom-Json)
    $event | Add-Member -NotePropertyName after -NotePropertyValue (($d | ConvertTo-Json -Depth 10 -Compress) | ConvertFrom-Json)
    if($d.physical){
        if($p.action -eq 'reopen'){
            $final=$oldStatus+'/'+$d.id+'/Livrables'
            if(Test-Path -LiteralPath (File-Path $final)){$moves+=@(Move-Spec $final ('Historique/'+$d.id+'/Final-'+[Guid]::NewGuid().ToString('N')))}
            $d.finalFiles=@();$d.finished=$null
            $event.after=$d|ConvertTo-Json -Depth 15|ConvertFrom-Json
        }
        if($oldStatus -ne $d.status){$moves+=@(Move-Spec ($oldStatus+'/'+$d.id) ($d.status+'/'+$d.id))}
        Commit-Files $moves $event
    }else{Save-State}
}
$lock=$null;$listener=$null
try {
    try{$lock=[IO.File]::Open((Join-Path $store 'server.lock'),[IO.FileMode]::OpenOrCreate,[IO.FileAccess]::ReadWrite,[IO.FileShare]::None)}catch{throw 'Une instance utilise déjà ce jeu de test. Fermez-la ou utilisez un autre dossier de test.'}
    $last=Get-ChildItem -LiteralPath $commits -Filter '*.json' | Sort-Object Name | Select-Object -Last 1
    $script:actor='SYSTEME'
    if($last){$script:state=Get-Content -LiteralPath $last.FullName -Raw -Encoding UTF8 | ConvertFrom-Json;$script:sequence=[int]$last.BaseName;Init-Files;Resolve-FileTransaction;foreach($d in $script:state.docs){if($d.active){$d.active=$false;$d.started=$null;Event 'REDEMARRAGE_PAUSE' $d.id 'Temps conservé au dernier point sauvegardé'}};Ensure-Config;Save-State}
    else{$script:state=Get-Content -LiteralPath (Join-Path $root 'seed.json') -Raw -Encoding UTF8 | ConvertFrom-Json;Init-Files;Ensure-Config;Event 'INITIALISATION_TEST' '' 'Données fictives';Save-State}
    Ensure-Backup
    $listener=[Net.Sockets.TcpListener]::new([Net.IPAddress]::Loopback,$Port);$listener.Start()
    $url="http://127.0.0.1:$Port/"
    Write-Host "ACCESSIBILITE v0.4 TEST - $url - Compte Windows : $account"
    Write-Host 'Aucun dossier client connecté. Ctrl+C pour arrêter. Ne fermez pas cette fenêtre pendant le test.'
    Start-Process $url
    $nextTick=[DateTime]::UtcNow
    while($true){
        if([DateTime]::UtcNow -ge $nextTick){$script:actor='SYSTEME';Tick;Maybe-Backup;$nextTick=[DateTime]::UtcNow.AddSeconds(5)}
        if(-not $listener.Pending()){Start-Sleep -Milliseconds 100;continue}
        $client=$listener.AcceptTcpClient();$stream=$client.GetStream();$stream.ReadTimeout=15000;$stream.WriteTimeout=3000
        try {
            $head=New-Object 'System.Collections.Generic.List[byte]'
            while($true){$b=$stream.ReadByte();if($b -lt 0){throw 'Requête interrompue'};$head.Add([byte]$b);$n=$head.Count;if($n -gt 16384){throw 'En-têtes trop grands'};if($n -ge 4 -and $head[$n-4] -eq 13 -and $head[$n-3] -eq 10 -and $head[$n-2] -eq 13 -and $head[$n-1] -eq 10){break}}
            # PowerShell 5.1 : éviter les surcharges ambiguës de String.Split.
            $lines = [Text.Encoding]::ASCII.GetString($head.ToArray()) -split "`r`n"
            $request = $lines[0] -split ' ', 3
            if ($request.Count -ne 3) { throw 'Ligne HTTP invalide' }
            $method = $request[0]
            $path = ($request[1] -split '\?', 2)[0]
            $headers = @{}
            foreach ($line in $lines[1..($lines.Length-1)]) {
                $colon = $line.IndexOf(':')
                if ($colon -gt 0) {
                    $headerName = $line.Substring(0, $colon).Trim().ToLowerInvariant()
                    $headerValue = $line.Substring($colon + 1).Trim()
                    $headers[$headerName] = $headerValue
                }
            }
            if($headers['host'] -ne "127.0.0.1:$Port"){throw 'Hôte refusé'}
            $code=200;$type='application/json; charset=utf-8';$out=$null;$disposition=''
            if($method -eq 'GET' -and $path -eq '/api/state'){$out=@{state=$script:state;token=$token;account=$account;sequence=$script:sequence;testOnly=$true;fileRecoveryPending=(Test-Path -LiteralPath (File-Path 'transactions/pending.json'))}|ConvertTo-Json -Depth 30}
            elseif($method -eq 'POST' -and $path -in @('/api/action','/api/config','/api/files','/api/backup')){
                if($headers['x-csrf-token'] -ne $token -or $headers['origin'] -ne "http://127.0.0.1:$Port"){throw 'Origine ou jeton refusé'}
                $maxBody=65536;if($path -eq '/api/files'){$maxBody=18MB};$len=0;if(-not [int]::TryParse($headers['content-length'],[ref]$len) -or $len -lt 1 -or $len -gt $maxBody){throw 'Taille de requête invalide'}
                $body=New-Object byte[] $len;$offset=0;while($offset -lt $len){$n=$stream.Read($body,$offset,$len-$offset);if($n -le 0){throw 'Corps incomplet'};$offset+=$n}
                $p=[Text.Encoding]::UTF8.GetString($body)|ConvertFrom-Json
                # Transaction mémoire : restituer le snapshot si validation/persistance échoue.
                $before=$script:state|ConvertTo-Json -Depth 30
                try{Tick;if(Test-Path -LiteralPath (File-Path 'transactions/pending.json')){throw 'Transaction fichiers en attente : redémarrez le serveur'};$backupResult=$null;if($path -eq '/api/backup'){$backupResult=Backup-Request $p}elseif($path -eq '/api/config'){Save-Config $p}elseif($path -eq '/api/files'){File-Request $p}else{Action $p};$out=@{ok=$true;result=$backupResult}|ConvertTo-Json -Depth 15}catch{$latest=Get-ChildItem -LiteralPath $commits -Filter '*.json'|Sort-Object Name|Select-Object -Last 1;$script:state=Get-Content -LiteralPath $latest.FullName -Raw -Encoding UTF8|ConvertFrom-Json;throw}
            }
            elseif($method -eq 'GET' -and $path -match '^/api/file/(F-[a-f0-9]{16})/(source|final)/([0-9]{1,2})$'){
                $docId=$Matches[1];$kind=$Matches[2];$index=[int]$Matches[3]
                $doc=@($script:state.docs|Where-Object {$_.id -eq $docId -and $_.physical})
                if($doc.Count -ne 1){throw 'Document introuvable'};$doc=$doc[0]
                $fileList=@($doc.sourceFiles);$sub='Source';if($kind -eq 'final'){$fileList=@($doc.finalFiles);$sub='Livrables'}
                if($index -ge $fileList.Count){throw 'Fichier introuvable'};$meta=$fileList[$index]
                $disk=File-Path ($doc.status+'/'+$doc.id+'/'+$sub+'/'+$meta.name)
                if((File-Hash $disk) -ne $meta.sha256){throw 'Fichier modifié sur disque : téléchargement bloqué pour diagnostic'}
                $out=[IO.File]::ReadAllBytes($disk);$type='application/octet-stream'
                $disposition="Content-Disposition: attachment; filename*=UTF-8''$([Uri]::EscapeDataString($meta.name))`r`n"
            }
            elseif($method -eq 'GET' -and $path -in @('/','/app.js','/style.css')){
                $name=@{'/'='index.html';'/app.js'='app.js';'/style.css'='style.css'}[$path]
                $type=@{'/'='text/html; charset=utf-8';'/app.js'='text/javascript; charset=utf-8';'/style.css'='text/css; charset=utf-8'}[$path]
                $out=[IO.File]::ReadAllText((Join-Path (Join-Path $root 'web') $name),[Text.Encoding]::UTF8)
            }else{$code=404;$out='{"error":"Route inconnue"}'}
        }catch{$code=400;$type='application/json; charset=utf-8';$out=@{error=$_.Exception.Message}|ConvertTo-Json -Compress}
        try{if($out -is [byte[]]){$bytes=$out}else{$bytes=[Text.Encoding]::UTF8.GetBytes($out)};$h=[Text.Encoding]::ASCII.GetBytes("HTTP/1.1 $code Result`r`nContent-Type: $type`r`nContent-Length: $($bytes.Length)`r`n${disposition}Cache-Control: no-store`r`nX-Content-Type-Options: nosniff`r`nContent-Security-Policy: default-src 'self'; style-src 'self'; script-src 'self'; frame-ancestors 'none'`r`nConnection: close`r`n`r`n");$stream.Write($h,0,$h.Length);$stream.Write($bytes,0,$bytes.Length)}finally{$client.Close()}
    }
}finally{if($listener){$listener.Stop()};if($lock){$lock.Dispose()}}
