﻿$ErrorActionPreference='Stop'
$project=Split-Path $PSScriptRoot -Parent
$source=Get-Content (Join-Path $project 'server.ps1') -Raw
$tokens=$null;$errors=$null;$ast=[System.Management.Automation.Language.Parser]::ParseInput($source,[ref]$tokens,[ref]$errors)
if($errors.Count){throw ($errors|Out-String)}
foreach($f in $ast.FindAll({param($n) $n -is [System.Management.Automation.Language.FunctionDefinitionAst]},$false)){Invoke-Expression $f.Extent.Text}
. (Join-Path $project 'backup.ps1')
$testBase=Join-Path ([IO.Path]::GetTempPath()) ([Guid]::NewGuid().ToString('N'));$root=Join-Path $testBase 'app';$store=Join-Path $root 'TEST-DATA';$commits=Join-Path $store 'commits';$backups=Join-Path $store 'backups'
New-Item -ItemType Directory -Path $commits,$backups -Force|Out-Null
$script:state=Get-Content (Join-Path $project 'seed.json') -Raw|ConvertFrom-Json;$script:sequence=0;$script:actor='MANAGER';$account='TEST';$session='TEST';$script:count=0
function Check($name,$condition){if(-not $condition){throw "ECHEC : $name"};$script:count++;Write-Output "OK $name"}
function Reject($name,[scriptblock]$operation,$pattern){$failed=$false;try{& $operation|Out-Null}catch{if($_.Exception.Message -notmatch $pattern){throw};$failed=$true};Check $name $failed}
$script:testDay=[datetime]'2026-09-28T09:00:00'
function Get-Date{param($Format) if($Format){return $script:testDay.ToString($Format)};return $script:testDay}
try{
 Init-Files;Save-State;Ensure-Backup
 Check 'initialisation parametre sauvegarde' ($script:state.backup.directory -eq (Join-Path $root 'SAUVEGARDES'))
 Reject 'dossier relatif refuse' {Backup-Destination 'relatif'} 'absolu'
 Reject 'destination dans donnees refusee' {Backup-Destination (Join-Path $store 'copie')} 'séparée'
 Reject 'destination ancetre refusee' {Backup-Destination $root} 'séparée'
 Reject 'destination fichiers refusee' {Backup-Destination (Join-Path $root 'TEST-FILES/backup')} 'séparée'
 Reject 'agent ne sauvegarde pas' {Backup-Request ([pscustomobject]@{actor='HAMDANMO';operation='create'})} 'réservées'
 Reject 'conflit parametre destination' {Backup-Request ([pscustomobject]@{actor='MANAGER';operation='configure';version=0;directory=(Join-Path $testBase 'externe')})} 'ailleurs'
 $bytes=[Text.Encoding]::ASCII.GetBytes('%PDF-1.4 backup test %%EOF')
 File-Request ([pscustomobject]@{actor='MANAGER';operation='import';entity='ACM';nature='Conditions générales';files=@([pscustomobject]@{name='original.pdf';base64=[Convert]::ToBase64String($bytes)})})
 $d=$script:state.docs[-1];$id=$d.id
 Action ([pscustomobject]@{actor='HAMDANMO';id=$id;version=$d.version;action='take'})
 [IO.File]::WriteAllText((Join-Path $store 'server.lock'),'verrou exclu')
 $script:actor='MANAGER';$first=New-Backup;$directory=Join-Path $script:state.backup.directory $first.id
 Check 'copie complete valide' ($first.valid -and $first.files -gt 4)
 Check 'etat reussite conserve' ($script:state.backup.lastId -eq $first.id -and -not $script:state.backup.lastError)
 Check 'source active copiee' ((Get-Content -LiteralPath (Join-Path $directory ('payload/TEST-FILES/EN COURS/'+$id+'/Source/original.pdf')) -Raw) -eq [Text.Encoding]::ASCII.GetString($bytes))
 Check 'original archive copie' (Test-Path -LiteralPath (Join-Path $directory ('payload/TEST-FILES/Historique/'+$id+'/V001/original.pdf')))
 Check 'verrou serveur exclu' (-not (Test-Path -LiteralPath (Join-Path $directory 'payload/TEST-DATA/server.lock')))
 $manifest=Get-Content -LiteralPath (Join-Path $directory 'manifest.json') -Raw|ConvertFrom-Json
 Check 'tous les commits du point de reprise' (@($manifest.files|Where-Object {$_.path -like 'TEST-DATA/commits/*'}).Count -eq $first.sequence)
 $verify=Verify-Backup $directory;Check 'verification relit contenu' ($verify.valid)
 $countBefore=@(List-Backups).Count;Maybe-Backup;Check 'pas de doublon automatique le meme jour' (@(List-Backups).Count -eq $countBefore)
 $script:testDay=$script:testDay.AddDays(1);Maybe-Backup
 Check 'sauvegarde automatique jour suivant' (@(List-Backups).Count -eq $countBefore+1)
 Check 'historique conserve sans purge' (Test-Path -LiteralPath $directory)
 $restored=Join-Path $testBase 'restaure'
 $out=Restore-NewFolder $directory $restored $project
 Check 'restauration nouveau dossier' ($out -eq $restored -and (Test-Path -LiteralPath (Join-Path $restored 'server.ps1')))
 $last=Get-ChildItem -LiteralPath (Join-Path $restored 'TEST-DATA/commits') -Filter '*.json'|Sort-Object Name|Select-Object -Last 1
 $restoredState=Get-Content -LiteralPath $last.FullName -Raw|ConvertFrom-Json
 $rd=@($restoredState.docs|Where-Object id -eq $id)[0]
 Check 'chronometre restaure en pause' (-not $rd.active -and -not $rd.started -and $rd.status -eq 'EN COURS')
 Check 'original restaure exact' ((Backup-Hash (Join-Path $restored ('TEST-FILES/Historique/'+$id+'/V001/original.pdf'))) -eq (Backup-Hash (File-Path ('Historique/'+$id+'/V001/original.pdf'))))
 Check 'destination sauvegarde restauree locale' ($restoredState.backup.directory -eq (Join-Path $restored 'SAUVEGARDES'))
 Check 'restauration journalisee' ($restoredState.events[-1].action -eq 'RESTAURATION_NOUVEAU_DOSSIER')
 Reject 'restauration refuse ecrasement' {Restore-NewFolder $directory $restored $project} 'inexistant'
 $file=Join-Path $directory ('payload/TEST-FILES/Historique/'+$id+'/V001/original.pdf')
 $savedBytes=[IO.File]::ReadAllBytes($file);[IO.File]::WriteAllText($file,'corruption')
 Reject 'corruption detectee' {Verify-Backup $directory} 'Intégrité'
 Reject 'restauration corrompue refusee' {Restore-NewFolder $directory (Join-Path $testBase 'invalide') $project} 'Intégrité'
 [IO.File]::WriteAllBytes($file,$savedBytes)
 $extra=Join-Path $directory 'payload/TEST-DATA/intrus.txt';[IO.File]::WriteAllText($extra,'intrus')
 Reject 'fichier ajoute detecte' {Verify-Backup $directory} 'inattendus'
 [IO.File]::Delete($extra)
 $destination=Join-Path $testBase 'destination-inaccessible';[IO.File]::WriteAllText($destination,'ceci est un fichier')
 Backup-Request ([pscustomobject]@{actor='MANAGER';operation='configure';version=$script:state.backup.version;directory=$destination})|Out-Null
 Reject 'echec destination remonte' {New-Backup} '.*'
 Check 'echec visible sans fausse reussite' ($script:state.backup.lastError -and -not $script:state.backup.lastSuccess)
 Check 'echec journalise' ($script:state.events[-1].action -eq 'ECHEC_SAUVEGARDE')
 $manifestPath=Join-Path $directory 'manifest.json';$originalManifest=[IO.File]::ReadAllText($manifestPath);$m=$originalManifest|ConvertFrom-Json;$m.files[0].path='../ailleurs';[IO.File]::WriteAllText($manifestPath,($m|ConvertTo-Json -Depth 10))
 Reject 'manifeste traversant refuse' {Verify-Backup $directory} 'invalide'
 [IO.File]::WriteAllText($manifestPath,$originalManifest)
 Check 'sauvegarde initiale toujours valide' ((Verify-Backup $directory).valid)
 Write-Output "TOTAL : $script:count tests sauvegarde réussis"
}finally{Remove-Item -LiteralPath $testBase -Recurse -Force}
