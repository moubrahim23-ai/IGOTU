"""Vrai serveur, sauvegarde via API, restauration hors ligne et nouveau serveur."""
import base64,json,os,shutil,subprocess,tempfile,time,urllib.request,urllib.error
from pathlib import Path
root=Path(__file__).resolve().parents[1];pwsh=os.environ['TEST_PWSH'];count=0

def check(name,ok):
 global count
 assert ok,name
 count+=1;print('OK',name,flush=True)
def req(port,path='/api/state',data=None,headers=None):
 r=urllib.request.Request(f'http://127.0.0.1:{port}'+path,data=None if data is None else json.dumps(data).encode(),headers=headers or {})
 try:
  with urllib.request.urlopen(r,timeout=30) as f:return f.status,f.read()
 except urllib.error.HTTPError as e:return e.code,e.read()
def start(folder,port,log):
 p=subprocess.Popen([pwsh,'-NoProfile','-File',str(folder/'server.ps1'),'-Port',str(port)],stdout=log,stderr=log)
 for _ in range(100):
  try:
   if req(port)[0]==200:return p
  except OSError:pass
  time.sleep(.1)
 p.terminate();raise RuntimeError('Serveur indisponible')
with tempfile.TemporaryDirectory() as folder:
 temp=Path(folder);app=temp/'app';app.mkdir()
 for f in ['server.ps1','backup.ps1','Restaurer.ps1','seed.json','Lancer.cmd']:shutil.copy(root/f,app/f)
 shutil.copytree(root/'web',app/'web');log=open(temp/'logs.txt','w');p=start(app,18093,log);restored=None
 try:
  a=json.loads(req(18093)[1]);h={'Origin':'http://127.0.0.1:18093','X-CSRF-Token':a['token'],'Content-Type':'application/json'}
  check('sauvegarde automatique initiale reussie',bool(a['state']['backup']['lastSuccess']))
  check('agent refuse par API sauvegarde',req(18093,'/api/backup',{'actor':'HAMDANMO','operation':'create'},h)[0]==400)
  check('origine absente refusee',req(18093,'/api/backup',{'actor':'MANAGER','operation':'create'})[0]==400)
  content=b'%PDF-1.4 restore exact bytes %%EOF'
  imp={'actor':'MANAGER','operation':'import','entity':'ACM','nature':'Conditions generales','files':[{'name':'source.pdf','base64':base64.b64encode(content).decode()}]}
  assert req(18093,'/api/files',imp,h)[0]==200
  check('sauvegarde manuelle HTTP',req(18093,'/api/backup',{'actor':'MANAGER','operation':'create'},h)[0]==200)
  state=json.loads(req(18093)[1])['state'];docid=state['docs'][-1]['id'];backup_id=state['backup']['lastId'];backup=app/'SAUVEGARDES'/backup_id
  listing=json.loads(req(18093,'/api/backup',{'actor':'MANAGER','operation':'list'},h)[1])['result']['items']
  check('liste conserve automatique et manuelle',len(listing)==2)
  check('verification HTTP valide',json.loads(req(18093,'/api/backup',{'actor':'MANAGER','operation':'verify','id':backup_id},h)[1])['result']['valid'])
  check('chemin arbitraire verification refuse',req(18093,'/api/backup',{'actor':'MANAGER','operation':'verify','id':'../fichier'},h)[0]==400)
  dest=temp/'restored'
  restore=subprocess.run([pwsh,'-NoProfile','-File',str(app/'Restaurer.ps1'),'-Sauvegarde',str(backup),'-Destination',str(dest)],capture_output=True,text=True)
  check('script restauration execute',restore.returncode==0)
  restored=start(dest,18094,log);s=json.loads(req(18094)[1])['state']
  check('serveur restaure demarre',len(s['docs'])==6)
  check('telechargement restaure exact',req(18094,'/api/file/'+docid+'/source/0')[1]==content)
  check('nouvelle sauvegarde du serveur restaure',bool(s['backup']['lastSuccess']) and s['backup']['directory']==str(dest/'SAUVEGARDES'))
  check('installation initiale conservee',len(json.loads(req(18093)[1])['state']['docs'])==6)
  check('aucun verrou sauvegarde',not (backup/'payload/TEST-DATA/server.lock').exists())
  print('TOTAL:',count,'tests HTTP sauvegarde réussis')
 finally:
  p.terminate();p.wait(timeout=5)
  if restored:restored.terminate();restored.wait(timeout=5)
  log.close()
