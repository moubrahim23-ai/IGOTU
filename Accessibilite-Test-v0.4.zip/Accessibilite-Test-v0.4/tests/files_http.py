"""Serveur réel, vrais octets, redémarrage et reprise de manifeste interrompu."""
import base64, hashlib, json, os, shutil, subprocess, tempfile, time, urllib.request, urllib.error, uuid
from pathlib import Path
root=Path(__file__).resolve().parents[1];base='http://127.0.0.1:18092';count=0

def check(name,ok):
 global count
 assert ok,name
 count+=1;print('OK',name,flush=True)
def req(path='/api/state',data=None,headers=None):
 r=urllib.request.Request(base+path,data=None if data is None else json.dumps(data).encode(),headers=headers or {})
 try:
  with urllib.request.urlopen(r,timeout=10) as f:return f.status,f.read(),f.headers
 except urllib.error.HTTPError as e:return e.code,e.read(),e.headers
with tempfile.TemporaryDirectory() as folder:
 dest=Path(folder)
 for f in ['server.ps1','seed.json','backup.ps1']:shutil.copy(root/f,dest/f)
 shutil.copytree(root/'web',dest/'web');log=open(dest/'server.log','w')
 def start():
  p=subprocess.Popen([os.environ['TEST_PWSH'],'-NoProfile','-File',str(dest/'server.ps1'),'-Port','18092'],stdout=log,stderr=log)
  for _ in range(100):
   try:
    if req()[0]==200:return p
   except OSError:pass
   time.sleep(.1)
  p.terminate();raise RuntimeError((dest/'server.log').read_text())
 def state():return json.loads(req()[1])['state']
 def headers():return {'Origin':base,'Content-Type':'application/json','X-CSRF-Token':json.loads(req()[1])['token']}
 p=start()
 try:
  content=b'%PDF-1.4\nHTTP test\n%%EOF'
  payload={'actor':'MANAGER','operation':'import','entity':'ACM','nature':'Conditions generales','files':[{'name':'test ete.pdf','base64':base64.b64encode(content).decode()}]}
  check('import sans jeton refuse',req('/api/files',payload)[0]==400)
  check('import HTTP fichiers',req('/api/files',payload,headers())[0]==200)
  d=state()['docs'][-1];docid=d['id'];archive=dest/'TEST-FILES/Historique'/docid/'V001/test ete.pdf'
  check('original exact sur disque',archive.read_bytes()==content)
  code,body,h=req('/api/file/'+docid+'/source/0')
  check('telechargement octets exacts',code==200 and body==content)
  check('telechargement force piece jointe','attachment' in h['Content-Disposition'])
  check('index absent refuse',req('/api/file/'+docid+'/source/9')[0]==400)
  check('chemin fichiers libre inaccessible',req('/TEST-FILES/Historique/'+docid+'/V001/test%20ete.pdf')[0]==404)
  req('/api/action',{'actor':'MANAGER','action':'block','id':docid,'version':d['version'],'reason':'Test NC'},headers())
  check('NC physique via HTTP',(dest/'TEST-FILES/NON CONFORME'/docid/'Source/test ete.pdf').read_bytes()==content)
  p.terminate();p.wait(timeout=5)
  # Coupure entre rename et checkpoint, avant toute sauvegarde du nouvel état.
  files=dest/'TEST-FILES';src='NON CONFORME/'+docid;dst='A TRAITER/'+docid
  tx={'id':uuid.uuid4().hex,'phase':'forward','done':0,'moves':[{'from':src,'to':dst}]}
  (files/'transactions/pending.json').write_text(json.dumps(tx))
  (files/src).rename(files/dst)
  p=start()
  check('reprise au demarrage annule mouvement non valide',(files/src/'Source/test ete.pdf').exists() and not (files/dst).exists())
  check('statut persistant coherent',state()['docs'][-1]['status']=='NON CONFORME')
  check('original apres redemarrage intact',archive.read_bytes()==content)
  check('manifeste cloture apres reprise',not (files/'transactions/pending.json').exists())
  # Réponse perdue après commit : reprise ne doit pas annuler une opération validée.
  p.terminate();p.wait(timeout=5)
  last=sorted((dest/'TEST-DATA/commits').glob('*.json'))[-1];saved=json.loads(last.read_text(encoding='utf-8-sig'))
  done_tx=next(e['fileTransaction'] for e in reversed(saved['events']) if 'fileTransaction' in e)
  completed=files/'transactions'/f'{done_tx}-valide.json'
  completed.rename(files/'transactions/pending.json')
  p=start()
  check('operation deja validee non annulee',(files/src/'Source/test ete.pdf').exists())
  check('pas de nouveau document au redemarrage',len(state()['docs'])==6)
  print('TOTAL:',count,'tests HTTP fichiers reussis')
 finally:
  p.terminate();p.wait(timeout=5);log.close()
