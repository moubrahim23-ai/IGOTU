import json, os, shutil, subprocess, tempfile, time, urllib.request, urllib.error
from pathlib import Path
root=Path(__file__).resolve().parents[1]
base='http://127.0.0.1:18091'
count=0

def check(name, condition):
 global count
 assert condition,name
 count+=1
 print('OK',name,flush=True)
def req(path='/api/state', data=None, headers=None):
 r=urllib.request.Request(base+path,data=None if data is None else json.dumps(data).encode(),headers=headers or {})
 try:
  with urllib.request.urlopen(r,timeout=5) as f:return f.status,f.read()
 except urllib.error.HTTPError as e:return e.code,e.read()
with tempfile.TemporaryDirectory() as folder:
 dest=Path(folder)
 for f in ['server.ps1','seed.json','backup.ps1']:shutil.copy(root/f,dest/f)
 shutil.copytree(root/'web',dest/'web')
 # Ancien état v0.1 : migration réelle au démarrage, seed livré conservé.
 old=json.loads((dest/'seed.json').read_text());old.pop('config',None)
 (dest/'TEST-DATA/commits').mkdir(parents=True)
 (dest/'TEST-DATA/commits/000000000001.json').write_text(json.dumps(old))
 log=open(dest/'server.log','w')
 def start():
  p=subprocess.Popen([os.environ['TEST_PWSH'],'-NoProfile','-File',str(dest/'server.ps1'),'-Port','18091'],stdout=log,stderr=log)
  for _ in range(50):
   try:
    if req()[0]==200:return p
   except OSError:pass
   time.sleep(.1)
  p.terminate();raise RuntimeError((dest/'server.log').read_text())
 p=start()
 try:
  code,raw=req();a=json.loads(raw);check('migration configuration HTTP',a['state']['config']['version']==1);check('état HTTP et 5 documents',code==200 and len(a['state']['docs'])==5)
  for path in ['/','/app.js','/style.css']:check('fichier servi '+path,req(path)[0]==200)
  check('route inconnue',req('/seed.json')[0]==404)
  check('Host refusé',req(headers={'Host':'evil.example'})[0]==400)
  payload={'actor':'MANAGER','id':'ACC-001','version':1,'action':'assign','owner':'RMAIDIIM','priority':'Urgente'}
  h={'Origin':base,'X-CSRF-Token':a['token'],'Content-Type':'application/json'}
  check('jeton manquant refusé',req('/api/action',payload)[0]==400)
  check('origine refusée',req('/api/action',payload,{**h,'Origin':'http://evil.example'})[0]==400)
  check('affectation via HTTP',req('/api/action',payload,h)[0]==200)
  check('conflit version refusé',req('/api/action',payload,h)[0]==400)
  a=json.loads(req()[1]);d=a['state']['docs'][0]
  check('journal et données cohérents',d['owner']=='RMAIDIIM' and a['state']['events'][-1]['after']['owner']=='RMAIDIIM')
  payload.update(version=d['version'],owner='HAMDANMO',priority='INVALIDE')
  check('requête invalide refusée',req('/api/action',payload,h)[0]==400)
  check('annulation mutation partielle',json.loads(req()[1])['state']['docs'][0]['owner']=='RMAIDIIM')
  config=json.loads(req()[1])['state']['config']
  config['entities'].append({'id':'ENTITE_TEST','active':True})
  check('paramètres agent refusés',req('/api/config',{'actor':'HAMDANMO','config':config},h)[0]==400)
  check('paramètres manager enregistrés',req('/api/config',{'actor':'MANAGER','config':config},h)[0]==200)
  check('conflit paramètres refusé',req('/api/config',{'actor':'MANAGER','config':config},h)[0]==400)
  p.terminate();p.wait(timeout=5);p=start()
  a=json.loads(req()[1]);check('persistance après redémarrage',a['state']['docs'][0]['owner']=='RMAIDIIM')
  check('paramètres conservés après redémarrage',a['state']['config']['version']==2 and a['state']['config']['entities'][-1]['id']=='ENTITE_TEST')
  check('ancien jeton refusé après redémarrage',req('/api/action',payload,h)[0]==400)
  check('sauvegarde créée',len(list((dest/'TEST-DATA/backups').glob('*.json')))==1)
  check('aucun fichier temporaire restant',not list((dest/'TEST-DATA/commits').glob('*.tmp')))
  print('TOTAL:',count,'tests HTTP réussis')
 finally:
  p.terminate();p.wait(timeout=5);log.close()
