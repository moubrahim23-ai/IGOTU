﻿$ErrorActionPreference='Stop'
$project=Split-Path $PSScriptRoot -Parent
$source=Get-Content (Join-Path $project 'server.ps1') -Raw
$tokens=$null;$errors=$null
$ast=[System.Management.Automation.Language.Parser]::ParseInput($source,[ref]$tokens,[ref]$errors)
if($errors.Count){throw ($errors | Out-String)}
# Charger les vraies fonctions, sans lancer le serveur ni toucher TEST-DATA.
foreach($f in $ast.FindAll({param($n) $n -is [System.Management.Automation.Language.FunctionDefinitionAst]},$false)){Invoke-Expression $f.Extent.Text}
$store=Join-Path ([IO.Path]::GetTempPath()) ([Guid]::NewGuid().ToString('N'))
$commits=Join-Path $store 'commits';$backups=Join-Path $store 'backups'
New-Item -ItemType Directory -Path $commits,$backups -Force|Out-Null
$account='TEST';$session='TEST';$script:sequence=0;$script:actor='SYSTEME'
$script:state=Get-Content (Join-Path $project 'seed.json') -Raw|ConvertFrom-Json
$script:count=0
function Check($name,$condition){if(-not $condition){throw "ECHEC: $name"};$script:count++;Write-Output "OK $name"}
function Invoke-ActionTest($id,$action,$actor='HAMDANMO',$extra=@{}){
 $d=$script:state.docs|Where-Object id -eq $id
 $p=@{id=$id;action=$action;actor=$actor;version=$d.version;reason='Motif test'}
 foreach($k in $extra.Keys){$p[$k]=$extra[$k]}
 $snapshot=$script:state|ConvertTo-Json -Depth 30
 try{Action ([pscustomobject]$p)}catch{$script:state=$snapshot|ConvertFrom-Json;throw}
}
function Reject($name,[scriptblock]$op,$pattern){$failed=$false;try{& $op}catch{if($_.Exception.Message -notmatch $pattern){throw};$failed=$true};Check $name $failed}
function Doc($id){$script:state.docs|Where-Object id -eq $id}
# Horloge injectée uniquement dans ce test pour les horaires de prise en charge.
$script:testDate=[datetime]'2026-09-28T09:00:00'
function Get-Date {param($Format) if($Format){return $script:testDate.ToString($Format)};$script:testDate}
function Change-Config([scriptblock]$edit,$actor='MANAGER') {
    $c=$script:state.config|ConvertTo-Json -Depth 30|ConvertFrom-Json
    & $edit $c
    $snapshot=$script:state|ConvertTo-Json -Depth 30
    try{Save-Config ([pscustomobject]@{actor=$actor;config=$c})}catch{$script:state=$snapshot|ConvertFrom-Json;throw}
}
try{
 Save-State
 $root=$project
 $initialDocs=$script:state.docs|ConvertTo-Json -Depth 20 -Compress
 $script:state.PSObject.Properties.Remove('config');Ensure-Config
 Check 'migration ancienne version' ($script:state.config.version -eq 1)
 Check 'migration conserve documents' (($script:state.docs|ConvertTo-Json -Depth 20 -Compress) -eq $initialDocs)
 Reject 'configuration interdite agent' {Change-Config {} 'HAMDANMO'} 'réservés'
 Reject 'version configuration périmée' {Change-Config {param($c) $c.version=0}} 'ailleurs'
 Reject 'doublon identifiant' {Change-Config {param($c) $c.users+=@($c.users[1])}} 'double'
 Reject 'suppression historique interdite' {Change-Config {param($c) $c.users=@($c.users|Where-Object id -ne 'HAMDANMO')}} 'historiques'
 Reject 'auto désactivation interdite' {Change-Config {param($c) $c.users[0].active=$false}} 'propre accès'
 Reject 'horaire invalide' {Change-Config {param($c) $c.hours.standard.start='8h'}} 'Horaire invalide'
 Reject 'pauses supérieures plage' {Change-Config {param($c) $c.hours.standard.pauseMinutes=600}} 'supérieure'
 Reject 'date impossible' {Change-Config {param($c) $c.holidays=@('2026-02-30')}} 'Date de fermeture'
 Reject 'doublon fermeture' {Change-Config {param($c) $c.holidays=@('2026-12-25','2026-12-25')}} 'double'
 Reject 'entité dupliquée' {Change-Config {param($c) $c.entities+=@([pscustomobject]@{id='acm';active=$true})}} 'double'
 Reject 'désactivation entité avec stock' {Change-Config {param($c) $c.entities[0].active=$false}} 'Terminez'
 Reject 'temps négatif' {Change-Config {param($c) $c.estimates[0].minutes=-1}} 'entier'
 Reject 'temps doublon' {Change-Config {param($c) $c.estimates+=@([pscustomobject]@{id='OTHER';nature='Fiche Zoom';entity='*';minutes=1})}} 'double'
 Change-Config {param($c) $c.users+=@([pscustomobject]@{id='NOUVEAU_TEST';name='Nouveau compte fictif';role='collaborator';active=$false})}
 Check 'ajout inactif conservé' ($script:state.config.users[-1].id -eq 'NOUVEAU_TEST' -and -not $script:state.config.users[-1].active)
 Reject 'compte inactif refusé' {Invoke-ActionTest ACC-001 take NOUVEAU_TEST} 'inconnu'
 Change-Config {param($c) $c.users[-1].active=$true}
 Invoke-ActionTest ACC-001 assign MANAGER @{owner='NOUVEAU_TEST';priority='Haute'}
 Check 'nouveau compte assignable' ((Doc ACC-001).owner -eq 'NOUVEAU_TEST')
 Reject 'désactivation avant réaffectation refusée' {Change-Config {param($c) $c.users[-1].active=$false}} 'Réaffectez'
 Invoke-ActionTest ACC-001 assign MANAGER @{owner='HAMDANMO';priority='Normale'}
 Change-Config {param($c) $c.users[-1].active=$false}
 Check 'désactivation après réaffectation' (-not $script:state.config.users[-1].active)
 Change-Config {param($c) $c.users+=@([pscustomobject]@{id='BACKUP_TEST';name='Suppléant fictif';role='backup';active=$true})}
 Invoke-ActionTest ACC-002 assign BACKUP_TEST @{owner='RMAIDIIM';priority='Haute'}
 Check 'suppléant affecte' ((Doc ACC-002).owner -eq 'RMAIDIIM')
 Change-Config {param($c) $c.entities+=@([pscustomobject]@{id='DIRCOM';active=$true});$c.estimates[0].minutes=300} 'BACKUP_TEST'
 Check 'DIRCOM distincte DIRCO' (@($script:state.config.entities|Where-Object {$_.id -in @('DIRCO','DIRCOM')}).Count -eq 2)
 Check 'temps de référence modifié' ($script:state.config.estimates[0].minutes -eq 300)
 Invoke-ActionTest ACC-001 take
 Reject 'horaires modifiés avec chrono actif' {Change-Config {param($c) $c.hours.standard.start='08:30'}} 'pause'
 Invoke-ActionTest ACC-001 pause
 Change-Config {param($c) $c.hours.standard.start='08:30';$c.hours.standard.end='17:45';$c.holidays=@('2026-09-29')}
 $script:testDate=[datetime]'2026-09-28T08:29:00'
 Reject 'début minute avant refusé' {Invoke-ActionTest ACC-001 resume} 'Hors horaires'
 $script:testDate=[datetime]'2026-09-28T08:30:00';Invoke-ActionTest ACC-001 resume
 Check 'début minute exacte accepté' ((Doc ACC-001).active)
 Invoke-ActionTest ACC-001 pause
 $script:testDate=[datetime]'2026-09-28T17:45:00'
 Reject 'fin minute exacte refusée' {Invoke-ActionTest ACC-001 resume} 'Hors horaires'
 $script:testDate=[datetime]'2026-09-29T10:00:00'
 Reject 'fermeture bloque reprise' {Invoke-ActionTest ACC-001 resume} 'fermeture'
 $d=Doc ACC-001;$d.started=([DateTimeOffset]([datetime]'2026-09-21T17:44:00')).ToString('o');$d.active=$true;$d.seconds=0;$d.stageSeconds=@(0,0,0,0);Tick
 Check 'arrêt aux minutes configurées' (-not $d.active -and [Math]::Abs($d.seconds-60) -lt .01)
 $configEvent=@($script:state.events|Where-Object action -eq 'PARAMETRES_MODIFIES')[-1]
 Check 'journal paramètres avant après' ($configEvent.before.version -eq $configEvent.after.version-1)
 Write-Output "TOTAL: $script:count tests paramètres réussis"
}finally{Remove-Item $store -Recurse -Force}
