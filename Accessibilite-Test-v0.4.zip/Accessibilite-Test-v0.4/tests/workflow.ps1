﻿$ErrorActionPreference='Stop'
$project=Split-Path $PSScriptRoot -Parent
$source=Get-Content (Join-Path $project 'server.ps1') -Raw
$tokens=$null;$errors=$null
$ast=[System.Management.Automation.Language.Parser]::ParseInput($source,[ref]$tokens,[ref]$errors)
if($errors.Count){throw ($errors | Out-String)}
# Charger les vraies fonctions, sans lancer le serveur ni toucher TEST-DATA.
foreach($f in $ast.FindAll({param($n) $n -is [System.Management.Automation.Language.FunctionDefinitionAst]},$false)){Invoke-Expression $f.Extent.Text}
$store=Join-Path ([IO.Path]::GetTempPath()) ([Guid]::NewGuid().ToString('N'))
$root=$store
$commits=Join-Path $store 'commits';$backups=Join-Path $store 'backups'
New-Item -ItemType Directory -Path $commits,$backups -Force|Out-Null
$account='TEST';$session='TEST';$script:sequence=0;$script:actor='SYSTEME'
$script:state=Get-Content (Join-Path $project 'seed.json') -Raw|ConvertFrom-Json
$script:count=0
function Check($name,$condition){if(-not $condition){throw "ECHEC: $name"};$script:count++;Write-Output "OK $name"}
function Invoke-ActionTest($id,$action,$actor='HAMDANMO',$extra=@{}){
 $d=$script:state.docs|Where-Object id -eq $id
 $p=@{id=$id;action=$action;actor=$actor;version=$d.version;reason='Motif test'}
 foreach($k in $extra.Keys){$p[$k]=$extra[$k]}
 $snapshot=$script:state|ConvertTo-Json -Depth 30
 try{Action ([pscustomobject]$p)}catch{$script:state=$snapshot|ConvertFrom-Json;throw}
}
function Reject($name,[scriptblock]$op,$pattern){$failed=$false;try{& $op}catch{if($_.Exception.Message -notmatch $pattern){throw};$failed=$true};Check $name $failed}
function Doc($id){$script:state.docs|Where-Object id -eq $id}
# Horloge injectée uniquement dans ce test pour les horaires de prise en charge.
$script:testDate=[datetime]'2026-09-28T09:00:00'
function Get-Date {param($Format) if($Format){return $script:testDate.ToString($Format)};$script:testDate}
try{
 Save-State
 Invoke-ActionTest ACC-001 assign MANAGER @{owner='HAMDANMO';priority='Urgente'}
 Check 'affectation et priorité' ((Doc ACC-001).owner -eq 'HAMDANMO' -and (Doc ACC-001).priority -eq 'Urgente')
 Reject 'réservation autre agent' {Invoke-ActionTest ACC-001 take RMAIDIIM} 'réservé'
 Invoke-ActionTest ACC-001 take
 Check 'prise en charge' ((Doc ACC-001).active)
 Reject 'double prise même document' {Invoke-ActionTest ACC-001 take RMAIDIIM} 'indisponible'
 Reject 'un seul document actif' {Invoke-ActionTest ACC-002 take} 'déjà actif'
 Reject 'clôture dossier incomplet' {Invoke-ActionTest ACC-001 close} 'incomplet'
 Reject 'affectation agent interdite' {Invoke-ActionTest ACC-002 assign RMAIDIIM @{owner='RMAIDIIM';priority='Haute'}} 'manager'
 Reject 'version périmée' {Invoke-ActionTest ACC-001 pause HAMDANMO @{version=0}} 'changé'
 $d=Doc ACC-001;$d.started=([DateTimeOffset]::Now.AddSeconds(-65)).ToString('o');Charge $d ([DateTimeOffset]::Now)
 Check 'charge temps et étape' ($d.seconds -ge 65 -and $d.stageSeconds[0] -eq $d.seconds)
 Invoke-ActionTest ACC-001 stage HAMDANMO @{stage=1}
 Check 'changement étape' ((Doc ACC-001).stage -eq 1)
 Invoke-ActionTest ACC-001 pause
 Check 'pause' (-not (Doc ACC-001).active -and -not (Doc ACC-001).started)
 Invoke-ActionTest ACC-002 take
 Reject 'reprise si autre actif' {Invoke-ActionTest ACC-001 resume} 'déjà actif'
 Invoke-ActionTest ACC-002 pause
 Invoke-ActionTest ACC-001 resume
 Reject 'motif NC obligatoire' {Invoke-ActionTest ACC-001 block HAMDANMO @{reason=' '}} 'Motif'
 Invoke-ActionTest ACC-001 block
 Check 'NC arrête chrono' ((Doc ACC-001).status -eq 'NON CONFORME' -and -not (Doc ACC-001).active)
 Reject 'retour agent interdit' {Invoke-ActionTest ACC-001 return} 'manager'
 Invoke-ActionTest ACC-001 return MANAGER
 Check 'retour incrémente reprise' ((Doc ACC-001).reworks -eq 1 -and (Doc ACC-001).status -eq 'A TRAITER')
 Invoke-ActionTest ACC-001 take
 Invoke-ActionTest ACC-001 package
 Invoke-ActionTest ACC-001 close
 Check 'clôture' ((Doc ACC-001).status -eq 'TRAITES' -and (Doc ACC-001).finished -and -not (Doc ACC-001).active)
 Reject 'publication hors ACM' {Invoke-ActionTest ACC-001 publish MANAGER} 'ACM'
 Invoke-ActionTest ACC-002 resume
 Invoke-ActionTest ACC-002 package
 Invoke-ActionTest ACC-002 close
 Invoke-ActionTest ACC-002 publish MANAGER
 Check 'publication ACM' ((Doc ACC-002).published)
 Invoke-ActionTest ACC-002 reopen MANAGER
 Check 'réouverture retire publication' (-not (Doc ACC-002).published -and (Doc ACC-002).wasPublished)
 Invoke-ActionTest ACC-002 take
 Invoke-ActionTest ACC-002 package
 Invoke-ActionTest ACC-002 close
 Check 'republication après correction' ((Doc ACC-002).published)
 foreach($date in @('2026-09-26T09:00:00','2026-09-28T07:59:00','2026-09-28T18:00:00','2026-09-25T17:00:00')){
  $script:testDate=[datetime]$date;Reject "hors horaires $date" {Invoke-ActionTest ACC-003 take} 'Hors horaires'
 }
 $script:actor='HAMDANMO';$d=Doc ACC-003;$d.active=$true;$d.started=([DateTimeOffset]([datetime]'2026-09-25T16:59:00')).ToString('o');$d.status='EN COURS';Tick
 Check 'arrêt vendredi 17h' (-not $d.active -and [Math]::Abs($d.seconds-60) -lt 0.01)
 Check 'arrêt automatique attribué au système' ($script:state.events[-1].actor -eq 'SYSTEME')
 Check 'sauvegarde quotidienne' (@(Get-ChildItem $backups -Filter '*.json').Count -eq 1)
 $last=Get-ChildItem $commits -Filter '*.json'|Sort-Object Name|Select-Object -Last 1
 $saved=Get-Content $last.FullName -Raw|ConvertFrom-Json
 Check 'persistance et journal avant/après' ($saved.events.Count -gt 15 -and $saved.events[0].before -and $saved.events[0].after)
 Write-Output "TOTAL: $script:count tests réussis"
}finally{Remove-Item $store -Recurse -Force}
