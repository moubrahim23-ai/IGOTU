# Accessibilité — cahier des charges validé

Version de cadrage du 26 septembre 2026. Responsable : Mohammed Oubrahim.

## Objectif et environnement
Application métier hors ligne en HTML/CSS/JavaScript et PowerShell Windows 5.1. Un serveur local par poste, sans élévation ni modification de la politique de sécurité. Compte de session Windows, jamais nom du PC. Données communes dans un partage interne distinct des dossiers clients. Chemins configurables. Tous les collaborateurs peuvent traiter toutes les entités. Excel est installé. Outlook local sera utilisé pour préparer les messages, jamais envoyer sans action de l’utilisateur.

## Personnes et droits
Trois collaborateurs autonomes : HAMDANI Mohamed, RMAIDI Imad, LISSAOUI Hiba. JEBBALI Youssef est prévu, date d’intégration à confirmer. Manager et suppléant avec mêmes fonctions. Gestion des comptes, rôles, désactivation et historique. Documents d’un compte désactivé à réaffecter. Collaborateur : ses évaluations et ses exports seulement. Manager : vue de toute l’équipe. Les permissions de l’interface ne remplacent pas les droits Windows sur les fichiers. Un partage inscriptible par tous n’offre pas un journal inviolable ni une confidentialité entre lecteurs : définir des ACL réelles pour la production.

## Réception et identité
Entité > sous-répertoire métier > À traiter, En cours, Traité, Non conforme. ACM possède aussi À Publier. Détection automatique des dépôts stables lorsque l’application est active. Archivage des originaux dans Historique avant modification. Identifiant stable par document, identifiant de version et de dépôt. Même nom ne signifie pas même contenu. Word et PDF de même nom, dans le même dépôt/entité/sous-répertoire, regroupés en une fiche. Association manuelle autorisée et journalisée si noms différents. Nouvelle version en cours de traitement : alerte, aucun écrasement, décision manager entre remplacement de la version de travail et traitement séparé. Définition opérationnelle d’un « même dépôt » et traitement des fichiers homonymes à valider avec exemples.

## Travail et états
Prise libre dans À traiter ; réservation exclusive et affectation prioritaire manager. Un seul document ACTIF et un seul chronomètre par compte, mais documents suspendus possibles. Pause pour une urgence sans perdre l’attribution. Étapes : préparation, balisage PDF, vérification RAPDF, finalisation. Temps cumulé par étape, par traitement et par reprise. Bouton Pause/Reprendre. Arrêt à 18 h lundi-jeudi, 17 h vendredi. Reprise manuelle. Fermeture du navigateur seule : compteur continue. Arrêt du PC/serveur : temps arrêté au dernier point sauvegardé. Coupure réseau : compteur local, puis synchronisation idempotente ; prises et mouvements bloqués. Conflits de réaffectation pendant coupure à présenter au manager, ne jamais fusionner silencieusement.

## Dossier final et contrôles
Clôture directe par le collaborateur, sans validation manager préalable. PDF final et audit Excel obligatoires ; Word final obligatoire si origine Word. Original client conservé dans Historique. Vérifier existence, extensions, intégrité minimale et identité du dossier, pas simplement cases cochées. Contrôle manager/suppléant possible à tout moment. Réouverture avec motif obligatoire. Correction interne distinguée de l’attente client. Garder la version contrôlée, les observations et les anciennes durées.

## Non-conformités et retours
Motif obligatoire, arrêt compteur, date et auteur journalisés. Retour corrigé reçu par mail, importé dans la fiche existante comme nouvelle version ; premier dépôt conservé. Réservé au collaborateur initial avec réaffectation manager possible. Relance tous les deux jours ouvrés hors week-end, jours fériés et fermetures configurés, jusqu’à résolution. Alerte et brouillon Outlook prérempli ; ouverture du brouillon n’est pas preuve d’envoi. Confirmation de relance envoyée et historique. Contacts À/Cc par entité modifiables par managers.

## Délais et capacité
Échéance par lot, exception par document prioritaire. Historique des modifications. Alerte quotidienne sur échéances à venir/dépassées. Temps indicatifs : Zoom/Clarté 4 h 30 max, CG ACM 9 h ; autres à estimer. Ajustement manager selon complexité/pages. Horaires 8-18 h lundi-jeudi avec 45 min de pause et 1 h déjeuner ; vendredi 8-17 h avec 40 min et 1 h déjeuner. Absences, réunions et formations : déclaration agent avec validation manager ou saisie manager validée. Déduire l’union des intervalles, pas deux fois les chevauchements. Capacité théorique : 8 h 15 lundi-jeudi, 7 h 20 vendredi. Temps restant ne doit pas être assimilé aveuglément à estimation moins temps consommé.

## ACM et publication
Bouton manager de mise à jour À Publier. Copie hebdomadaire de l’ensemble traité selon processus existant. Nouveau système : préparer, vérifier, puis basculer sans effacement destructif prématuré, archiver les versions remplacées. Journal des succès/échecs. Réouverture d’un document publié : retrait et archivage de sa copie ; alerte si échec. Après correction : republication automatique uniquement si publié avant réouverture. Traité + À Publier ne comptent pas deux réceptions ou deux productions.

## Qualité
Référentiel officiel : https://accessibilite.public.lu/fr/rapdf1.1/referentiel-technique.html . Numérotation et tests à intégrer fidèlement avec version, source et date de récupération. La liste « 46 critères » annoncée reste à rapprocher de la liste officielle avant implémentation. Application de saisie et d’aide au contrôle, pas moteur de certification automatique.
Résultats : Conforme, Non conforme, Non applicable, Non évalué. Observation obligatoire uniquement pour Non conforme. Brouillon tant qu’un Non évalué subsiste ou qu’une NC est sans observation. Finalisation : notification agent à la synchronisation, bouton Pris connaissance (lecture ≠ accord), commentaire et demande de révision. Historique des réponses et corrections, préserver l’évaluation initiale.
Tirage hebdomadaire d’un document terminé par collaborateur ; mois de cinq semaines = cinq évaluations. Si aucun terminé, chercher un plus ancien non évalué ; sinon signaler absence de candidat. Ne pas tirer deux fois le même traitement. Export Excel par Évaluations/Agent/Année/Mois/Semaine, mois déterminé par date d’évaluation. Historique agent/semaine/mois. Règles et seuils de prime à confirmer, distincts de la conformité technique.

## Pilotage et reportings
Rafraîchissement toutes les 30 secondes et bouton Actualiser ; heure du dernier succès et état de connexion. Stock par statut, production initiale/reprises, délai, alertes, charge, qualité. Filtres jour/semaine/mois/année, agent, entité, nature. Export Excel synthèse + détails ; périmètre agent ou global manager. Modèle configurable par entité avec indicateurs, regroupements, présentation et brouillon Outlook joint. Aucune expédition automatique.
ACM : modèle Lydie, métiers distincts et indicateurs reçus/à traiter/NC/à publier. Clarifier stock versus flux hebdomadaire. Ventilation Santé/Prévoyance et Vie/ERE à confirmer ; ne pas répartir arbitrairement un répertoire regroupé.

## Reprise des données
Consolidation_ACC.xlsx analysé : PILOTAGE inventaire actualisé avant envoi ; compter les PDF via colonne J sans compter audits Word/Excel. Selon responsable, Date conserve premier dépôt, K/L horodatent les transitions. DATA source active, Date_A_TRAITER = prise en charge, Date_FIN = fin et déplacement Traité. DATAs ancien UserForm. Prévisualiser et résoudre les incohérences, pas de suppression automatique par nom. DMT historique comprend des interruptions/nuits et diverge entre sources : conserver provenance et drapeau non fiabilisé. Homonymes peuvent être versions distinctes. Les 82 noms ACM À Publier du premier rapport restent provisoires, car dédoublonnage par nom insuffisant.

## Journal, sauvegarde et reprise après incident
Événement : ID unique, heure UTC + affichage local, compte Windows, poste/session, document/version, action, état avant/après, raison, résultat et erreur. Transactions sous verrou exclusif et contrôles de version ; aucune opération métier acceptée sans persistance. Sauvegarde quotidienne quand une instance est active, emplacement distinct configurable, conservation illimitée sans purge. Restauration manager confirmée et coordonnée (arrêt des écritures, contrôle cohérence, sauvegarde préalable). Une sauvegarde logique seule ne restaure pas les fichiers métier : périmètre documentaire et volume à définir.

## État de livraison v0.1 TEST
Cette version valide le socle métier avec données fictives uniquement. Elle ne connecte aucun dossier client. Les droits manager/agent peuvent être simulés et sont clairement identifiés. Ne pas l’utiliser pour mesurer la production réelle.

Opérationnel dans le prototype : serveur local, persistance atomique du jeu test et des événements, filtrage, affectation, réservation, un actif par compte, étapes, pause/reprise, NC, retour corrigé simulé, dossier final simulé, clôture, réouverture et publication simulée, arrêt horaire, arrêt après redémarrage, journal et sauvegardes quotidiennes du jeu test.

À intégrer ensuite : déplacements et vérification des vrais fichiers, scan stable du partage, versionnement physique et transactions de récupération, usage simultané multi-postes sur SMB réel, tampon réseau local, grille RAPDF officielle et exports Excel, tirage hebdomadaire, Outlook, reporting configurable, import Excel, absences/capacité, jours fériés, gestion des comptes et restauration coordonnée. Aucun bouton ne prétend exécuter ces modules absents.

## Points à récupérer au bureau
Chemins du partage interne, des entités et sauvegardes ; comptes manager et suppléant ; liste complète des entités ; règles de prime ; exemples de versions homonymes ; validation de la conservation des dates sur cas réels ; export CRM ; modèle d’audit existant si disponible. Le modèle RAPDF en ligne suffit pour préparer le futur module technique.

## Livraison v0.2 TEST — 27 septembre 2026

Écran Paramètres : gestion des comptes simulés et rôles manager/suppléant/collaborateur, activation et désactivation avec réaffectation préalable, entités sans suppression historique, horaires lundi-jeudi et vendredi à la minute, pauses pour capacité théorique, jours de fermeture, temps de référence par nature et entité. Application des paramètres au workflow et aux filtres. Version de configuration contrôlée, journal avant/après et migration automatique du jeu v0.1.

L'authentification Windows réelle, les chemins réseau, les fichiers métier, la restauration et les autres modules du cahier des charges restent à développer.

## Livraison v0.3 TEST LOCAL — 27 septembre 2026

Import explicite de copies PDF/DOCX, archive de source V001, déplacement physique du dossier par statut et identifiant dans TEST-FILES, téléchargement de la source, dépôt des livrables PDF/XLSX/DOCX requis, vérification minimale de structure et empreintes avant clôture, retours corrigés versionnés et réouverture avec archivage des anciens livrables. Manifeste de transaction avec checkpoints, annulation/reprise après interruption. Les sources choisies sur le PC ne sont pas modifiées.

La sauvegarde documentaire complète n'est pas encore automatisée : la sauvegarde JSON seule ne suffit pas. La connexion aux partages par entité, la détection automatique, la publication physique et les autres modules restent à développer. Les homonymes importés sont distincts ; un retour corrigé doit être importé depuis la fiche existante.

## Livraison v0.4 TEST LOCAL — 27 septembre 2026

Sauvegardes complètes quotidiennes et manuelles de TEST-DATA et TEST-FILES avec empreintes et manifeste. Emplacement configurable, erreurs visibles, conservation sans purge, vérification à la demande. Une copie automatique au premier fonctionnement de chaque jour, reprise après échec après 30 minutes. La sauvegarde est séquentielle et peut immobiliser temporairement l’interface.

Restaurer.ps1 vérifie les données et crée un nouveau dossier avec le code v0.4 fourni, sans écraser l’installation précédente. Chronomètres en pause, événement de restauration, nouvelle destination de sauvegarde locale. Ce procédé fournit une récupération isolée ; le basculement de plusieurs postes de production reste à organiser.


## Livraison v0.5 TEST LOCAL — 28 septembre 2026

Publication physique ACM individuelle ou globale avec aperçu et confirmation, contrôle des empreintes, archivage intégral de l’ancien À PUBLIER et journalisation. Les documents fictifs sont exclus de la publication globale. Une liste modifiée depuis l’aperçu impose son rechargement.

Réouverture : retrait et archivage de la copie publiée. Clôture après correction : republication automatique d’un document précédemment publié. Transactions récupérables au démarrage et sauvegardes incluant les publications. Rappel hebdomadaire indicatif ; lancement de la publication manuellement par manager ou suppléant. Périmètre limité à TEST-FILES, sans partage client ni authentification Windows de production.

## Livraison v0.6 — préparation des partages

Configuration par entité, racine locale ou UNC, quatre noms de sous-dossiers, aperçu manuel récursif en lecture seule. PDF seuls dans le total PDF, homonymes conservés, résultats incomplets explicites, limites de parcours et journalisation de la configuration. Aucun traitement sur partage ni import automatique dans cette étape. Voir LIRE-MOI.md pour les limites exactes.

## Livraison v0.7 — import explicite depuis partage

Préparation et copie locale du PDF avec son Word de même nom, empreintes relues au moment de la confirmation, date de premier dépôt saisie par le manager, provenance et archivage atomiquement enregistrés avec le document. Même chemin déjà importé refusé ; version changée dirigée vers la fiche existante. Aucun déplacement ni réservation sur partage dans cette étape.

## Livraison v0.8 — recherche à tous les niveaux

Parcours depuis la racine de chaque entité, PDF et Word DOC/DOCX/DOCM détectés à toute profondeur logique. Chemins et niveaux conservés, erreurs par branche sans abandon global, liens non suivis, export complet et script autonome. Aucun déplacement et aucun import automatique depuis cette nouvelle découverte.
