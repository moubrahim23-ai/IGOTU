# Accessibilité — v0.8 TEST LOCAL

Application HTML/CSS/JS et serveur PowerShell. Aucun module externe, installation administrateur ou accès internet requis sur le poste utilisateur. Les tests de développement inclus nécessitent d'autres outils, pas l'application.

## Mise à jour

Suivre INSTALLATION_CORRECTIF.txt. Remplacer server.ps1, seed.json et web ; ajouter backup.ps1 et Restaurer.ps1 ; conserver TEST-DATA, TEST-FILES et SAUVEGARDES. Ne pas utiliser l'ancienne interface avec le nouveau serveur.

## Nouveau parcours avec fichiers

1. Choisir le rôle Manager, puis Documents → **Importer un document de test**.
2. Choisir l'entité et la nature. Sélectionner un PDF, un DOCX ou les deux pour un seul document.
3. L'import copie les fichiers, archive l'original dans `TEST-FILES/Historique/<identifiant>/V001`, puis crée le dossier de travail dans `TEST-FILES/A TRAITER/<identifiant>/Source`. Les fichiers sélectionnés sur le PC ne sont pas déplacés ni modifiés.
4. Affecter le document ou sélectionner un collaborateur puis **Prendre en charge**. Le dossier passe réellement dans EN COURS.
5. Dans la fiche, télécharger une copie de la source pour travailler. Enregistrer son travail dans un autre dossier, puis utiliser **Déposer les livrables**.
6. Déposer le PDF final et l'audit XLSX ; si la source comporte un Word, le DOCX final est obligatoire. Le remplacement d'un dépôt final conserve le précédent dans Historique.
7. **Clôturer et déplacer vers Traités** vérifie les fichiers attendus et leurs empreintes, puis déplace le dossier complet dans TRAITES. Aucun contrôle manager préalable n'est requis.
8. **Déclarer non conforme**, avec motif, déplace le dossier dans NON CONFORME et arrête le chrono.
9. Le manager utilise **Importer le retour corrigé** avec les pièces reçues par mail. La source V002 (puis V003…) est archivée, l'ancien travail est conservé dans Historique, le dossier revient en A TRAITER, l'agent initial est conservé et la date du premier dépôt ne change pas.
10. Le manager peut rouvrir un traité pour correction. Les livrables précédents sont archivés et le dossier revient en A TRAITER.

Les cinq exemples fournis restent fictifs et conservent leurs boutons de simulation. Un document importé ne peut pas être clôturé en simulant la présence des fichiers. Un même nom importé deux fois crée deux documents distincts : aucun dédoublonnage ou écrasement implicite.

## Publication ACM — v0.6

Dans Documents, le manager ou son suppléant ouvre **Publication ACM**. L’aperçu présente tous les ACM importés et traités ; les cinq exemples fictifs sont exclus. Après confirmation, le contenu actuel de `TEST-FILES/A PUBLIER` est archivé dans Historique puis remplacé par les livrables de tous les documents éligibles. Les sources restent dans TRAITES. Les dossiers sont identifiés par document pour éviter les collisions de noms.

Une fiche ACM traitée permet aussi de publier ou republier ses seuls livrables. Une réouverture retire et archive sa copie publiée ; la clôture après correction la republie automatiquement si elle avait déjà été publiée. Un fichier absent, altéré ou une collision bloque l’opération.

L’interface indique la dernière publication globale et un rappel après sept jours : le lancement reste manuel. Aucun partage client n’est connecté. Les publications et leurs archives sont incluses dans les sauvegardes complètes.

## Horaires

Import, consultation, affectation et déclaration NC possibles hors horaires. La prise en charge et la reprise du chrono restent limitées aux horaires configurés, hors week-ends et jours de fermeture. Les tests automatisés injectent une horloge de test ; ils ne modifient pas celle du poste.

## Formats et limites

- Source : PDF et DOCX. Les anciens formats DOC/XLS ne sont pas encore pris en charge.
- Livrables : PDF, XLSX et DOCX si requis ; un fichier maximum par format.
- 10 Mio par fichier, 12 Mio par envoi, nom de fichier de 100 caractères maximum.
- Le PDF est vérifié par sa signature ; les fichiers Office par leur structure ZIP minimale. L'application ne vérifie pas encore le remplissage de l'audit, la lisibilité complète, la protection du PDF ou la conformité RAPDF. Elle n'exécute pas les documents importés.
- Les dossiers physiques sont classés par statut et identifiant interne dans cet espace de test. Le classement par entité reste dans la fiche ; le branchement sur les vrais dossiers par entité viendra ensuite.

## Récupération et sauvegarde

Les déplacements sont accompagnés d'un manifeste de transaction. Au démarrage, une opération non validée dans le journal est annulée ; une opération validée est conservée. Une collision ou incohérence ne déclenche aucune suppression automatique. Si la reprise ne peut pas aboutir, conserver les deux dossiers de données pour diagnostic.

Ne pas déplacer ou renommer manuellement les fichiers sous TEST-FILES pendant le fonctionnement. En cas d'échec d'enregistrement, le mouvement est annulé lorsque les chemins restent cohérents. Les zones de staging et manifestes sont conservées pour diagnostic, sans purge automatique.

La sauvegarde quotidienne est désormais complète : données, journal, sources, versions et livrables. L’onglet Sauvegardes permet de changer l’emplacement, créer une copie et la vérifier. La restauration utilise Restaurer.ps1 et crée un nouveau dossier sans écrasement. Lire RESTAURATION.md. Choisir un autre disque ou emplacement autorisé pour se protéger d’une panne du disque ; la destination locale par défaut ne suffit pas à cet objectif.

## Périmètre restant

Authentification Windows réelle, plusieurs postes sur partage SMB, détection automatique des dépôts, versions reçues en cours de traitement, évaluations RAPDF, exports/reportings Excel, import de l'ancien consolidé et Outlook. Les rôles restent sélectionnables pour la démonstration : ce n'est pas une gestion sécurisée des droits de production.

Les fichiers importés sont de vraies copies locales. Les emplacements configurés peuvent être lus à la demande ; le traitement et la publication restent dans TEST-FILES. Les tests et leurs limites sont décrits dans VERIFICATION.md.

## Dossiers partagés — v0.6

L’onglet Dossiers partagés est réservé aux rôles manager et suppléant. Définir une racine absolue par entité et les noms des quatre sous-dossiers, enregistrer, puis cliquer Tester et consulter les PDF. Les chemins Windows UNC peuvent être préparés hors réseau ; leur test nécessite le compte Windows et le réseau ayant les accès nécessaires. Aucun identifiant réseau n’est demandé ni enregistré.

L’aperçu parcourt les sous-dossiers en lecture seule. Il dénombre PDF, DOCX et autres fichiers séparément, conserve les homonymes et affiche au plus 200 PDF par statut. Un dossier absent, un refus d’accès, un lien non pris en charge ou une limite de parcours donne un résultat incomplet, jamais un zéro présenté comme total fiable. Le parcours est limité à 10 000 entrées et vérifie une limite de 20 secondes entre les accès ; un appel SMB bloqué peut néanmoins durer plus longtemps et immobiliser temporairement ce serveur local.

La consultation seule ne déplace ni n’importe aucun fichier et ne lit pas le contenu PDF. L’import explicite décrit ci-dessous constitue une action distincte. La date de modification du fichier n’est pas sa date de réception. Le résultat est un instantané de lecture, pas un inventaire transactionnel : des dépôts simultanés peuvent changer les fichiers pendant le parcours. Aucun droit d’écriture n’est testé. Les publications ACM restent locales.

Le paramétrage est journalisé et sauvegardé dans l’état local. Les fichiers des partages ne sont pas inclus dans la sauvegarde de l’application. La gestion multi-postes, les réservations sur partage et l’authentification réelle restent à développer avant un usage en production.

## Import depuis un partage — v0.7

1. Dans Dossiers partagés, enregistrer les chemins et tester l’entité.
2. Pour un PDF de À traiter, cliquer Préparer l’import. Le serveur lit le PDF et le DOCX de même nom s’il existe dans le même dossier. Il vérifie leur structure minimale, leurs tailles et empreintes.
3. Vérifier la liste des sources. Si le Word porte un autre nom, utiliser l’import manuel avec les deux fichiers. Aucun rapprochement approximatif n’est effectué.
4. Renseigner la nature et la date/heure du premier dépôt client depuis le suivi métier. Aucune date de réception n’est déduite de la modification du fichier.
5. Confirmer que la source est complète, puis importer. La source reste sur le partage ; la copie rejoint TEST-FILES/A TRAITER et Historique/V001. Le chemin d’origine et la date d’import sont journalisés.

Un même chemin déjà importé est refusé dans cette installation, même après redémarrage. S’il contient une nouvelle version, la fiche existante est indiquée : utiliser son parcours de retour corrigé. Un homonyme dans un autre répertoire reste distinct. Ce mécanisme ne reconnaît pas un fichier renommé ou déplacé et ne remplace pas une réservation multi-postes. Le partage reste inchangé : un autre outil pourrait toujours prendre le même fichier.

L’aperçu ne fige pas le dépôt client. L’import relit les sources et refuse un contenu changé depuis la préparation. Limites existantes : 10 Mio par fichier, 12 Mio au total, un PDF et un DOCX maximum. Les accès réseau peuvent bloquer temporairement le serveur local. Les sources copiées et leur provenance sont incluses dans les sauvegardes locales ; le reste du partage ne l’est pas.

## Recherche depuis la racine — v0.8

Dans Dossiers partagés, enregistrer la racine de chaque entité puis cliquer **Rechercher tous les PDF et Word**. Le parcours descend dans toute l’arborescence sans imposer de position aux dossiers de statut et continue après chaque fichier trouvé. Il n’applique aucune limite logique au nombre de niveaux ou de fichiers. Les limites du système Windows (chemins longs, droits, réseau, mémoire disponible) restent applicables et les accès impossibles sont signalés. Les autres branches restent parcourues.

Formats détectés : PDF, DOC, DOCX, DOCM. Le compteur PDF est séparé du compteur Word. Aucun fichier n’est exécuté ni déplacé. La détection DOC/DOCM ne signifie pas que ces formats sont acceptés par le module de traitement, qui reste PDF/DOCX.

Chaque résultat conserve chemin complet, chemin relatif, niveaux intermédiaires, profondeur et statut reconnu dans le chemin. Un statut absent est Non déterminé ; plusieurs statuts différents sont Ambigu. Les dossiers nommés Historique, A PUBLIER ou À PUBLIER sont distingués. Les noms personnalisés de statuts restent configurables. Aucune réception n’est déduite de cet inventaire ; les copies et versions présentes restent comptées comme fichiers distincts.

L’interface montre les 200 premiers résultats ; Télécharger la liste complète CSV fournit tous les fichiers détectés. Les répertoires non lisibles et les liens non suivis rendent l’inventaire incomplet. La liste et le compteur peuvent changer si un dépôt intervient pendant le parcours. Les partages volumineux peuvent immobiliser temporairement le serveur : utiliser le script autonome pour lancer ce travail séparément si nécessaire.

Script autonome : Rechercher-Documents.ps1, accompagné de backup.ps1 et discovery.ps1. Il demande la racine si elle n’est pas fournie et crée un nouveau dossier INVENTAIRE à côté de l’application contenant documents.csv, anomalies.csv et inventaire.json. Le paramètre -Sortie permet de choisir un dossier neuf extérieur à la racine inspectée. Les fichiers existants ne sont pas écrasés. Le JSON conserve les valeurs exactes ; les CSV neutralisent les noms pouvant être interprétés comme formules.

Exemple dans PowerShell, depuis le dossier de l’application :

```powershell
.\Rechercher-Documents.ps1 -Racine "C:\Test\ACM" -Entite "ACM"
```

Le bouton Parcours des statuts directs conserve l’ancien aperçu et son import v0.7. La nouvelle recherche complète ne propose pas encore d’import depuis une structure de statuts imbriquée. Le résultat sert à identifier cette structure sans déplacer les fichiers.
