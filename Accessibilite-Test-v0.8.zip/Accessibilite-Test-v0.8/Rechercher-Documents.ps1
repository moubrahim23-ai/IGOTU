﻿param([string]$Racine,[string]$Entite='ACM',[string]$Sortie)
$ErrorActionPreference='Stop'
. (Join-Path $PSScriptRoot 'backup.ps1')
. (Join-Path $PSScriptRoot 'discovery.ps1')
if(-not $Racine){$Racine=Read-Host 'Chemin racine de votre entité'}
if(-not $Sortie){$Sortie=Join-Path $PSScriptRoot ('INVENTAIRE-'+[DateTime]::Now.ToString('yyyyMMdd-HHmmss')+'-'+[Guid]::NewGuid().ToString('N').Substring(0,6))}
$destination=Full-Path $Sortie
if(Inside-Path $destination $Racine){throw 'Choisir un dossier de résultat en dehors de la racine inspectée'}
if(Test-Path -LiteralPath $destination){throw 'Le dossier de résultat existe déjà : aucun écrasement'}
Assert-NoLink $destination
$folders=[pscustomobject]@{'A TRAITER'='A TRAITER';'EN COURS'='EN COURS';'NON CONFORME'='NON CONFORME';'TRAITES'='TRAITES'}
Write-Host 'Parcours en lecture seule. Les accès réseau peuvent prendre du temps.'
$result=Discover-Documents $Racine $Entite $folders
[IO.Directory]::CreateDirectory($destination)|Out-Null
$result|ConvertTo-Json -Depth 12|Set-Content -LiteralPath (Join-Path $destination 'inventaire.json') -Encoding UTF8
$safeRows=@($result.files|ForEach-Object {$row=$_|Select-Object *;foreach($property in $row.PSObject.Properties){if($property.Value -is [string] -and $property.Value -match '^[=+@\-\t\r\n]'){$property.Value="'"+$property.Value}};$row})
$safeRows|Export-Csv -LiteralPath (Join-Path $destination 'documents.csv') -Delimiter ';' -NoTypeInformation -Encoding UTF8
$result.issues|Export-Csv -LiteralPath (Join-Path $destination 'anomalies.csv') -Delimiter ';' -NoTypeInformation -Encoding UTF8
Write-Host ("PDF : {0} | Word : {1} | Dossiers parcourus : {2}" -f $result.pdf,$result.word,$result.directories)
if(-not $result.complete){Write-Warning 'Inventaire incomplet : consulter anomalies.csv. Les chiffres ne représentent pas un total fiable.'}
Write-Host ('Résultats : '+$destination)
