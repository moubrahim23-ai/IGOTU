# Vérification — Accessibilité v0.5

Exécution le 28 septembre 2026 sur copies temporaires isolées, avec PowerShell 7.4.14 sous Linux, Python et Node.js.

## 262 contrôles automatisés réussis

| Suite | Contrôles | Couverture |
|---|---:|---|
| workflow.ps1 | 29 | Réservation, rôles, pause/reprise, NC, clôture, publication fictive, horaires, journal |
| settings.ps1 | 30 | Paramètres, migration, droits, désactivation, horaires à la minute, fermetures |
| server_http.py | 22 | Serveur réel, contrôles de requête, conflits, sauvegarde, redémarrage |
| frontend.cjs | 41 | Vrai JS avec DOM simulé : filtres, rôles, paramètres et commandes de fichiers |
| files.ps1 | 36 | Vrais octets et déplacements : import, archive, homonymes, livrables, altération, NC, retour, réouverture, collisions, rollback |
| files_http.py | 14 | Import HTTP, téléchargement exact, déplacements sur disque et récupération au démarrage |
| backup.ps1 (tests) | 31 | Sauvegardes complètes, intégrité, rétention, échecs, copies corrompues et restauration sans écrasement |
| backup_http.py | 13 | Sauvegarde par API, script de restauration, démarrage du serveur restauré et téléchargement exact |

Les suites existantes ont été réexécutées sur la nouvelle version. Syntaxe JS et analyse syntaxique PowerShell vérifiées.

## Publication ACM : 46 contrôles supplémentaires

- `publication.ps1` : 32 contrôles des publications individuelles/globales, empreintes, rôles, liste périmée, homonymes, archivage, retrait, republication et annulation sur échec.
- `publication_http.py` : 14 contrôles par API réelle, téléchargement exact, sauvegarde de la publication et redémarrage après remplacement interrompu.
- Défaut corrigé pendant cette campagne : récupérer une transaction interrompue avant de recréer les répertoires au démarrage, pour ne pas créer de collision artificielle dans À PUBLIER.

## Incidents testés

- Destination déjà occupée : refus et conservation de la source.
- Échec de sauvegarde après déplacement : retour à la position et à l'état précédemment enregistrés.
- Interruption avant déplacement, après le premier ou le deuxième déplacement d'un remplacement de livrables, y compris entre déplacement et checkpoint : récupération des deux jeux de fichiers.
- Vrai redémarrage de processus avec un déplacement effectué mais non validé : restauration de la source, statut cohérent et original intact.
- Redémarrage avec une transaction déjà enregistrée mais un manifeste non clôturé : opération conservée, sans document dupliqué.

## Contrôles documentaires

Empreintes SHA-256 comparées pour la conservation des sources et la détection d'une altération des livrables après dépôt. Téléchargement comparé octet par octet. Données synthétiques utilisées : signature PDF et archives Office minimales, sans contenu client et sans certification de validité métier.

Le contrôle d'un fichier Office vérifie la structure minimale du conteneur. Le contrôle PDF vérifie une signature, pas le balisage ni l'absence de protection. L'audit peut être vide : le module de validation de ses critères n'est pas encore présent.

## Limites exactes

Windows PowerShell 5.1, verrous de fichiers Windows, chemins longs, applications Office et partages SMB n'ont pas été exécutés dans cet environnement. Aucun test ne prouve la résistance à une panne matérielle ou à toutes les coupures système. Les tests d'interruption reproduisent les états intermédiaires et la reprise, pas une panne électrique.

Le navigateur complet reste bloqué par les restrictions de l'environnement de développement. Les 41 tests JS utilisent un DOM simulé : ils ne valident pas le rendu ni les dialogues natifs de sélection de fichiers sous Chrome/Edge. browser.cjs reste un scénario fourni mais non validé ici.

Les sauvegardes quotidiennes comprennent désormais TEST-DATA et TEST-FILES, avec vérification des empreintes avant validation. Tests supplémentaires : destination inaccessible, corruption, fichier ajouté, chemin de manifeste traversant, restauration dans un dossier neuf, chronomètres en pause, refus d’écrasement et reprise du serveur restauré. Le serveur restauré a servi les octets exacts d’un document. L’installation initiale est restée intacte. La destination par défaut est sur le même disque ; une copie indépendante est à configurer pour les pannes de disque. Pas de connexion à un dossier client, pas de déploiement multi-postes.

## Rejouer

PowerShell : tests/workflow.ps1, tests/settings.ps1, tests/files.ps1, tests/backup.ps1.
Node.js : `node tests/frontend.cjs`.
Python : définir TEST_PWSH vers PowerShell, puis lancer tests/server_http.py (port 18091) et tests/files_http.py (port 18092) et tests/backup_http.py (ports 18093 et 18094). Les suites n'utilisent pas vos données de test personnelles.

Publication locale uniquement. La vérification de sauvegarde contrôle aussi les empreintes des copies publiées. Pour rejouer le module : tests/publication.ps1 et tests/publication_http.py (port 18095).

## Correctif v0.5.1

Voir CORRECTIF_SAUVEGARDE.txt. 23 nouveaux contrôles reparse réussis ; suites backup.ps1 (31) et backup_http.py (13) réexécutées. Les 262 contrôles ci-dessus concernent la v0.5, pas une réexécution complète sur v0.5.1. L’appel natif Windows reste à valider sur Windows.

## Campagne v0.6 — 28 septembre 2026 : 316 contrôles réussis

Toutes les suites ont été exécutées sur cette version sous PowerShell 7.4.14/Linux : workflow 29, settings 30, files 36, backup 31, publication 32, reparse 23, server_http 22, files_http 14, backup_http 13, publication_http 14, shares_http 24 et frontend 48.

Partages : tests API avec répertoires temporaires réels, configuration persistée au redémarrage, rôles, jeton et conflits de version, refus des chemins relatifs et racines imbriquées, statuts personnalisés, comptage PDF récursif, extensions majuscules, homonymes conservés, absence de mutation des fichiers et des réceptions, accès incomplet, lien non suivi, liste limitée à 200 PDF et total intégral. Les chemins UNC sont enregistrables ; leur accès SMB Windows n’a pas été exécuté ici. Le test de classement des reparse points compile le composant mais ne prouve pas l’appel natif Windows.

Les tests frontend utilisent un DOM simulé. Aucun rendu visuel en navigateur complet, aucun verrou réseau multi-postes et aucun droit d’écriture professionnel n’ont été validés. Le module partage reste en lecture seule.

## Campagne v0.7 — 28 septembre 2026 : 350 contrôles réussis

Suites réexécutées : workflow 29, settings 30, files 36, backup 31, publication 32, reparse 23, server_http 22, files_http 14, backup_http 13, publication_http 14, shares_http 24, frontend 52, share_import_http 30.

Import depuis partage : API et fichiers temporaires réels, rapprochement PDF/DOCX de même nom, confirmation et premier dépôt obligatoires, date future refusée, nature requise, refus de traversée et de lien, empreinte changée après aperçu, source conservée, archive et copie de travail identiques, provenance dans le journal et la sauvegarde, refus de double import avant et après redémarrage, orientation des versions modifiées vers la fiche existante et homonymes de dossiers différents conservés.

Une différence de conversion des dates JSON sous PowerShell 7 a été corrigée pendant les essais : la date est normalisée avant validation. Tests sous PowerShell 7/Linux, pas sur PowerShell 5.1 ni sur un partage Windows SMB. DOM simulé pour les tests JS, sans rendu navigateur complet. L’import est une copie locale, pas une réservation ni un déplacement sur le partage.

## Campagne v0.8 — 28 septembre 2026 : 377 contrôles réussis

Suites : workflow 29, settings 30, files 36, backup 31, publication 32, reparse 23, server_http 22, files_http 14, backup_http 13, publication_http 14, shares_http 28, frontend 56, share_import_http 30, discovery 19. Toutes exécutées sous PowerShell 7/Linux et Node/Python.

Découverte : PDF à 48 niveaux, poursuite après découverte, Word DOC/DOCX/DOCM, fichiers directement à la racine, statuts au milieu du chemin, historique distingué, statut ambigu, boucle symbolique refusée sans abandon des autres branches, racine manquante, chemins complets, exports JSON/CSV, refus d’écrasement et sources conservées. Endpoint manager testé avec configuration sauvegardée.

Aucune limite logicielle de profondeur ou de nombre de fichiers dans la découverte complète. Ce test ne garantit pas la prise en charge des chemins longs par Windows PowerShell 5.1 ou SMB ; les limitations et erreurs du système sont rapportées. Un inventaire en cours peut bloquer temporairement le serveur ; script autonome fourni pour exécution séparée. Pas de lecture du contenu ni validation documentaire dans la découverte. Les nouveaux tests frontend restent un DOM simulé, sans rendu navigateur complet.
