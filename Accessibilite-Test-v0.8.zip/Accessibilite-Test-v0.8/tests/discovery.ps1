$ErrorActionPreference='Stop'
$project=Split-Path $PSScriptRoot -Parent
. (Join-Path $project 'backup.ps1')
. (Join-Path $project 'discovery.ps1')
$count=0
function Check($name,$ok){if(-not $ok){throw "ECHEC $name"};$script:count++;Write-Output "OK $name"}
$base=Join-Path ([IO.Path]::GetTempPath()) ([Guid]::NewGuid().ToString('N'));$source=Join-Path $base 'ACM'
$map=[pscustomobject]@{'A TRAITER'='A TRAITER';'EN COURS'='EN COURS';'NON CONFORME'='NON CONFORME';'TRAITES'='TRAITES'}
try{
 [IO.Directory]::CreateDirectory($source)|Out-Null
 $deep=Join-Path $source 'Assurances biens/Offres/A TRAITER'
 foreach($n in 1..45){$deep=Join-Path $deep ('niveau'+$n)}
 [IO.Directory]::CreateDirectory($deep)|Out-Null
 [IO.File]::WriteAllText((Join-Path $deep 'fiche.PDF'),'PDF test')
 [IO.File]::WriteAllText((Join-Path $deep 'fiche.docx'),'Word test')
 [IO.File]::WriteAllText((Join-Path $source 'direct.doc'),'Word ancien')
 [IO.File]::WriteAllText((Join-Path $source 'direct.docm'),'Word macros')
 [IO.File]::WriteAllText((Join-Path $source 'audit.xlsx'),'audit')
 $archive=Join-Path $source 'Historique/A TRAITER';[IO.Directory]::CreateDirectory($archive)|Out-Null;[IO.File]::WriteAllText((Join-Path $archive 'version.pdf'),'archive')
 $ambiguous=Join-Path $source 'A TRAITER/EN COURS';[IO.Directory]::CreateDirectory($ambiguous)|Out-Null;[IO.File]::WriteAllText((Join-Path $ambiguous 'ambigu.pdf'),'ambigu')
 $r=Discover-Documents $source 'ACM' $map
 Check 'parcours complet sans statut à la racine' $r.complete
 Check 'PDF tous niveaux' ($r.pdf -eq 3)
 Check 'Word DOC DOCX DOCM détectés' ($r.word -eq 3)
 Check 'audit exclu des documents' ($r.other -eq 1)
 $f=@($r.files|Where-Object {$_.name -eq 'fiche.PDF'})[0]
 Check 'profondeur 48 conservée' ($f.depth -eq 48)
 Check 'chemin complet conservé' ($f.path -eq (Join-Path $deep 'fiche.PDF'))
 Check 'statut trouvé au milieu du chemin' ($f.status -eq 'A TRAITER')
 Check 'Word trouvé après PDF' (@($r.files|Where-Object {$_.name -eq 'fiche.docx'}).Count -eq 1)
 Check 'fichier racine sans statut explicite' (@($r.files|Where-Object {$_.name -eq 'direct.doc'})[0].status -eq 'Non déterminé')
 Check 'historique identifié' (@($r.files|Where-Object {$_.name -eq 'version.pdf'})[0].status -eq 'Historique / publication')
 Check 'statuts contradictoires non devinés' (@($r.files|Where-Object {$_.name -eq 'ambigu.pdf'})[0].status -eq 'Ambigu')
 $link=Join-Path $source 'boucle';New-Item -ItemType SymbolicLink -Path $link -Target $source|Out-Null
 $partial=Discover-Documents $source 'ACM' $map
 Check 'boucle non suivie' ($partial.pdf -eq 3 -and -not $partial.complete)
 Check 'chemin anomalie exact' ($partial.issues[0].path -eq $link)
 Check 'autres branches poursuivies' ($partial.word -eq 3)
 Remove-Item -LiteralPath $link -Force
 $missing=Discover-Documents (Join-Path $source 'absent') 'ACM' $map
 Check 'racine absente résultat incomplet' (-not $missing.complete -and $missing.issues.Count -eq 1)
 $out=Join-Path $base 'resultats'
 & (Join-Path $project 'Rechercher-Documents.ps1') -Racine $source -Entite ACM -Sortie $out|Out-Null
 Check 'export JSON complet' ((Get-Content (Join-Path $out 'inventaire.json') -Raw|ConvertFrom-Json).files.Count -eq 6)
 Check 'CSV tous documents' (@(Import-Csv (Join-Path $out 'documents.csv') -Delimiter ';').Count -eq 6)
 Check 'source inchangée' ([IO.File]::ReadAllText((Join-Path $deep 'fiche.PDF')) -eq 'PDF test')
 $failed=$false;try{& (Join-Path $project 'Rechercher-Documents.ps1') -Racine $source -Sortie $out|Out-Null}catch{$failed=$true};Check 'export existant non écrasé' $failed
 Write-Output "TOTAL: $count tests découverte réussis"
}finally{if(Test-Path -LiteralPath (Join-Path $source 'boucle')){Remove-Item -LiteralPath (Join-Path $source 'boucle') -Force};Remove-Item -LiteralPath $base -Recurse -Force}
