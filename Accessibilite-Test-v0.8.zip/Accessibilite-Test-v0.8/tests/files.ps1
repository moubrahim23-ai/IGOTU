﻿$ErrorActionPreference='Stop'
$project=Split-Path $PSScriptRoot -Parent
$source=Get-Content (Join-Path $project 'server.ps1') -Raw
$tokens=$null;$errors=$null
$ast=[System.Management.Automation.Language.Parser]::ParseInput($source,[ref]$tokens,[ref]$errors)
if($errors.Count){throw ($errors | Out-String)}
# Charger les vraies fonctions, sans lancer le serveur ni toucher TEST-DATA.
foreach($f in $ast.FindAll({param($n) $n -is [System.Management.Automation.Language.FunctionDefinitionAst]},$false)){Invoke-Expression $f.Extent.Text}
$store=Join-Path ([IO.Path]::GetTempPath()) ([Guid]::NewGuid().ToString('N'))
$root=$store
$commits=Join-Path $store 'commits';$backups=Join-Path $store 'backups'
New-Item -ItemType Directory -Path $commits,$backups -Force|Out-Null
$account='TEST';$session='TEST';$script:sequence=0;$script:actor='SYSTEME'
$script:state=Get-Content (Join-Path $project 'seed.json') -Raw|ConvertFrom-Json
$script:count=0
function Check($name,$condition){if(-not $condition){throw "ECHEC: $name"};$script:count++;Write-Output "OK $name"}
function Invoke-ActionTest($id,$action,$actor='HAMDANMO',$extra=@{}){
 $d=$script:state.docs|Where-Object id -eq $id
 $p=@{id=$id;action=$action;actor=$actor;version=$d.version;reason='Motif test'}
 foreach($k in $extra.Keys){$p[$k]=$extra[$k]}
 $snapshot=$script:state|ConvertTo-Json -Depth 30
 try{Action ([pscustomobject]$p)}catch{$script:state=$snapshot|ConvertFrom-Json;throw}
}
function Reject($name,[scriptblock]$op,$pattern){$failed=$false;try{& $op}catch{if($_.Exception.Message -notmatch $pattern){throw};$failed=$true};Check $name $failed}
function Doc($id){$script:state.docs|Where-Object id -eq $id}
# Horloge injectée uniquement dans ce test pour les horaires de prise en charge.
$script:testDate=[datetime]'2026-09-28T09:00:00'
function Get-Date {param($Format) if($Format){return $script:testDate.ToString($Format)};$script:testDate}
function Payload($name,[byte[]]$bytes){return [pscustomobject]@{name=$name;base64=[Convert]::ToBase64String($bytes)}}
function Office-Bytes($entry){
 Add-Type -AssemblyName System.IO.Compression
 $ms=[IO.MemoryStream]::new();$zip=[IO.Compression.ZipArchive]::new($ms,[IO.Compression.ZipArchiveMode]::Create,$true)
 foreach($name in @('[Content_Types].xml',$entry)){$e=$zip.CreateEntry($name);$w=[IO.StreamWriter]::new($e.Open());$w.Write('<test/>');$w.Dispose()}
 $zip.Dispose();$bytes=$ms.ToArray();$ms.Dispose();return ,$bytes
}
function File-Test($operation,$id,$files,$actor='MANAGER'){
 $d=Doc $id;$p=[pscustomobject]@{operation=$operation;actor=$actor;id=$id;version=$d.version;entity='ACM';nature='Conditions générales';files=@($files)}
 $snapshot=$script:state|ConvertTo-Json -Depth 30
 try{File-Request $p}catch{$script:state=$snapshot|ConvertFrom-Json;throw}
}
try{
 $root=$store;Init-Files;Save-State
 $pdf=Payload 'contrat.pdf' ([Text.Encoding]::ASCII.GetBytes('%PDF-1.4 test initial %%EOF'))
 $word=Payload 'contrat.docx' (Office-Bytes 'word/document.xml')
 $audit=Payload 'contrat.xlsx' (Office-Bytes 'xl/workbook.xml')
 Reject 'import agent interdit' {File-Test import '' @($pdf) HAMDANMO} 'réservé'
 Reject 'nom traversant interdit' {File-Test import '' @((Payload '../contrat.pdf' ([byte[]](1,2,3))))} 'Nom'
 Reject 'nom Windows réservé interdit' {File-Test import '' @((Payload 'CON.pdf' ([byte[]](1,2,3))))} 'Nom'
 Reject 'PDF signature invalide refusé' {File-Test import '' @((Payload 'faux.pdf' ([byte[]](1,2,3))))} 'signature PDF'
 Reject 'Office invalide refusé' {File-Test import '' @((Payload 'faux.docx' ([byte[]](1,2,3))))} 'DOCX'
 Reject 'double PDF refusé' {File-Test import '' @($pdf,$pdf)} 'seul fichier'
 Reject 'sortie espace local refusée' {File-Path '../ailleurs'} 'hors espace'
 File-Test import '' @($pdf,$word);$d=$script:state.docs[-1];$id=$d.id;$received=$d.received
 Check 'import réel ajouté' ($d.physical -and $d.word -and $d.status -eq 'A TRAITER')
 $original=File-Path ('Historique/'+$id+'/V001/contrat.pdf');$hash=File-Hash $original
 Check 'source et original identiques' ((File-Hash (File-Path ('A TRAITER/'+$id+'/Source/contrat.pdf'))) -eq $hash)
 File-Test import '' @($pdf,$word)
 Check 'homonyme sans écrasement' ($script:state.docs[-1].id -ne $id -and (File-Hash $original) -eq $hash)
 Invoke-ActionTest $id take
 Check 'prise déplace tout le dossier' ((Test-Path -LiteralPath (File-Path ('EN COURS/'+$id+'/Source/contrat.docx'))) -and -not (Test-Path -LiteralPath (File-Path ('A TRAITER/'+$id))))
 Reject 'simulation de livrables interdite' {Invoke-ActionTest $id package} 'vrais fichiers'
 Reject 'clôture sans fichiers refusée' {Invoke-ActionTest $id close} 'non déposés'
 Reject 'Word final obligatoire' {File-Test package $id @($pdf,$audit) HAMDANMO} 'incomplets'
 Reject 'dépôt autre agent interdit' {File-Test package $id @($pdf,$word,$audit) RMAIDIIM} 'collaborateur'
 File-Test package $id @($pdf,$word,$audit) HAMDANMO
 Check 'livrables déposés' ((Doc $id).packageReady -and (Test-Path -LiteralPath (File-Path ('EN COURS/'+$id+'/Livrables/contrat.xlsx'))))
 File-Test package $id @($pdf,$word,$audit) HAMDANMO
 Check 'anciens livrables archivés' (@(Get-ChildItem -LiteralPath (File-Path ('Historique/'+$id)) -Directory -Filter 'Final-*').Count -eq 1)
 $final=File-Path ('EN COURS/'+$id+'/Livrables/contrat.pdf');[IO.File]::WriteAllText($final,'altération')
 Reject 'livrable modifié détecté' {Invoke-ActionTest $id close} 'modifié'
 File-Test package $id @($pdf,$word,$audit) HAMDANMO
 Invoke-ActionTest $id close
 Check 'clôture déplace les fichiers' ((Doc $id).status -eq 'TRAITES' -and (Test-Path -LiteralPath (File-Path ('TRAITES/'+$id+'/Livrables/contrat.xlsx'))))
 Invoke-ActionTest $id publish MANAGER
 Check 'publication physique réelle' (Test-Path -LiteralPath (File-Path ('A PUBLIER/'+$id+'/contrat.pdf')))
 Invoke-ActionTest $id reopen MANAGER
 Check 'réouverture archive livrables' ((Doc $id).status -eq 'A TRAITER' -and -not (Doc $id).finished -and -not (Test-Path -LiteralPath (File-Path ('A TRAITER/'+$id+'/Livrables'))))
 Invoke-ActionTest $id block MANAGER
 Check 'NC déplacement réel' (Test-Path -LiteralPath (File-Path ('NON CONFORME/'+$id+'/Source/contrat.pdf')))
 Reject 'retour Word absent refusé' {File-Test return $id @($pdf)} 'DOCX'
 $corrected=Payload 'contrat.pdf' ([Text.Encoding]::ASCII.GetBytes('%PDF-1.4 test corrige %%EOF'))
 File-Test return $id @($corrected,$word)
 Check 'retour nouvelle version' ((Doc $id).sourceVersion -eq 2 -and (Test-Path -LiteralPath (File-Path ('Historique/'+$id+'/V002/contrat.pdf'))))
 Check 'premier dépôt et original préservés' ((Doc $id).received -eq $received -and (File-Hash $original) -eq $hash)
 Check 'ancienne NC retirée' (-not (Test-Path -LiteralPath (File-Path ('NON CONFORME/'+$id))))
 # Collision : aucune suppression, aucune transaction en attente.
 [IO.Directory]::CreateDirectory((File-Path ('EN COURS/'+$id)))|Out-Null
 Reject 'collision destination refusée' {Invoke-ActionTest $id take} 'occupée'
 Check 'source conservée après collision' ((Test-Path -LiteralPath (File-Path ('A TRAITER/'+$id+'/Source/contrat.pdf'))) -and -not (Test-Path -LiteralPath (File-Path 'transactions/pending.json')))
 [IO.Directory]::Delete((File-Path ('EN COURS/'+$id)))
 # Échec de persistance après déplacement : annulation du déplacement.
 $saveBody=${function:Save-State}
 function Save-State {throw 'DISQUE_TEST'}
 try{Reject 'échec sauvegarde signalé' {Invoke-ActionTest $id take} 'DISQUE_TEST'}finally{Set-Item Function:Save-State $saveBody}
 Check 'déplacement annulé après échec' ((Test-Path -LiteralPath (File-Path ('A TRAITER/'+$id+'/Source/contrat.pdf'))) -and -not (Test-Path -LiteralPath (File-Path ('EN COURS/'+$id))))
 # Coupures au début, entre opérations et entre déplacement/checkpoint.
 foreach($scenario in @(@(0,0),@(1,0),@(1,1),@(2,1),@(2,2))){
  $prefix='staging/recovery-'+[Guid]::NewGuid().ToString('N');$old=$prefix+'/old';$new=$prefix+'/new';$archive=$prefix+'/archive'
  [IO.Directory]::CreateDirectory((File-Path $old))|Out-Null;[IO.Directory]::CreateDirectory((File-Path $new))|Out-Null
  [IO.File]::WriteAllText((File-Path ($old+'/old.txt')),'ancien');[IO.File]::WriteAllText((File-Path ($new+'/new.txt')),'nouveau')
  $tx=[pscustomobject]@{id=[Guid]::NewGuid().ToString('N');phase='forward';done=$scenario[1];moves=@((Move-Spec $old $archive),(Move-Spec $new $old))}
  Save-FileManifest $tx
  for($i=0;$i -lt $scenario[0];$i++){[IO.Directory]::Move((File-Path $tx.moves[$i].from),(File-Path $tx.moves[$i].to))}
  Resolve-FileTransaction
  Check "récupération déplacement $($scenario[0]) checkpoint $($scenario[1])" ((Test-Path -LiteralPath (File-Path ($old+'/old.txt'))) -and (Test-Path -LiteralPath (File-Path ($new+'/new.txt'))) -and -not (Test-Path -LiteralPath (File-Path $archive)))
 }
 Check 'aucune transaction en attente' (-not (Test-Path -LiteralPath (File-Path 'transactions/pending.json')))
 Write-Output "TOTAL: $script:count tests fichiers réussis"
}finally{Remove-Item $store -Recurse -Force}
