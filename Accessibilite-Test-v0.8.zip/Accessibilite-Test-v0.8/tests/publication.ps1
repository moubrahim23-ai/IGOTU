﻿$ErrorActionPreference='Stop'
$project=Split-Path $PSScriptRoot -Parent
$source=Get-Content (Join-Path $project 'server.ps1') -Raw
$tokens=$null;$errors=$null
$ast=[System.Management.Automation.Language.Parser]::ParseInput($source,[ref]$tokens,[ref]$errors)
if($errors.Count){throw ($errors | Out-String)}
# Charger les vraies fonctions, sans lancer le serveur ni toucher TEST-DATA.
foreach($f in $ast.FindAll({param($n) $n -is [System.Management.Automation.Language.FunctionDefinitionAst]},$false)){Invoke-Expression $f.Extent.Text}
$store=Join-Path ([IO.Path]::GetTempPath()) ([Guid]::NewGuid().ToString('N'))
$root=$store
$commits=Join-Path $store 'commits';$backups=Join-Path $store 'backups'
New-Item -ItemType Directory -Path $commits,$backups -Force|Out-Null
$account='TEST';$session='TEST';$script:sequence=0;$script:actor='SYSTEME'
$script:state=Get-Content (Join-Path $project 'seed.json') -Raw|ConvertFrom-Json
$script:count=0
function Check($name,$condition){if(-not $condition){throw "ECHEC: $name"};$script:count++;Write-Output "OK $name"}
function Invoke-ActionTest($id,$action,$actor='HAMDANMO',$extra=@{}){
 $d=$script:state.docs|Where-Object id -eq $id
 $p=@{id=$id;action=$action;actor=$actor;version=$d.version;reason='Motif test'}
 foreach($k in $extra.Keys){$p[$k]=$extra[$k]}
 $snapshot=$script:state|ConvertTo-Json -Depth 30
 try{Action ([pscustomobject]$p)}catch{$script:state=$snapshot|ConvertFrom-Json;throw}
}
function Reject($name,[scriptblock]$op,$pattern){$failed=$false;try{& $op}catch{if($_.Exception.Message -notmatch $pattern){throw};$failed=$true};Check $name $failed}
function Doc($id){$script:state.docs|Where-Object id -eq $id}
# Horloge injectée uniquement dans ce test pour les horaires de prise en charge.
$script:testDate=[datetime]'2026-09-28T09:00:00'
function Get-Date {param($Format) if($Format){return $script:testDate.ToString($Format)};$script:testDate}
function Payload($name,[byte[]]$bytes){return [pscustomobject]@{name=$name;base64=[Convert]::ToBase64String($bytes)}}
function Office-Bytes($entry){
 Add-Type -AssemblyName System.IO.Compression
 $ms=[IO.MemoryStream]::new();$zip=[IO.Compression.ZipArchive]::new($ms,[IO.Compression.ZipArchiveMode]::Create,$true)
 foreach($name in @('[Content_Types].xml',$entry)){$e=$zip.CreateEntry($name);$w=[IO.StreamWriter]::new($e.Open());$w.Write('<test/>');$w.Dispose()}
 $zip.Dispose();$bytes=$ms.ToArray();$ms.Dispose();return ,$bytes
}
function File-Test($operation,$id,$files,$actor='MANAGER'){
 $d=Doc $id;$p=[pscustomobject]@{operation=$operation;actor=$actor;id=$id;version=$d.version;entity='ACM';nature='Conditions générales';files=@($files)}
 $snapshot=$script:state|ConvertTo-Json -Depth 30
 try{File-Request $p}catch{$script:state=$snapshot|ConvertFrom-Json;throw}
}
. (Join-Path $project 'backup.ps1')
function New-Finished($entity){
 File-Request ([pscustomobject]@{actor='MANAGER';operation='import';entity=$entity;nature='Conditions générales';files=@($pdf)})
 $id=$script:state.docs[-1].id;Invoke-ActionTest $id take;File-Test package $id @($pdf,$audit) HAMDANMO;Invoke-ActionTest $id close
 return $id
}
function Publish-AllTest($token,$actor='MANAGER'){
 $snapshot=$script:state|ConvertTo-Json -Depth 30
 try{return (Publication-Request ([pscustomobject]@{actor=$actor;operation='publish-all';token=$token}))}catch{$script:state=$snapshot|ConvertFrom-Json;throw}
}
try{
 $root=$store;Init-Files;Save-State
 $pdf=Payload 'contrat.pdf' ([Text.Encoding]::ASCII.GetBytes('%PDF-1.4 publication initiale %%EOF'))
 $audit=Payload 'audit.xlsx' (Office-Bytes 'xl/workbook.xml')
 $plan=Publication-Plan
 Check 'apercu vide hors exemples fictifs' ($plan.count -eq 0 -and $plan.weeklyUpdateDue)
 Reject 'publication vide refusee' {Publish-AllTest $plan.token} 'Aucun document'
 $id1=New-Finished ACM;$id2=New-Finished ACM;$other=New-Finished DIRCO
 $plan=Publication-Plan;Check 'seulement ACM importes traites' ($plan.count -eq 2)
 Reject 'publication globale agent refusee' {Publish-AllTest $plan.token HAMDANMO} 'manager'
 Reject 'publication individuelle agent refusee' {Invoke-ActionTest $id1 publish HAMDANMO} 'réservée'
 Reject 'autre entite publication refusee' {Invoke-ActionTest $other publish MANAGER} 'ACM'
 Invoke-ActionTest $id1 publish MANAGER
 $published=File-Path ('A PUBLIER/'+$id1+'/contrat.pdf')
 Check 'publication individuelle identique' ((File-Hash $published) -eq (Doc $id1).finalFiles[0].sha256)
 Check 'source traite conservee' (Test-Path -LiteralPath (File-Path ('TRAITES/'+$id1+'/Livrables/contrat.pdf')))
 $plan=Publication-Plan
 Invoke-ActionTest $id2 assign MANAGER @{owner='RMAIDIIM';priority='Haute'}
 Reject 'apercu perime refuse' {Publish-AllTest $plan.token} 'changé'
 $plan=Publication-Plan;[IO.File]::WriteAllText((File-Path 'A PUBLIER/ancien.txt'),'ancien contenu')
 Reject 'changement contenu publication detecte' {Publish-AllTest $plan.token} 'changé'
 $plan=Publication-Plan;$result=Publish-AllTest $plan.token
 Check 'publication globale deux dossiers' (@(Get-ChildItem -LiteralPath (File-Path 'A PUBLIER') -Directory).Count -eq 2)
 Check 'ancien contenu archive' (Test-Path -LiteralPath (Join-Path (Join-Path $root $result.archive) 'ancien.txt'))
 Check 'ancien contenu retire destination' (-not (Test-Path -LiteralPath (File-Path 'A PUBLIER/ancien.txt')))
 Check 'homonymes isoles' ((Test-Path -LiteralPath (File-Path ('A PUBLIER/'+$id1+'/contrat.pdf'))) -and (Test-Path -LiteralPath (File-Path ('A PUBLIER/'+$id2+'/contrat.pdf'))))
 Check 'compteurs publication journalises' ((Doc $id1).publicationCount -eq 2 -and (Doc $id2).publicationCount -eq 1 -and $script:state.events[-1].action -eq 'PUBLICATION_ACM_GLOBALE')
 Check 'rappel hebdomadaire actualise' (-not (Publication-Plan).weeklyUpdateDue)
 # Livrable altéré : ancienne publication intégralement conservée.
 $final=File-Path ('TRAITES/'+$id1+'/Livrables/contrat.pdf');$bytes=[IO.File]::ReadAllBytes($final);$publishedHash=File-Hash $published
 [IO.File]::WriteAllText($final,'alteration')
 Reject 'source alteree refuse publication globale' {Publish-AllTest (Publication-Plan).token} 'altéré'
 Check 'ancienne copie conservee apres refus' ((File-Hash $published) -eq $publishedHash)
 [IO.File]::WriteAllBytes($final,$bytes)
 # Échec de sauvegarde du nouvel état : rollback des deux dossiers de publication.
 $saveBody=${function:Save-State};function Save-State {throw 'DISQUE_TEST'}
 try{Reject 'echec commit publication remonte' {Publish-AllTest (Publication-Plan).token} 'DISQUE_TEST'}finally{Set-Item Function:Save-State $saveBody}
 Check 'publication restauree apres echec' ((File-Hash $published) -eq $publishedHash -and (Test-Path -LiteralPath (File-Path ('A PUBLIER/'+$id2+'/contrat.pdf'))))
 Invoke-ActionTest $id1 reopen MANAGER
 Check 'reouverture retire publication' (-not (Test-Path -LiteralPath (File-Path ('A PUBLIER/'+$id1))) -and -not (Doc $id1).published -and (Doc $id1).wasPublished)
 Check 'autre publication conservee' (Test-Path -LiteralPath (File-Path ('A PUBLIER/'+$id2+'/contrat.pdf')))
 Check 'copie retiree archivee' (@(Get-ChildItem -LiteralPath (File-Path ('Historique/'+$id1)) -Directory -Filter 'Publication-*').Count -ge 1)
 Invoke-ActionTest $id1 take
 $corrected=Payload 'contrat.pdf' ([Text.Encoding]::ASCII.GetBytes('%PDF-1.4 publication corrigee %%EOF'))
 File-Test package $id1 @($corrected,$audit) HAMDANMO
 # Collision publication : clôture doit échouer sans passer en traité.
 [IO.File]::WriteAllText((File-Path ('A PUBLIER/'+$id1)),'collision')
 Reject 'collision republication refuse cloture' {Invoke-ActionTest $id1 close} 'Source absente|destination occupée'
 Check 'statut reste en cours apres echec' ((Doc $id1).status -eq 'EN COURS' -and (Test-Path -LiteralPath (File-Path ('EN COURS/'+$id1+'/Livrables/contrat.pdf'))))
 [IO.File]::Delete((File-Path ('A PUBLIER/'+$id1)))
 Invoke-ActionTest $id1 close
 Check 'cloture republie automatiquement' ((Doc $id1).published -and (Doc $id1).status -eq 'TRAITES' -and (File-Hash $published) -eq (Doc $id1).finalFiles[0].sha256)
 Check 'nouvelle version remplace publication' ((File-Hash $published) -ne $publishedHash)
 Check 'republication journalisee' ($script:state.events[-1].action -eq 'CLOTURE_ET_REPUBLICATION_ACM')
 # Une clôture jamais publiée reste non publiée.
 Check 'autre entite non publiee' (-not (Doc $other).published)
 # Si la copie disparaît hors application, refuser la réouverture jusqu'à réparation.
 [IO.Directory]::Move((File-Path ('A PUBLIER/'+$id2)),(File-Path ('staging/copie-externe-'+$id2)))
 Reject 'copie disparue signalee' {Invoke-ActionTest $id2 reopen MANAGER} 'manquante'
 Invoke-ActionTest $id2 publish MANAGER
 Check 'republication manuelle repare copie absente' (Test-Path -LiteralPath (File-Path ('A PUBLIER/'+$id2+'/contrat.pdf')))
 Check 'aucune transaction en attente' (-not (Test-Path -LiteralPath (File-Path 'transactions/pending.json')))
 Write-Output "TOTAL: $script:count tests publication réussis"
}finally{Remove-Item $store -Recurse -Force}
