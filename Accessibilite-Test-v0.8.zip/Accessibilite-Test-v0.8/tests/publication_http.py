"""API réelle sur un état de test préparé : un ACM déjà traité avec livrables synthétiques."""
import hashlib,io,json,os,shutil,subprocess,tempfile,time,urllib.request,urllib.error,uuid,zipfile
from pathlib import Path
root=Path(__file__).resolve().parents[1];base='http://127.0.0.1:18095';count=0

def check(name,ok):
 global count
 assert ok,name
 count+=1;print('OK',name,flush=True)
def req(path='/api/state',data=None,headers=None):
 r=urllib.request.Request(base+path,data=None if data is None else json.dumps(data).encode(),headers=headers or {})
 try:
  with urllib.request.urlopen(r,timeout=30) as f:return f.status,f.read()
 except urllib.error.HTTPError as e:return e.code,e.read()
with tempfile.TemporaryDirectory() as folder:
 app=Path(folder)
 for f in ['server.ps1','backup.ps1','seed.json']:shutil.copy(root/f,app/f)
 shutil.copytree(root/'web',app/'web')
 seed=json.loads((app/'seed.json').read_text());doc=dict(seed['docs'][0]);docid='F-1234567890abcdef'
 pdf=b'%PDF-1.4 publication HTTP %%EOF';buf=io.BytesIO()
 with zipfile.ZipFile(buf,'w') as z:z.writestr('[Content_Types].xml','<test/>');z.writestr('xl/workbook.xml','<test/>')
 audit=buf.getvalue()
 def meta(name,content):return {'name':name,'ext':Path(name).suffix,'size':len(content),'sha256':hashlib.sha256(content).hexdigest().upper()}
 doc.update(id=docid,entity='ACM',word=False,status='TRAITES',owner='HAMDANMO',physical=True,received='2026-09-25T09:00:00Z',sourceVersion=1,sourceFiles=[meta('doc.pdf',pdf)],finalFiles=[meta('doc.pdf',pdf),meta('audit.xlsx',audit)],packageReady=True,finished='2026-09-25T16:00:00Z')
 seed['docs'].append(doc);(app/'seed.json').write_text(json.dumps(seed))
 for rel,content in [('TRAITES/'+docid+'/Source/doc.pdf',pdf),('TRAITES/'+docid+'/Livrables/doc.pdf',pdf),('TRAITES/'+docid+'/Livrables/audit.xlsx',audit),('Historique/'+docid+'/V001/doc.pdf',pdf)]:
  p=app/'TEST-FILES'/rel;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(content)
 log=open(app/'test.log','w')
 def start():
  p=subprocess.Popen([os.environ['TEST_PWSH'],'-NoProfile','-File',str(app/'server.ps1'),'-Port','18095'],stdout=log,stderr=log)
  for _ in range(100):
   try:
    if req()[0]==200:return p
   except OSError:pass
   time.sleep(.1)
  p.terminate();raise RuntimeError((app/'test.log').read_text())
 def headers():return {'Origin':base,'X-CSRF-Token':json.loads(req()[1])['token'],'Content-Type':'application/json'}
 p=start()
 try:
  check('aperçu manager via HTTP',req('/api/publication',{'actor':'MANAGER','operation':'preview'},headers())[0]==200)
  check('aperçu agent refusé',req('/api/publication',{'actor':'HAMDANMO','operation':'preview'},headers())[0]==400)
  plan=json.loads(req('/api/publication',{'actor':'MANAGER','operation':'preview'},headers())[1])['result']
  check('aperçu exclut fictifs',plan['count']==1)
  check('jeton périmé refusé',req('/api/publication',{'actor':'MANAGER','operation':'publish-all','token':'invalide'},headers())[0]==400)
  check('publication globale HTTP',req('/api/publication',{'actor':'MANAGER','operation':'publish-all','token':plan['token']},headers())[0]==200)
  check('téléchargement copie publiée exact',req('/api/file/'+docid+'/published/0')[1]==pdf)
  check('audit également publié',(app/'TEST-FILES/A PUBLIER'/docid/'audit.xlsx').read_bytes()==audit)
  s=json.loads(req()[1])['state'];check('aucune réception ajoutée',len(s['docs'])==6)
  check('sauvegarde publication valide',req('/api/backup',{'actor':'MANAGER','operation':'create'},headers())[0]==200)
  s=json.loads(req()[1])['state'];backup=app/'SAUVEGARDES'/s['backup']['lastId']
  check('copie publiée dans sauvegarde',(backup/'payload/TEST-FILES/A PUBLIER'/docid/'doc.pdf').read_bytes()==pdf)
  p.terminate();p.wait(timeout=5)
  files=app/'TEST-FILES';stage='staging/publication-interrompue';archive='Historique/Publication-ACM/interruption'
  shutil.copytree(files/'A PUBLIER',files/stage);(files/archive).parent.mkdir(parents=True,exist_ok=True)
  tx={'id':uuid.uuid4().hex,'phase':'forward','done':1,'moves':[{'from':'A PUBLIER','to':archive},{'from':stage,'to':'A PUBLIER'}]}
  (files/'transactions/pending.json').write_text(json.dumps(tx));(files/'A PUBLIER').rename(files/archive)
  p=start()
  check('ancienne publication restaurée au redémarrage',req('/api/file/'+docid+'/published/0')[1]==pdf)
  d=json.loads(req()[1])['state']['docs'][-1]
  check('réouverture manager HTTP',req('/api/action',{'actor':'MANAGER','id':docid,'version':d['version'],'action':'reopen','reason':'Correction de test'},headers())[0]==200)
  check('copie retirée après réouverture',not (files/'A PUBLIER'/docid).exists())
  check('téléchargement publié refusé après retrait',req('/api/file/'+docid+'/published/0')[0]==400)
  print('TOTAL:',count,'tests HTTP publication réussis')
 finally:p.terminate();p.wait(timeout=5);log.close()
