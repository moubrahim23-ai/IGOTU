$ErrorActionPreference='Stop'
. (Join-Path (Split-Path $PSScriptRoot -Parent) 'backup.ps1')
Initialize-ReparseReader
$count=0
foreach($n in 0..15){if(-not (Test-CloudTag ([uint32](2415919130+$n*4096)))){throw 'Tag cloud refusé'};$count++}
foreach($tag in @([uint32]2684354563,[uint32]2684354572,[uint32]2415919131,[uint32]0)){if(Test-CloudTag $tag){throw 'Tag non cloud accepté'};$count++}
$folder=Join-Path ([IO.Path]::GetTempPath()) ([Guid]::NewGuid().ToString('N'))
try{
 [IO.Directory]::CreateDirectory($folder)|Out-Null
 Assert-NoLink $folder;$count++
 $target=Join-Path $folder 'target';[IO.Directory]::CreateDirectory($target)|Out-Null
 $link=Join-Path $folder 'link'
 New-Item -ItemType SymbolicLink -Path $link -Target $target|Out-Null
 $rejected=$false;try{Assert-NoLink (Join-Path $link 'future')}catch{if(-not $_.Exception.Message.Contains($link)){throw};$rejected=$true}
 if(-not $rejected){throw 'Lien ancêtre accepté'};$count++
 $rejected=$false;try{Tree-Files $folder|Out-Null}catch{$rejected=$true};if(-not $rejected){throw 'Lien dans données accepté'};$count++
 Write-Output "TOTAL: $count contrôles reparse réussis (appel natif Windows non exécuté hors Windows)"
}finally{if(Test-Path $link){Remove-Item -LiteralPath $link -Force};Remove-Item -LiteralPath $folder -Recurse -Force}
