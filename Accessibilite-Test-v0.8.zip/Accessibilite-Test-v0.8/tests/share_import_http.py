import io,zipfile,hashlib,json,os,shutil,subprocess,tempfile,time,urllib.request,urllib.error
from pathlib import Path
root=Path(__file__).resolve().parents[1];base='http://127.0.0.1:18097';count=0

def check(name,ok):
 global count
 assert ok,name
 count+=1;print('OK',name,flush=True)
def req(data=None,headers=None,path='/api/shares'):
 request=urllib.request.Request(base+path,data=None if data is None else json.dumps(data).encode(),headers=headers or {})
 try:
  with urllib.request.urlopen(request,timeout=30) as f:return f.status,f.read()
 except urllib.error.HTTPError as e:return e.code,e.read()
def state():return json.loads(req(path='/api/state')[1])
with tempfile.TemporaryDirectory() as temp:
 app=Path(temp)/'app';app.mkdir();share=Path(temp)/'entite';share.mkdir()
 statuses=['A TRAITER','EN COURS','NON CONFORME','TRAITES'];folders={s:s for s in statuses};folders['TRAITES']='Traités'
 for directory in folders.values():(share/directory).mkdir()
 (share/'A TRAITER/a.pdf').write_bytes(b'%PDF-1.4 source original');buf=io.BytesIO()
 with zipfile.ZipFile(buf,'w') as z:z.writestr('[Content_Types].xml','<test/>');z.writestr('word/document.xml','<test/>')
 (share/'A TRAITER/a.docx').write_bytes(buf.getvalue());(share/'A TRAITER/a.xlsx').write_bytes(b'audit')
 (share/'A TRAITER/sous').mkdir();(share/'A TRAITER/sous/a.pdf').write_bytes(b'%PDF-1.4 autre version')
 (share/'Traités/fini.PDF').write_bytes(b'%PDF fini')
 def inventory():return {str(f.relative_to(share)):hashlib.sha256(f.read_bytes()).hexdigest() for f in share.rglob('*') if f.is_file()}
 before=inventory()
 for file in ['server.ps1','backup.ps1','seed.json']:shutil.copy(root/file,app/file)
 shutil.copytree(root/'web',app/'web');log=open(app/'server.log','w')
 def start():
  p=subprocess.Popen([os.environ['TEST_PWSH'],'-NoProfile','-File',str(app/'server.ps1'),'-Port','18097'],stdout=log,stderr=log)
  for _ in range(100):
   try:
    if req(path='/api/state')[0]==200:return p
   except OSError:pass
   time.sleep(.1)
  p.terminate();raise RuntimeError((app/'server.log').read_text())
 p=start()
 try:
  def headers():return {'Origin':base,'X-CSRF-Token':state()['token'],'Content-Type':'application/json'}
  def call(payload):return req({'actor':'MANAGER',**payload},headers())
  row={'entity':'ACM','root':str(share),'folders':folders}
  check('configuration import',call({'operation':'configure','version':1,'rows':[row]})[0]==200)
  prep={'operation':'prepare-import','entity':'ACM','version':2,'relative':'a.pdf'}
  check('agent import refusé',call({**prep,'actor':'HAMDANMO'})[0]==400)
  check('version configuration périmée refusée',call({**prep,'version':1})[0]==400)
  check('traversée refusée',call({**prep,'relative':'../Traités/fini.PDF'})[0]==400)
  check('autre format refusé',call({**prep,'relative':'a.docx'})[0]==400)
  check('PDF absent refusé',call({**prep,'relative':'absent.pdf'})[0]==400)
  code,raw=call(prep);plan=json.loads(raw)['result']
  check('aperçu PDF et Word',code==200 and plan['word'] and len(plan['files'])==2)
  check('aperçu sans création',len(state()['state']['docs'])==5 and inventory()==before)
  payload={**plan,'operation':'import','nature':'Conditions générales','received':'2026-09-01T09:00:00Z','confirmSource':True}
  check('confirmation requise',call({**payload,'confirmSource':False})[0]==400)
  check('date requise',call({**payload,'received':''})[0]==400)
  check('date future refusée',call({**payload,'received':'2099-01-01T09:00:00Z'})[0]==400)
  check('nature requise',call({**payload,'nature':''})[0]==400)
  (share/'A TRAITER/a.pdf').write_bytes(b'%PDF-1.4 modification')
  check('source changée depuis aperçu refusée',call(payload)[0]==400)
  plan=json.loads(call(prep)[1])['result'];payload={**payload,**plan,'operation':'import'}
  before=inventory();code,raw=call(payload);check('import réel réussi : '+raw.decode(),code==200)
  doc=state()['state']['docs'][-1];docid=doc['id']
  check('statut à traiter et origine Word',doc['status']=='A TRAITER' and doc['word'])
  check('premier dépôt préservé',doc['received'].startswith('2026-09-01T09:00:00'))
  check('provenance enregistrée',doc['shareOrigin']['path']==str(share/'A TRAITER/a.pdf'))
  check('source inchangée',inventory()==before)
  check('archive exacte PDF et Word',all((app/'TEST-FILES/Historique'/docid/'V001'/name).read_bytes()==(share/'A TRAITER'/name).read_bytes() for name in ['a.pdf','a.docx']))
  check('copie de travail exacte',(app/'TEST-FILES/A TRAITER'/docid/'Source/a.pdf').read_bytes()==(share/'A TRAITER/a.pdf').read_bytes())
  check('journal import distinct',state()['state']['events'][-1]['action']=='IMPORT_DEPUIS_PARTAGE')
  check('sauvegarde complète après import',req({'actor':'MANAGER','operation':'create'},headers(),path='/api/backup')[0]==200)
  snapshot=state()['state'];backup=app/'SAUVEGARDES'/snapshot['backup']['lastId'];manifest=json.loads((backup/'manifest.json').read_text(encoding='utf-8-sig'));commit=backup/'payload/TEST-DATA/commits'/f"{int(manifest['sequence']):012d}.json";restored=json.loads(commit.read_text(encoding='utf-8-sig'))
  check('provenance et sources sauvegardées',restored['docs'][-1]['shareOrigin']['path']==doc['shareOrigin']['path'] and (backup/'payload/TEST-FILES/Historique'/docid/'V001/a.docx').read_bytes()==(share/'A TRAITER/a.docx').read_bytes())
  check('double clic sans doublon',call(payload)[0]==400 and len(state()['state']['docs'])==6)
  p.terminate();p.wait(timeout=5);p=start()
  check('doublon bloqué après redémarrage',call(prep)[0]==400)
  (share/'A TRAITER/a.pdf').write_bytes(b'%PDF-1.4 nouvelle version')
  code,raw=call(prep);check('version corrigée renvoie vers fiche',code==400 and docid in json.loads(raw)['error'] and len(state()['state']['docs'])==6)
  code,raw=call({**prep,'relative':'sous/a.pdf'});plan=json.loads(raw)['result']
  check('homonyme autre dossier reste distinct',code==200 and not plan['word'])
  check('homonyme importable',call({**payload,**plan,'operation':'import'})[0]==200 and len(state()['state']['docs'])==7)
  (share/'A TRAITER/lien.pdf').symlink_to(share/'Traités/fini.PDF')
  check('lien source refusé',call({**prep,'relative':'lien.pdf'})[0]==400)
  (share/'A TRAITER/invalide.pdf').write_bytes(b'pas un PDF')
  check('signature invalide refusée',call({**prep,'relative':'invalide.pdf'})[0]==400)
  print('TOTAL:',count,'tests HTTP import depuis partage réussis')

 finally:p.terminate();p.wait(timeout=5);log.close()
