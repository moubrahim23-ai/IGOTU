import hashlib,json,os,shutil,subprocess,tempfile,time,urllib.request,urllib.error
from pathlib import Path
root=Path(__file__).resolve().parents[1];base='http://127.0.0.1:18096';count=0

def check(name,ok):
 global count
 assert ok,name
 count+=1;print('OK',name,flush=True)
def req(data=None,headers=None,path='/api/shares'):
 request=urllib.request.Request(base+path,data=None if data is None else json.dumps(data).encode(),headers=headers or {})
 try:
  with urllib.request.urlopen(request,timeout=30) as f:return f.status,f.read()
 except urllib.error.HTTPError as e:return e.code,e.read()
def state():return json.loads(req(path='/api/state')[1])
with tempfile.TemporaryDirectory() as temp:
 app=Path(temp)/'app';app.mkdir();share=Path(temp)/'entite';share.mkdir()
 statuses=['A TRAITER','EN COURS','NON CONFORME','TRAITES'];folders={s:s for s in statuses};folders['TRAITES']='Traités'
 for directory in folders.values():(share/directory).mkdir()
 (share/'A TRAITER/a.pdf').write_bytes(b'%PDF a');(share/'A TRAITER/a.docx').write_bytes(b'word');(share/'A TRAITER/a.xlsx').write_bytes(b'audit')
 (share/'A TRAITER/sous').mkdir();(share/'A TRAITER/sous/a.pdf').write_bytes(b'%PDF autre version')
 (share/'Traités/fini.PDF').write_bytes(b'%PDF fini')
 def inventory():return {str(f.relative_to(share)):hashlib.sha256(f.read_bytes()).hexdigest() for f in share.rglob('*') if f.is_file()}
 before=inventory()
 for file in ['server.ps1','backup.ps1','seed.json','discovery.ps1']:shutil.copy(root/file,app/file)
 shutil.copytree(root/'web',app/'web');log=open(app/'server.log','w')
 def start():
  p=subprocess.Popen([os.environ['TEST_PWSH'],'-NoProfile','-File',str(app/'server.ps1'),'-Port','18096'],stdout=log,stderr=log)
  for _ in range(100):
   try:
    if req(path='/api/state')[0]==200:return p
   except OSError:pass
   time.sleep(.1)
  p.terminate();raise RuntimeError((app/'server.log').read_text())
 p=start()
 try:
  def headers():return {'Origin':base,'X-CSRF-Token':state()['token'],'Content-Type':'application/json'}
  def call(payload):return req({'actor':'MANAGER',**payload},headers())
  row={'entity':'ACM','root':str(share),'folders':folders}
  check('origine manquante refusée',req({'operation':'scan'})[0]==400)
  check('agent refusé',call({'actor':'HAMDANMO','operation':'configure','version':1,'rows':[row]})[0]==400)
  check('configuration valide',call({'operation':'configure','version':1,'rows':[row]})[0]==200)
  check('journal configuration',state()['state']['events'][-1]['action']=='CONFIGURATION_PARTAGES')
  check('version périmée refusée',call({'operation':'configure','version':1,'rows':[row]})[0]==400)
  check('chemin relatif refusé',call({'operation':'configure','version':2,'rows':[{**row,'root':'relatif'}]})[0]==400)
  check('sous-dossier traversant refusé',call({'operation':'configure','version':2,'rows':[{**row,'folders':{**folders,'TRAITES':'../ailleurs'}}]})[0]==400)
  check('statuts confondus refusés',call({'operation':'configure','version':2,'rows':[{**row,'folders':{**folders,'TRAITES':'A TRAITER'}}]})[0]==400)
  check('entité inconnue refusée',call({'operation':'configure','version':2,'rows':[{**row,'entity':'INCONNUE'}]})[0]==400)
  check('racines imbriquées refusées',call({'operation':'configure','version':2,'rows':[row,{**row,'entity':'DIRCO','root':str(share/'sous')} ]})[0]==400)
  check('entité sans configuration refusée',call({'operation':'scan','entity':'DIRCO'})[0]==400)
  code,raw=call({'operation':'scan','entity':'ACM'});result=json.loads(raw)['result']
  check('lecture réussie des quatre statuts',code==200 and all(r['complete'] for r in result['results']))
  check('seuls PDF comptés',result['results'][0]['pdf']==2 and result['results'][0]['word']==1 and result['results'][0]['other']==1)
  check('homonymes conservés',len(result['results'][0]['homonyms'])==1)
  check('sous-dossier personnalisé et extension majuscule',result['results'][3]['pdf']==1)
  check('aucune mutation du partage',before==inventory())
  code,raw=call({'operation':'discover','entity':'ACM'});discovery=json.loads(raw)['result']
  check('découverte racine par API',code==200 and discovery['complete'] and discovery['pdf']==3 and discovery['word']==1)
  check('chemin intégral dans découverte',all(str(share) in f['path'] for f in discovery['files']))
  check('découverte sans écriture',before==inventory())
  check('découverte agent refusée',call({'actor':'HAMDANMO','operation':'discover','entity':'ACM'})[0]==400)
  check('aucun import ni réception créé',len(state()['state']['docs'])==5)
  (share/'EN COURS').rmdir()
  report=json.loads(call({'operation':'scan','entity':'ACM'})[1])['result'];check('dossier absent marqué incomplet',not report['results'][1]['complete'] and 'EN COURS' in report['results'][1]['error'])
  (share/'EN COURS').mkdir();(share/'EN COURS/lien').symlink_to(share/'A TRAITER',target_is_directory=True)
  report=json.loads(call({'operation':'scan','entity':'ACM'})[1])['result'];check('jonction non suivie',not report['results'][1]['complete'] and report['results'][1]['pdf']==0)
  (share/'EN COURS/lien').unlink()
  for n in range(205):(share/'EN COURS'/f'{n}.pdf').write_bytes(b'%PDF')
  report=json.loads(call({'operation':'scan','entity':'ACM'})[1])['result'];r=report['results'][1];check('liste bornée total complet',r['complete'] and r['pdf']==205 and len(r['files'])==200 and r['listTruncated'])
  p.terminate();p.wait(timeout=5);p=start()
  check('configuration conservée au redémarrage',state()['state']['shares']['rows'][0]['root']==str(share))
  check('UNC hors réseau enregistrable',call({'operation':'configure','version':2,'rows':[{**row,'root':r'\\serveur\partage\ACM'}]})[0]==200)
  check('erreur explicite plateforme de test',call({'operation':'scan','entity':'ACM'})[0]==400)
  check('retrait configuration',call({'operation':'configure','version':3,'rows':[]})[0]==200 and not state()['state']['shares']['rows'])
  print('TOTAL:',count,'tests HTTP partages réussis')
 finally:p.terminate();p.wait(timeout=5);log.close()
