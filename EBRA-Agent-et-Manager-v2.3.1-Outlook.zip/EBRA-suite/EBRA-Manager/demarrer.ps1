$ErrorActionPreference='Stop'
$url='http://127.0.0.1:8766'
$mailUrl='http://127.0.0.1:8770'
$mailServer=Join-Path (Split-Path $PSScriptRoot -Parent) 'Outlook-Mail\server.ps1'
function Ready {
    try { return ((Invoke-RestMethod "$url/api/health" -TimeoutSec 2).version -eq '2.1.0') } catch { return $false }
}
function Start-MailModule {
    try { $health=Invoke-RestMethod "$mailUrl/api/health" -TimeoutSec 2;if($health.application -eq 'EBRA OUTLOOK'){return} } catch {}
    $mailIds=@(netstat.exe -ano -p tcp | ForEach-Object {
        if($_ -match '^\s*TCP\s+127\.0\.0\.1:8770\s+0\.0\.0\.0:0\s+\S+\s+(\d+)\s*$'){[int]$matches[1]}
    } | Select-Object -Unique)
    foreach($mailId in $mailIds){
        $mailProcess=Get-Process -Id $mailId -ErrorAction Stop
        if($mailProcess.ProcessName -notin @('powershell','pwsh')){throw 'Le port 8770 est utilise par une autre application.'}
        Stop-Process -Id $mailProcess.Id -ErrorAction Stop
        $mailProcess.WaitForExit(5000)|Out-Null
    }
    Start-Process powershell.exe -WindowStyle Hidden -ArgumentList ('-NoProfile -ExecutionPolicy Bypass -WindowStyle Hidden -File "'+$mailServer+'" -NoBrowser')
    for($i=0;$i -lt 20;$i++){Start-Sleep -Milliseconds 350;try{$health=Invoke-RestMethod "$mailUrl/api/health" -TimeoutSec 2;if($health.application -eq 'EBRA OUTLOOK'){return}}catch{}}
    throw 'Le module Messagerie Outlook ne demarre pas. Verifiez que le port 8770 est libre.'
}
try {
    Start-MailModule
    if (-not (Ready)) {
        $previous = $null
        try { $previous = Invoke-RestMethod "$url/api/health" -TimeoutSec 2 } catch {}
        if ($previous -and $previous.application -eq 'EBRA MANAGER') {
            $serverIds = @(netstat.exe -ano -p tcp | ForEach-Object {
                if ($_ -match '^\s*TCP\s+127\.0\.0\.1:8766\s+0\.0\.0\.0:0\s+\S+\s+(\d+)\s*$') { [int]$matches[1] }
            } | Select-Object -Unique)
            if ($serverIds.Count -ne 1) { throw 'Fermez l ancien serveur manager avant de relancer.' }
            $process = Get-Process -Id $serverIds[0] -ErrorAction Stop
            if ($process.ProcessName -notin @('powershell','pwsh')) { throw 'Le port 8766 est utilise par une autre application.' }
            Stop-Process -Id $process.Id -ErrorAction Stop
            $process.WaitForExit(5000) | Out-Null
        }
        Start-Process powershell.exe -WindowStyle Hidden -ArgumentList ('-NoProfile -ExecutionPolicy Bypass -WindowStyle Hidden -File "' + (Join-Path $PSScriptRoot 'serveur.ps1') + '"')
        $ready=$false
        for($i=0;$i -lt 20;$i++){Start-Sleep -Milliseconds 400;if(Ready){$ready=$true;break}}
        if(-not $ready){throw 'Le serveur manager ne demarre pas. Verifiez que le port 8766 est libre. Pour le diagnostic, ouvrez PowerShell dans ce dossier et lancez : powershell.exe -NoProfile -ExecutionPolicy Bypass -File .\serveur.ps1'}
    }
    Start-Process $url
} catch { Add-Type -AssemblyName PresentationFramework;[System.Windows.MessageBox]::Show($_.Exception.Message,'EBRA MANAGER') | Out-Null }
