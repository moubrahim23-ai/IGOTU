@echo off
start "" wscript.exe "%~dp0lancer.vbs"
exit /b
