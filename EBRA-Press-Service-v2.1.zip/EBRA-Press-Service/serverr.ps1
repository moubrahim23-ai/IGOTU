﻿param([int]$Port = 8765, [string]$DataDirectory = '\\uf11pu01\ACCESSIBILITÉ_ CONSEILLERS\EBRA SERVICE\EBRA SERVICE')
$ErrorActionPreference = 'Stop'
$utf8 = New-Object System.Text.UTF8Encoding($false)
$root = Join-Path $PSScriptRoot 'web'
[IO.Directory]::CreateDirectory($DataDirectory) | Out-Null
$database = Join-Path $DataDirectory 'traitements.json'
$mutex = New-Object Threading.Mutex($false, ('Local\EbraPressService' + $Port))
if (-not $mutex.WaitOne(0)) { exit }
function Save-Records($records) {
    $json = ConvertTo-Json -InputObject @($records) -Depth 8
    $temp = $database + '.tmp'
    [IO.File]::WriteAllText($temp, $json, $utf8)
    if ([IO.File]::Exists($database)) { [IO.File]::Replace($temp, $database, ($database + '.bak')) }
    else { [IO.File]::Move($temp, $database) }
}
function Read-Records {
    if (-not [IO.File]::Exists($database)) { return }
    $raw = [IO.File]::ReadAllText($database, $utf8)
    if (-not $raw.Trim().StartsWith('[')) { throw 'Le fichier JSON est invalide. Restaurez la sauvegarde .bak.' }
    $parsed = $raw | ConvertFrom-Json
    # Windows PowerShell 5.1 can emit a decorated array as a single pipeline
    # object. Enumerate explicitly, including wrappers written by version 1.
    Expand-Records $parsed
}
function Expand-Records($items) {
    foreach ($item in $items) {
        if ($null -eq $item) { throw 'Entree JSON vide : aucune donnee ne sera ecrasee.' }
        if ($item -is [array]) { Expand-Records $item }
        elseif ($item.PSObject.Properties['id']) { Write-Output $item }
        elseif ($item.PSObject.Properties['value'] -and $item.PSObject.Properties['Count']) {
            $script:needsMigration = $true
            Expand-Records $item.value
        } else { throw 'Structure JSON inconnue : aucune donnee ne sera ecrasee.' }
    }
}
function Required($value, $max) {
    if ($value -isnot [string] -or [string]::IsNullOrWhiteSpace($value) -or $value.Length -gt $max) { throw 'Champ obligatoire manquant ou trop long.' }
    return $value.Trim()
}
$listener = New-Object Net.Sockets.TcpListener([Net.IPAddress]::Loopback, $Port)
try {
    $listener.Start()
    $script:needsMigration = $false
    $initialRecords = @(Read-Records)
    if ($script:needsMigration) {
        $backup = $database + '.avant-correction-' + [DateTime]::Now.ToString('yyyyMMdd-HHmmss-fff') + '.bak'
        [IO.File]::Copy($database, $backup, $false)
        Save-Records $initialRecords
    }
    # Legacy ghost treatments must not occupy the live work queue. Keep them
    # for review, with their original dates and comments, rather than closing
    # them with fabricated processing durations.
    $legacyIds = @{}
    foreach ($legacyBackup in Get-ChildItem -LiteralPath $DataDirectory -Filter 'traitements.json.avant-correction-*.bak') {
        $legacyData = [IO.File]::ReadAllText($legacyBackup.FullName, $utf8) | ConvertFrom-Json
        foreach ($legacyRecord in @(Expand-Records $legacyData)) { $legacyIds[$legacyRecord.id] = $true }
    }
    $recovered = @($initialRecords | Where-Object { $_.statut -eq 'En cours' -and $legacyIds.ContainsKey($_.id) })
    if ($recovered.Count -gt 0) {
        [IO.File]::Copy($database, ($database + '.avant-deblocage-' + [DateTime]::Now.ToString('yyyyMMdd-HHmmss-fff') + '.bak'), $false)
        foreach ($record in $recovered) {
            $record.statut = 'A verifier'
            $record | Add-Member -NotePropertyName motifVerification -NotePropertyValue 'Ancienne trace issue du bug initial ; retiree de la file active sans inventer de date de fin.' -Force
            $record | Add-Member -NotePropertyName dateArchivage -NotePropertyValue ([DateTimeOffset]::Now.ToString('o')) -Force
        }
        Save-Records $initialRecords
    }
    while ($true) {
        $client = $listener.AcceptTcpClient()
        $client.ReceiveTimeout = 5000
        $client.SendTimeout = 5000
        $stream = $client.GetStream()
        try {
            $header = New-Object 'System.Collections.Generic.List[byte]'
            while ($header.Count -lt 16384) {
                $b = $stream.ReadByte()
                if ($b -lt 0) { throw 'Connexion interrompue.' }
                $header.Add([byte]$b)
                $n = $header.Count
                if ($n -ge 4 -and $header[$n-4] -eq 13 -and $header[$n-3] -eq 10 -and $header[$n-2] -eq 13 -and $header[$n-1] -eq 10) { break }
            }
            $lines = [Text.Encoding]::ASCII.GetString($header.ToArray()) -split "`r`n"
            $request = $lines[0] -split ' '
            $method = $request[0]; $path = $request[1]
            $headers = @{}
            foreach ($line in $lines | Select-Object -Skip 1) {
                if ($line.Contains(':')) { $pair = $line -split ':', 2; $headers[$pair[0].ToLowerInvariant()] = $pair[1].Trim() }
            }
            if ($headers['host'] -notin @("127.0.0.1:$Port", "localhost:$Port")) { throw 'Hote non autorise.' }
            $length = 0
            if ($headers.ContainsKey('content-length')) { $length = [int]$headers['content-length'] }
            if ($length -lt 0 -or $length -gt 32768 -or $headers.ContainsKey('transfer-encoding')) { throw 'Requete non prise en charge.' }
            $body = New-Object byte[] $length
            $offset = 0
            while ($offset -lt $length) { $read = $stream.Read($body, $offset, $length - $offset); if ($read -eq 0) { throw 'Requete incomplete.' }; $offset += $read }
            $status = '200 OK'; $type = 'application/json; charset=utf-8'
            if ($method -eq 'GET' -and $path -eq '/api/state') {
                $result = @{ application = 'EBRA PRESS SERVICE'; version = '2.1.1'; collaborateur = $env:USERNAME; traitements = @(Read-Records); chemin = $database }
            } elseif ($method -eq 'POST' -and $path -in @('/api/start', '/api/finish')) {
                if ($headers['origin'] -notin @("http://127.0.0.1:$Port", "http://localhost:$Port") -or $headers['x-ebra-request'] -ne '1') { throw 'Origine non autorisee.' }
                $inputData = $utf8.GetString($body) | ConvertFrom-Json
                $records = @(Read-Records)
                if ($path -eq '/api/start') {
                    if (@($records | Where-Object statut -eq 'En cours').Count -gt 0) { throw 'Un traitement est deja en cours.' }
                    if ($inputData.type -notin @('Front', 'Back', 'Web')) { throw 'Selectionnez Front, Back ou Web.' }
                    $record = [pscustomobject]@{ id = [guid]::NewGuid().ToString(); type = $inputData.type; titre = (Required $inputData.titre 200); origine = (Required $inputData.origine 200); commentaire = ''; datePriseEnCharge = [DateTimeOffset]::Now.ToString('o'); dateFin = $null; dmtSecondes = $null; dmt = $null; collaborateur = $env:USERNAME; statut = 'En cours' }
                    $records += $record
                } else {
                    $record = $records | Where-Object { $_.id -eq $inputData.id -and $_.statut -eq 'En cours' } | Select-Object -First 1
                    if (-not $record) { throw 'Ce traitement est introuvable ou deja termine.' }
                    $record.commentaire = Required $inputData.commentaire 5000
                    $now = [DateTimeOffset]::Now
                    $seconds = [Math]::Max(0, [Math]::Floor(($now - [DateTimeOffset]::Parse($record.datePriseEnCharge)).TotalSeconds))
                    $record.dateFin = $now.ToString('o'); $record.dmtSecondes = $seconds
                    $record.dmt = '{0:00}:{1:00}:{2:00}' -f [int][Math]::Floor($seconds / 3600), [int][Math]::Floor(($seconds % 3600) / 60), [int]($seconds % 60)
                    $record.statut = 'Termine'
                }
                Save-Records $records
                $result = @{ ok = $true }
            } elseif ($method -eq 'GET' -and $path -in @('/', '/app.js', '/style.css')) {
                $file = @{ '/' = 'index.html'; '/app.js' = 'app.js'; '/style.css' = 'style.css' }[$path]
                $type = @{ '/' = 'text/html; charset=utf-8'; '/app.js' = 'text/javascript; charset=utf-8'; '/style.css' = 'text/css; charset=utf-8' }[$path]
                $bytes = [IO.File]::ReadAllBytes((Join-Path $root $file))
            } else { $status = '404 Not Found'; $result = @{ erreur = 'Ressource introuvable.' } }
            if ($type.StartsWith('application/json')) { $bytes = $utf8.GetBytes((ConvertTo-Json -InputObject $result -Depth 10)) }
        } catch { $status = '400 Bad Request'; $type = 'application/json; charset=utf-8'; $bytes = $utf8.GetBytes((@{ erreur = $_.Exception.Message } | ConvertTo-Json)) }
        try {
            $response = "HTTP/1.1 $status`r`nContent-Type: $type`r`nContent-Length: $($bytes.Length)`r`nConnection: close`r`nCache-Control: no-store`r`nX-Content-Type-Options: nosniff`r`nContent-Security-Policy: default-src 'self'; frame-ancestors 'none'; base-uri 'none'`r`n`r`n"
            $prefix = [Text.Encoding]::ASCII.GetBytes($response)
            $stream.Write($prefix, 0, $prefix.Length); $stream.Write($bytes, 0, $bytes.Length)
        } catch {} finally { $client.Close() }
    }
} finally { $listener.Stop(); $mutex.ReleaseMutex(); $mutex.Dispose() }
