param(
    [string]$Dossier = (Join-Path $PSScriptRoot 'DP_TEST'),
    [int]$Port = 8090
)

$ErrorActionPreference = 'Stop'
$configuration = Join-Path $PSScriptRoot 'configuration.json'
if ($PSBoundParameters.ContainsKey('Dossier')) {
    if (-not (Test-Path -LiteralPath $Dossier -PathType Container)) { throw "Dossier introuvable : $Dossier" }
} elseif (Test-Path -LiteralPath $configuration) {
    $Dossier = (Get-Content -LiteralPath $configuration -Raw -Encoding UTF8 | ConvertFrom-Json).Dossier
    if (-not (Test-Path -LiteralPath $Dossier -PathType Container)) { throw "Dossier configure introuvable : $Dossier" }
} elseif (-not (Test-Path -LiteralPath $Dossier)) {
    New-Item -ItemType Directory -Path $Dossier -Force | Out-Null
}
$Dossier = (Resolve-Path -LiteralPath $Dossier).Path
$journal = Join-Path $PSScriptRoot 'journal.csv'
$page = Join-Path $PSScriptRoot 'index.html'
if (-not (Test-Path -LiteralPath $page)) { throw 'index.html introuvable dans le dossier du script.' }

function Get-Inventaire {
    $items = @{}
    foreach ($f in @(Get-ChildItem -LiteralPath $Dossier -File -Recurse -Force -ErrorAction Stop)) {
        $items[$f.FullName] = ('{0}|{1}' -f $f.Length, $f.LastWriteTimeUtc.Ticks)
    }
    return ,$items
}

function Ajouter-Evenement([string]$Action, [string]$Chemin) {
    # Le nom du compte ayant modifié un fichier sur un partage réseau n'est pas fourni par cet inventaire.
    $ligne = [pscustomobject]@{
        Date = (Get-Date).ToString('yyyy-MM-dd HH:mm:ss')
        Action = $Action
        Chemin = $Chemin
        Utilisateur = 'Non identifiable (modification externe)'
        Source = 'Surveillance du dossier'
    }
    $ligne | Export-Csv -LiteralPath $journal -Delimiter ';' -NoTypeInformation -Encoding UTF8 -Append
}

$avant = Get-Inventaire
$listener = [System.Net.HttpListener]::new()
$listener.Prefixes.Add("http://localhost:$Port/")
try {
    $listener.Start()
    Write-Host "Surveillance de : $Dossier"
    Write-Host "Interface : http://localhost:$Port/"
    Write-Host 'Arret : Ctrl+C dans cette fenetre.'
    Start-Process "http://localhost:$Port/"
    $requete = $listener.GetContextAsync()
    while ($listener.IsListening) {
        try { $maintenant = Get-Inventaire } catch {
            Write-Warning "Lecture du dossier impossible, inventaire precedent conserve : $($_.Exception.Message)"
            Start-Sleep -Milliseconds 2000
            continue
        }
        foreach ($chemin in $maintenant.Keys) {
            if (-not $avant.ContainsKey($chemin)) { Ajouter-Evenement 'CREATION' $chemin }
            elseif ($maintenant[$chemin] -ne $avant[$chemin]) { Ajouter-Evenement 'MODIFICATION' $chemin }
        }
        foreach ($chemin in $avant.Keys) {
            if (-not $maintenant.ContainsKey($chemin)) { Ajouter-Evenement 'SUPPRESSION' $chemin }
        }
        $avant = $maintenant
        if ($requete.IsCompleted) {
            try {
                $contexte = $requete.GetAwaiter().GetResult()
                $url = $contexte.Request.Url.AbsolutePath
                if ($url -eq '/api/config' -and $contexte.Request.HttpMethod -eq 'GET') {
                    $corps = [System.Text.Encoding]::UTF8.GetBytes((ConvertTo-Json -InputObject @{ Dossier = $Dossier } -Compress))
                    $type = 'application/json; charset=utf-8'
                } elseif ($url -eq '/api/config' -and $contexte.Request.HttpMethod -eq 'POST') {
                    $type = 'application/json; charset=utf-8'
                    $origine = $contexte.Request.Headers['Origin']
                    if ($origine -and $origine -ne "http://localhost:$Port") {
                        $contexte.Response.StatusCode = 403
                        $reponse = @{ erreur = 'Origine non autorisee.' }
                    } elseif ($contexte.Request.ContentLength64 -gt 8192) {
                        $contexte.Response.StatusCode = 413
                        $reponse = @{ erreur = 'Chemin trop long.' }
                    } else {
                        $lecteur = [System.IO.StreamReader]::new($contexte.Request.InputStream, $contexte.Request.ContentEncoding)
                        try { $entree = $lecteur.ReadToEnd() | ConvertFrom-Json } catch { $entree = $null }
                        $lecteur.Dispose()
                        $candidat = [string]$entree.Dossier
                        if ([string]::IsNullOrWhiteSpace($candidat) -or -not (Test-Path -LiteralPath $candidat -PathType Container)) {
                            $contexte.Response.StatusCode = 400
                            $reponse = @{ erreur = 'Dossier introuvable ou inaccessible depuis ce PC.' }
                        } else {
                            $nouveau = (Resolve-Path -LiteralPath $candidat).Path
                            if ($nouveau -ne $Dossier) {
                                $Dossier = $nouveau
                                $avant = Get-Inventaire
                            }
                            @{ Dossier = $Dossier } | ConvertTo-Json | Set-Content -LiteralPath $configuration -Encoding UTF8
                            $reponse = @{ Dossier = $Dossier; message = 'Surveillance active sur ce dossier.' }
                            Write-Host "Surveillance de : $Dossier"
                        }
                    }
                    $corps = [System.Text.Encoding]::UTF8.GetBytes((ConvertTo-Json -InputObject $reponse -Compress))
                } elseif ($url -eq '/api/journal') {
                    $donnees = @(if (Test-Path -LiteralPath $journal) { Import-Csv -LiteralPath $journal -Delimiter ';' -Encoding UTF8 | Select-Object -Last 500 })
                    $json = if ($donnees.Count -eq 0) { '[]' } else { ConvertTo-Json -InputObject $donnees -Depth 3 -Compress }
                    $corps = [System.Text.Encoding]::UTF8.GetBytes([string]$json)
                    $type = 'application/json; charset=utf-8'
                } elseif ($url -eq '/') {
                    $corps = [System.IO.File]::ReadAllBytes($page)
                    $type = 'text/html; charset=utf-8'
                } else {
                    $contexte.Response.StatusCode = 404
                    $corps = [System.Text.Encoding]::UTF8.GetBytes('Introuvable')
                    $type = 'text/plain; charset=utf-8'
                }
                $contexte.Response.ContentType = $type
                $contexte.Response.ContentLength64 = $corps.Length
                $contexte.Response.OutputStream.Write($corps, 0, $corps.Length)
                $contexte.Response.Close()
            } catch { Write-Warning $_.Exception.Message }
            if ($listener.IsListening) { $requete = $listener.GetContextAsync() }
        }
        Start-Sleep -Milliseconds 2000
    }
} finally { $listener.Stop(); $listener.Close() }
