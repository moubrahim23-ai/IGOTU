param([switch]$NoBrowser)
$ErrorActionPreference = 'Stop'
$Root = Split-Path -Parent $MyInvocation.MyCommand.Path
$Config = Get-Content (Join-Path $Root 'config.json') -Raw -Encoding UTF8 | ConvertFrom-Json
$Prefix = "http://127.0.0.1:$($Config.Port)/"
$DataDir = Join-Path $Root 'data'
$HistoryPath = Join-Path $DataDir 'historique.jsonl'

if (!(Test-Path $DataDir)) {
    $null = New-Item -ItemType Directory -Path $DataDir
}

function Add-History([string]$Action, [string]$Subject, [string]$Details) {
    $row = [ordered]@{
        date = (Get-Date).ToString('dd/MM/yyyy HH:mm:ss')
        user = [Environment]::UserName
        action = $Action
        subject = $Subject
        details = $Details
    }
    Add-Content -LiteralPath $HistoryPath -Value ($row | ConvertTo-Json -Compress) -Encoding UTF8
}

function Get-History {
    if (!(Test-Path $HistoryPath)) { return @{ history = @() } }
    $rows = @(Get-Content -LiteralPath $HistoryPath -Encoding UTF8 | Select-Object -Last 500 | ForEach-Object {
        try { $_ | ConvertFrom-Json } catch { }
    })
    [array]::Reverse($rows)
    return @{ history = $rows }
}

function Send-Json($Context, $Object, [int]$Status = 200) {
    $json = $Object | ConvertTo-Json -Depth 8 -Compress
    $bytes = [Text.Encoding]::UTF8.GetBytes($json)
    $Context.Response.StatusCode = $Status
    $Context.Response.ContentType = 'application/json; charset=utf-8'
    $Context.Response.Headers.Add('Cache-Control', 'no-store, no-cache, must-revalidate')
    $Context.Response.ContentLength64 = $bytes.Length
    $Context.Response.OutputStream.Write($bytes, 0, $bytes.Length)
    $Context.Response.Close()
}

function Send-File($Context, $Path) {
    if (!(Test-Path $Path -PathType Leaf)) {
        Send-Json $Context @{ error = 'File not found' } 404
        return
    }
    $ext = [IO.Path]::GetExtension($Path).ToLowerInvariant()
    $types = @{ '.html' = 'text/html; charset=utf-8'; '.css' = 'text/css; charset=utf-8'; '.js' = 'application/javascript; charset=utf-8' }
    $bytes = [IO.File]::ReadAllBytes($Path)
    $Context.Response.ContentType = $types[$ext]
    $Context.Response.Headers.Add('Cache-Control', 'no-store, no-cache, must-revalidate')
    $Context.Response.ContentLength64 = $bytes.Length
    $Context.Response.OutputStream.Write($bytes, 0, $bytes.Length)
    $Context.Response.Close()
}

function Get-OutlookContext {
    try { $outlook = [Runtime.InteropServices.Marshal]::GetActiveObject('Outlook.Application') }
    catch { $outlook = New-Object -ComObject Outlook.Application }
    $ns = $outlook.GetNamespace('MAPI')
    $inbox = $ns.GetDefaultFolder(6)
    $source = $inbox.Folders.Item([string]$Config.SourceFolder)
    $dest = $inbox.Folders.Item([string]$Config.DestinationFolder)
    if (!$source) { throw "Source folder not found: $($Config.SourceFolder)" }
    if (!$dest) { throw "Destination folder not found: $($Config.DestinationFolder)" }
    return @{ Namespace = $ns; Source = $source; Destination = $dest }
}

function Get-SenderEmail($Item) {
    try {
        if ($Item.SenderEmailType -eq 'EX') { return $Item.Sender.GetExchangeUser().PrimarySmtpAddress }
        return $Item.SenderEmailAddress
    } catch { return '' }
}

function Format-Size([long]$Bytes) {
    if ($Bytes -ge 1MB) { return ('{0:N1} MB' -f ($Bytes / 1MB)) }
    if ($Bytes -ge 1KB) { return ('{0:N0} KB' -f ($Bytes / 1KB)) }
    return "$Bytes bytes"
}

function Get-Messages {
    $o = Get-OutlookContext
    $items = $o.Source.Items
    $items.Sort('[ReceivedTime]', $true)
    $result = @()
    $limit = [Math]::Min([int]$Config.MaxMessages, $items.Count)
    for ($i = 1; $i -le $limit; $i++) {
        $m = $items.Item($i)
        if ($m -and $m.Class -eq 43) {
            $body = [string]$m.Body
            if ($body.Length -gt 12000) { $body = $body.Substring(0, 12000) + '...' }
            $att = @()
            for ($a = 1; $a -le $m.Attachments.Count; $a++) {
                $x = $m.Attachments.Item($a)
                $att += @{ index = $a; name = [string]$x.FileName; size = [long]$x.Size; sizeText = (Format-Size $x.Size) }
            }
            $result += @{
                id = [string]$m.EntryID; storeId = [string]$o.Source.StoreID
                sender = [string]$m.SenderName; senderEmail = (Get-SenderEmail $m)
                subject = [string]$m.Subject; received = $m.ReceivedTime.ToString('dd/MM/yyyy HH:mm')
                body = $body; unread = [bool]$m.UnRead; attachments = [int]$m.Attachments.Count; attachmentList = $att
            }
        }
    }
    return @{ messages = $result; sourceFolder = [string]$Config.SourceFolder; destinationFolder = [string]$Config.DestinationFolder }
}

function Move-Messages($Ids) {
    $o = Get-OutlookContext
    $moved = 0
    $errors = @()
    foreach ($id in $Ids) {
        try {
            $mail = $o.Namespace.GetItemFromID([string]$id, [string]$o.Source.StoreID)
            if ($mail) {
                $subject = [string]$mail.Subject
                $sender = [string]$mail.SenderName
                $null = $mail.Move($o.Destination)
                $moved++
                Add-History 'Move' $subject "From oubra to Accessibility - Sender: $sender"
            }
        } catch { $errors += @($_.Exception.Message) }
    }
    if ($errors.Count -gt 0 -and $moved -eq 0) { throw ($errors -join ' | ') }
    return @{ moved = $moved; failed = $errors.Count }
}

function Send-Attachment($Context, [string]$Id, [int]$Index) {
    $o = Get-OutlookContext
    $mail = $o.Namespace.GetItemFromID($Id, [string]$o.Source.StoreID)
    if (!$mail -or $Index -lt 1 -or $Index -gt $mail.Attachments.Count) { throw 'Attachment not found' }
    $att = $mail.Attachments.Item($Index)
    $safe = [IO.Path]::GetFileName([string]$att.FileName)
    $tmp = Join-Path ([IO.Path]::GetTempPath()) (('{0}_{1}' -f ([guid]::NewGuid().ToString('N')), $safe))
    $att.SaveAsFile($tmp)
    try {
        $bytes = [IO.File]::ReadAllBytes($tmp)
        $encoded = [Uri]::EscapeDataString($safe)
        $Context.Response.ContentType = 'application/octet-stream'
        $Context.Response.AddHeader('Content-Disposition', ("attachment; filename*=UTF-8''$encoded"))
        $Context.Response.ContentLength64 = $bytes.Length
        $Context.Response.OutputStream.Write($bytes, 0, $bytes.Length)
        $Context.Response.Close()
        Add-History 'Attachment download' ([string]$mail.Subject) $safe
    } finally { Remove-Item -LiteralPath $tmp -Force -ErrorAction SilentlyContinue }
}

function Reply-ToMessage($Data) {
    $Id = [string]$Data.id; $Text = [string]$Data.text; $To = [string]$Data.to
    $Cc = [string]$Data.cc; $Bcc = [string]$Data.bcc
    if ([string]::IsNullOrWhiteSpace($Text)) { throw 'Reply is empty' }
    if ([string]::IsNullOrWhiteSpace($To)) { throw 'Recipient is empty' }
    if ($Text.Length -gt 20000) { throw 'Reply exceeds 20000 characters' }
    $o = Get-OutlookContext
    $mail = $o.Namespace.GetItemFromID($Id, [string]$o.Source.StoreID)
    if (!$mail) { throw 'Email not found' }
    $reply = $mail.Reply()
    $originalHtml = [string]$reply.HTMLBody
    $encoded = [Net.WebUtility]::HtmlEncode($Text.Trim())
    $encoded = $encoded -replace "`r`n|`n|`r", '<br>'
    $reply.BodyFormat = 2
    $reply.HTMLBody = '<div style="font-family:Calibri,Arial,sans-serif;font-size:11pt">' + $encoded + '</div><br>' + $originalHtml
    $reply.To = $To; $reply.CC = $Cc; $reply.BCC = $Bcc
    $temps = @(); $names = @(); [long]$total = 0
    try {
        foreach ($a in @($Data.attachments)) {
            if ($null -eq $a) { continue }
            $safe = [IO.Path]::GetFileName([string]$a.name)
            if ([string]::IsNullOrWhiteSpace($safe)) { throw 'Invalid attachment name' }
            $bytes = [Convert]::FromBase64String([string]$a.content)
            $total += $bytes.Length
            if ($total -gt 20MB) { throw 'Attachments exceed 20 MB' }
            $tmp = Join-Path ([IO.Path]::GetTempPath()) (('{0}_{1}' -f ([guid]::NewGuid().ToString('N')), $safe))
            [IO.File]::WriteAllBytes($tmp, $bytes)
            $temps += @($tmp); $names += @($safe)
            $null = $reply.Attachments.Add($tmp, 1, 1, $safe)
        }
        $reply.Send()
        $detail = "To: $To"
        if ($Cc) { $detail += "; Cc: $Cc" }
        if ($Bcc) { $detail += "; Bcc: $Bcc" }
        if ($names.Count) { $detail += '; Attachments: ' + ($names -join ', ') }
        Add-History 'Reply sent' ([string]$mail.Subject) $detail
        return @{ sent = $true }
    } finally {
        foreach ($tmp in $temps) { Remove-Item -LiteralPath $tmp -Force -ErrorAction SilentlyContinue }
    }
}

$listener = New-Object Net.HttpListener
$listener.Prefixes.Add($Prefix)
try {
    $listener.Start()
    Write-Host "Server started: $Prefix" -ForegroundColor Green
    Write-Host 'Ctrl+C to stop.' -ForegroundColor DarkGray
    if (!$NoBrowser) { Start-Process ($Prefix + '?v=4.1') }
    while ($listener.IsListening) {
        $ctx = $listener.GetContext()
        try {
            $path = $ctx.Request.Url.AbsolutePath
            if ($ctx.Request.HttpMethod -eq 'GET' -and $path -eq '/api/messages') {
                Send-Json $ctx (Get-Messages)
            } elseif ($ctx.Request.HttpMethod -eq 'GET' -and $path -eq '/api/history') {
                Send-Json $ctx (Get-History)
            } elseif ($ctx.Request.HttpMethod -eq 'GET' -and $path -eq '/api/attachment') {
                $id = $ctx.Request.QueryString['id']; $index = [int]$ctx.Request.QueryString['index']
                Send-Attachment $ctx $id $index
            } elseif ($ctx.Request.HttpMethod -eq 'POST' -and $path -eq '/api/move') {
                $reader = New-Object IO.StreamReader($ctx.Request.InputStream, $ctx.Request.ContentEncoding)
                $data = $reader.ReadToEnd() | ConvertFrom-Json
                if (!$data.ids) { throw 'No message selected' }
                Send-Json $ctx (Move-Messages $data.ids)
            } elseif ($ctx.Request.HttpMethod -eq 'POST' -and $path -eq '/api/reply') {
                $reader = New-Object IO.StreamReader($ctx.Request.InputStream, $ctx.Request.ContentEncoding)
                $data = $reader.ReadToEnd() | ConvertFrom-Json
                Send-Json $ctx (Reply-ToMessage $data)
            } elseif ($ctx.Request.HttpMethod -eq 'GET') {
                if ($path -eq '/') { $name = 'index.html' } else { $name = $path.TrimStart('/') }
                if ($name -notin @('index.html', 'styles.css', 'app.js')) { Send-Json $ctx @{ error = 'Forbidden resource' } 403 }
                else { Send-File $ctx (Join-Path $Root $name) }
            } else { Send-Json $ctx @{ error = 'Method not allowed' } 405 }
        } catch {
            try { Send-Json $ctx @{ error = $_.Exception.Message } 500 } catch { }
        }
    }
} finally {
    if ($listener.IsListening) { $listener.Stop() }
    $listener.Close()
}
