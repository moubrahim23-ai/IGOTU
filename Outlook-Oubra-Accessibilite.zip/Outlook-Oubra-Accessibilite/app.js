const $=s=>document.querySelector(s);
let all=[], selected=new Set(), activeId='';
const esc=s=>String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
function toast(msg,bad=false){const t=$('#toast');t.textContent=msg;t.className='toast show'+(bad?' bad':'');setTimeout(()=>t.className='toast',3200)}
function setStatus(text,type='ok'){ $('#status').textContent=text; $('#status').className='status '+type }
async function api(url,opt){const r=await fetch(url,opt);let data;try{data=await r.json()}catch{throw Error('Réponse serveur invalide')}if(!r.ok||data.error)throw Error(data.error||`Erreur ${r.status}`);return data}
async function load(){
  setStatus('Lecture d’Outlook…','loading'); $('#messages').innerHTML='<div class="empty">Chargement des messages…</div>';
  try{const d=await api('/api/messages');all=d.messages||[];selected.clear();activeId='';$('#sourceName').textContent=d.sourceFolder;$('#destName').textContent=d.destinationFolder;setStatus('Outlook connecté');render();updateSelection();$('#preview').innerHTML='<div class="empty">Sélectionne un message pour afficher son aperçu.</div>'}
  catch(e){setStatus('Connexion impossible','error');$('#messages').innerHTML=`<div class="empty">${esc(e.message)}<br><br>Vérifie qu’Outlook classique est ouvert.</div>`;toast(e.message,true)}
}
function filtered(){const q=$('#search').value.trim().toLocaleLowerCase('fr');return q?all.filter(m=>`${m.sender} ${m.subject} ${m.body}`.toLocaleLowerCase('fr').includes(q)):all}
function render(){const rows=filtered();$('#count').textContent=`${rows.length} message${rows.length>1?'s':''}`;$('#messages').innerHTML=rows.length?rows.map(m=>`<div class="message ${m.unread?'unread':''} ${m.id===activeId?'active':''}" data-id="${esc(m.id)}"><input type="checkbox" ${selected.has(m.id)?'checked':''} aria-label="Sélectionner"><div class="sender">${esc(m.sender||'(expéditeur inconnu)')}</div><div class="date">${esc(m.received)}</div><div class="subject">${esc(m.subject||'(sans objet)')}</div><div class="snippet">${esc((m.body||'').replace(/\s+/g,' ').slice(0,150))}</div></div>`).join(''):'<div class="empty">Aucun message trouvé.</div>';bindRows()}
function bindRows(){document.querySelectorAll('.message').forEach(row=>{row.addEventListener('click',e=>{const id=row.dataset.id;if(e.target.type==='checkbox'){e.target.checked?selected.add(id):selected.delete(id);updateSelection();return}activeId=id;render();showPreview(all.find(m=>m.id===id))})})}
function showPreview(m){if(!m)return;$('#preview').innerHTML=`<h2>${esc(m.subject||'(sans objet)')}</h2><div class="meta"><span>De</span><b>${esc(m.sender)} &lt;${esc(m.senderEmail)}&gt;</b><span>Reçu</span><b>${esc(m.received)}</b><span>Pièces jointes</span><b>${m.attachments||0}</b></div><div class="body">${esc(m.body||'(message vide)')}</div>`}
function updateSelection(){const visible=filtered();$('#selectedCount').textContent=selected.size;$('#move').disabled=!selected.size;$('#selectAll').checked=visible.length>0&&visible.every(m=>selected.has(m.id));$('#selectAll').indeterminate=visible.some(m=>selected.has(m.id))&&!$('#selectAll').checked}
$('#search').addEventListener('input',()=>{render();updateSelection()});
$('#refresh').addEventListener('click',load);
$('#selectAll').addEventListener('change',e=>{filtered().forEach(m=>e.target.checked?selected.add(m.id):selected.delete(m.id));render();updateSelection()});
$('#move').addEventListener('click',async()=>{const n=selected.size;if(!confirm(`Déplacer ${n} message${n>1?'s':''} vers « ${$('#destName').textContent} » ?`))return;$('#move').disabled=true;setStatus('Déplacement…','loading');try{const d=await api('/api/move',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({ids:[...selected]})});toast(`${d.moved} message${d.moved>1?'s':''} déplacé${d.moved>1?'s':''}.`);await load()}catch(e){toast(e.message,true);setStatus('Erreur de déplacement','error');updateSelection()}});
load();
