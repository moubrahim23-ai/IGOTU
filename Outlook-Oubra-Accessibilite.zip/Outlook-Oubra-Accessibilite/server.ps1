param([switch]$NoBrowser)
$ErrorActionPreference = 'Stop'
$Root = Split-Path -Parent $MyInvocation.MyCommand.Path
$Config = Get-Content (Join-Path $Root 'config.json') -Raw -Encoding UTF8 | ConvertFrom-Json
$Prefix = "http://127.0.0.1:$($Config.Port)/"

function Send-Json($Context, $Object, [int]$Status=200) {
    $json = $Object | ConvertTo-Json -Depth 8 -Compress
    $bytes = [Text.Encoding]::UTF8.GetBytes($json)
    $Context.Response.StatusCode = $Status
    $Context.Response.ContentType = 'application/json; charset=utf-8'
    $Context.Response.ContentLength64 = $bytes.Length
    $Context.Response.OutputStream.Write($bytes,0,$bytes.Length)
    $Context.Response.Close()
}
function Send-File($Context, $Path) {
    if (!(Test-Path $Path -PathType Leaf)) { Send-Json $Context @{error='Fichier introuvable'} 404; return }
    $ext=[IO.Path]::GetExtension($Path).ToLowerInvariant(); $types=@{'.html'='text/html; charset=utf-8';'.css'='text/css; charset=utf-8';'.js'='application/javascript; charset=utf-8'}
    $bytes=[IO.File]::ReadAllBytes($Path); $Context.Response.ContentType=$types[$ext]; $Context.Response.ContentLength64=$bytes.Length
    $Context.Response.OutputStream.Write($bytes,0,$bytes.Length); $Context.Response.Close()
}
function Get-OutlookContext {
    try { $outlook=[Runtime.InteropServices.Marshal]::GetActiveObject('Outlook.Application') } catch { $outlook=New-Object -ComObject Outlook.Application }
    $ns=$outlook.GetNamespace('MAPI'); $inbox=$ns.GetDefaultFolder(6)
    $source=$inbox.Folders.Item([string]$Config.SourceFolder); $dest=$inbox.Folders.Item([string]$Config.DestinationFolder)
    if (!$source) { throw "Le dossier Outlook '$($Config.SourceFolder)' est introuvable sous Boîte de réception." }
    if (!$dest) { throw "Le dossier Outlook '$($Config.DestinationFolder)' est introuvable sous Boîte de réception." }
    @{ Namespace=$ns; Source=$source; Destination=$dest }
}
function Get-SenderEmail($Item) {
    try { if($Item.SenderEmailType -eq 'EX'){return $Item.Sender.GetExchangeUser().PrimarySmtpAddress}; return $Item.SenderEmailAddress } catch { return '' }
}
function Get-Messages {
    $o=Get-OutlookContext; $items=$o.Source.Items; $items.Sort('[ReceivedTime]', $true); $result=@(); $limit=[Math]::Min([int]$Config.MaxMessages,$items.Count)
    for($i=1;$i -le $limit;$i++){
        $m=$items.Item($i); if($m -and $m.Class -eq 43){
            $body=[string]$m.Body; if($body.Length -gt 12000){$body=$body.Substring(0,12000)+'…'}
            $result+=@{id=[string]$m.EntryID;storeId=[string]$o.Source.StoreID;sender=[string]$m.SenderName;senderEmail=(Get-SenderEmail $m);subject=[string]$m.Subject;received=$m.ReceivedTime.ToString('dd/MM/yyyy HH:mm');body=$body;unread=[bool]$m.UnRead;attachments=[int]$m.Attachments.Count}
        }
    }
    @{messages=$result;sourceFolder=[string]$Config.SourceFolder;destinationFolder=[string]$Config.DestinationFolder}
}
function Move-Messages($Ids) {
    $o=Get-OutlookContext; $moved=0; $errors=@()
    foreach($id in $Ids){try{$mail=$o.Namespace.GetItemFromID([string]$id,[string]$o.Source.StoreID);if($mail){$null=$mail.Move($o.Destination);$moved++}}catch{$errors+=@($_.Exception.Message)}}
    if($errors.Count -gt 0 -and $moved -eq 0){throw ($errors -join ' | ')}
    @{moved=$moved;failed=$errors.Count}
}

$listener=New-Object Net.HttpListener; $listener.Prefixes.Add($Prefix)
try {
    $listener.Start(); Write-Host "Serveur démarré : $Prefix" -ForegroundColor Green; Write-Host 'Ctrl+C pour arrêter.' -ForegroundColor DarkGray
    if(!$NoBrowser){Start-Process $Prefix}
    while($listener.IsListening){
        $ctx=$listener.GetContext()
        try{
            $path=$ctx.Request.Url.AbsolutePath
            if($ctx.Request.HttpMethod -eq 'GET' -and $path -eq '/api/messages'){Send-Json $ctx (Get-Messages)}
            elseif($ctx.Request.HttpMethod -eq 'POST' -and $path -eq '/api/move'){$reader=New-Object IO.StreamReader($ctx.Request.InputStream,$ctx.Request.ContentEncoding);$data=$reader.ReadToEnd()|ConvertFrom-Json;if(!$data.ids){throw 'Aucun message sélectionné.'};Send-Json $ctx (Move-Messages $data.ids)}
            elseif($ctx.Request.HttpMethod -eq 'GET'){$name=if($path -eq '/'){'index.html'}else{$path.TrimStart('/')};if($name -notin @('index.html','styles.css','app.js')){Send-Json $ctx @{error='Ressource interdite'} 403}else{Send-File $ctx (Join-Path $Root $name)}}
            else{Send-Json $ctx @{error='Méthode non autorisée'} 405}
        }catch{try{Send-Json $ctx @{error=$_.Exception.Message} 500}catch{}}
    }
} finally { if($listener.IsListening){$listener.Stop()};$listener.Close() }
